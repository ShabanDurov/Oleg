package com.example

import android.content.Context
import androidx.test.core.app.ApplicationProvider
import com.example.call.CallAudioRouteManager
import com.example.call.CallEndReason
import com.example.call.CallPhase
import com.example.call.CallStateReducer
import com.example.call.IceCandidatePayload
import com.example.data.model.CallSession
import com.example.util.PhonogrammMediaHelper
import com.example.util.VideoCircleCodec
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [36])
class ExampleRobolectricTest {

    @Test
    fun appName_matchesOleg() {
        val context = ApplicationProvider.getApplicationContext<Context>()
        val appName = context.getString(R.string.app_name)
        assertEquals("Oleg", appName)
    }

    @Test
    fun callStateReducer_outgoingAndIncomingStateTransitions_andDuplicateCallGuard() {
        val sampleSession = CallSession(
            callId = "call_alice_bob",
            sessionId = "sess_101",
            callerId = "alice_uid",
            callerUsername = "Alice",
            calleeId = "bob_uid",
            calleeUsername = "Bob",
            isVideo = false,
            callerVideoEnabled = false,
            calleeVideoEnabled = false,
            status = CallSession.STATUS_RINGING
        )

        // 1. Start from IDLE -> OUTGOING
        val idle = CallStateReducer.transitionToIdle()
        assertTrue(CallStateReducer.canStartNewCall(idle.phase))

        val outgoing = CallStateReducer.transitionToOutgoing(sampleSession, isVideo = false)
        assertEquals(CallPhase.OUTGOING, outgoing.phase)
        assertFalse(outgoing.isIncoming)
        assertFalse(outgoing.isLocalVideoEnabled)
        assertFalse("Cannot start a second call while OUTGOING", CallStateReducer.canStartNewCall(outgoing.phase))

        // 2. OUTGOING -> CONNECTING -> ACTIVE -> RECONNECTING -> ACTIVE -> IDLE
        val acceptedSession = sampleSession.copy(
            status = CallSession.STATUS_ACCEPTED,
            calleeVideoEnabled = true
        )
        val connecting = CallStateReducer.transitionToConnecting(
            current = outgoing,
            session = acceptedSession,
            localVideoEnabled = false,
            remoteVideoEnabled = true
        )
        assertEquals(CallPhase.CONNECTING, connecting.phase)
        assertTrue(connecting.isRemoteVideoEnabled)

        val active = CallStateReducer.transitionToActive(connecting).copy(elapsedSeconds = 65)
        assertEquals(CallPhase.ACTIVE, active.phase)
        assertEquals("01:05", active.formattedElapsedTime)

        val reconnecting = CallStateReducer.transitionToReconnecting(active)
        assertEquals(CallPhase.RECONNECTING, reconnecting.phase)

        val recovered = CallStateReducer.transitionToActive(reconnecting)
        assertEquals(CallPhase.ACTIVE, recovered.phase)

        val ended = CallStateReducer.transitionToEnding(recovered, CallEndReason.HANGUP_LOCAL)
        assertEquals(CallPhase.ENDING, ended.phase)
        assertEquals(CallEndReason.HANGUP_LOCAL, ended.endReason)

        val backToIdle = CallStateReducer.transitionToIdle()
        assertEquals(CallPhase.IDLE, backToIdle.phase)
        assertNull(backToIdle.session)

        // 3. INCOMING call state machine
        val incomingVideoSession = sampleSession.copy(
            sessionId = "sess_202",
            isVideo = true,
            callerVideoEnabled = true
        )
        val incoming = CallStateReducer.transitionToIncoming(incomingVideoSession)
        assertEquals(CallPhase.INCOMING, incoming.phase)
        assertTrue(incoming.isIncoming)
        assertTrue(incoming.isRemoteVideoEnabled)
        assertFalse(CallStateReducer.canStartNewCall(incoming.phase))
    }

    @Test
    fun iceCandidatePayload_jsonRoundTrip_andInvalidJsonHandling() {
        val candidate = IceCandidatePayload(
            sdpMid = "0",
            sdpMLineIndex = 0,
            sdp = "candidate:842163049 1 udp 1677729535 203.0.113.10 54321 typ srflx raddr 192.168.1.5 rport 54321"
        )
        val json = candidate.toJsonString()
        val parsed = IceCandidatePayload.fromJsonString(json)
        assertNotNull(parsed)
        assertEquals("0", parsed!!.sdpMid)
        assertEquals(0, parsed.sdpMLineIndex)
        assertEquals(candidate.sdp, parsed.sdp)

        assertNull(IceCandidatePayload.fromJsonString(""))
        assertNull(IceCandidatePayload.fromJsonString("{broken_json"))
    }

    @Test
    fun callSession_peerHelpers_resolveCallerAndCalleeSignalingCorrectly() {
        val session = CallSession(
            callId = "call_1_2",
            sessionId = "sess_abc",
            callerId = "uid_caller",
            callerUsername = "CallerUser",
            calleeId = "uid_callee",
            calleeUsername = "CalleeUser",
            isVideo = true,
            callerVideoEnabled = true,
            calleeVideoEnabled = false,
            callerMuted = false,
            calleeMuted = true,
            offerSdp = "v=0\r\no=- 123 2 IN IP4 127.0.0.1\r\n",
            answerSdp = "v=0\r\no=- 456 2 IN IP4 127.0.0.1\r\n",
            callerCandidates = listOf("cand_caller_1"),
            calleeCandidates = listOf("cand_callee_1", "cand_callee_2"),
            status = CallSession.STATUS_ACCEPTED
        )

        // From caller's perspective
        assertFalse(session.isIncoming("uid_caller"))
        assertEquals("CalleeUser", session.otherUsername("uid_caller"))
        assertFalse(session.peerVideoEnabled("uid_caller"))
        assertTrue(session.peerMuted("uid_caller"))
        assertEquals(listOf("cand_callee_1", "cand_callee_2"), session.peerCandidates("uid_caller"))

        // From callee's perspective
        assertTrue(session.isIncoming("uid_callee"))
        assertEquals("CallerUser", session.otherUsername("uid_callee"))
        assertTrue(session.peerVideoEnabled("uid_callee"))
        assertFalse(session.peerMuted("uid_callee"))
        assertEquals(listOf("cand_caller_1"), session.peerCandidates("uid_callee"))
    }

    @Test
    fun callAudioRouteManager_acquiresTogglesAndReleasesAudioCleanly() {
        val context = ApplicationProvider.getApplicationContext<Context>()
        val routeManager = CallAudioRouteManager(context)

        routeManager.acquireCallAudioRoute(enableSpeakerphone = true)
        routeManager.setSpeakerphoneEnabled(false)
        routeManager.setSpeakerphoneEnabled(true)
        routeManager.releaseCallAudioRoute()
    }

    @Test
    fun voiceMessages_videoCircles_andPhotoPayloads_remainIntact() {
        // 1. Photo pending registration & consumption
        val photoTag = "📷 Фотография #test1"
        val sampleDataUri = "data:image/jpeg;base64,/9j/4AAQSkZJRg=="
        PhonogrammMediaHelper.registerPendingChatPhoto(photoTag, sampleDataUri)
        val consumedPhoto = PhonogrammMediaHelper.consumePendingChatPhoto(photoTag)
        assertEquals(sampleDataUri, consumedPhoto)
        assertNull(PhonogrammMediaHelper.consumePendingChatPhoto(photoTag))

        // 2. Telegram-style Video Circle ("кружок") packing & local cache registration
        val packedCircle = VideoCircleCodec.packVideoCircleFrames(
            rawFrames = listOf("dGVzdGZyYW1lMQ==", "dGVzdGZyYW1lMg==", "dGVzdGZyYW1lMw=="),
            durationSeconds = 3
        )
        assertTrue(packedCircle.startsWith(VideoCircleCodec.VIDEO_CIRCLE_PREFIX))

        val circleMsgTag = "📹 Видеосообщение (0:03)"
        PhonogrammMediaHelper.registerPendingChatPhoto(circleMsgTag, packedCircle)
        assertEquals(packedCircle, PhonogrammMediaHelper.getLocalVideoCirclePayload(circleMsgTag))
        assertEquals(packedCircle, PhonogrammMediaHelper.consumePendingChatPhoto(circleMsgTag))
    }
}
