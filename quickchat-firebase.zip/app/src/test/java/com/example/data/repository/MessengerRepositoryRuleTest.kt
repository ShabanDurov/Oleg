package com.example.data.repository

import com.example.base.FirestoreEmulatorTestBase
import com.example.data.model.AdminAccessDeniedException
import com.example.data.model.NicknameTakenException
import com.google.firebase.firestore.FirebaseFirestoreException
import java.util.UUID
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.runBlocking
import kotlinx.coroutines.tasks.await
import kotlinx.coroutines.withTimeout
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Assert.fail
import org.junit.Test

class MessengerRepositoryRuleTest : FirestoreEmulatorTestBase() {

    @Test
    fun signInWithoutExistingProfileDocument_observesNullCleanlyWithoutSnapshotError_andRegistersNonAdmin() = runBlocking {
        val suffix = UUID.randomUUID().toString().replace("-", "").take(6)
        // Specifically verify the reported account scenario (aboba.666.777.ali@gmail.com)
        val abobaUid = signInTestUser("aboba.666.777.ali.$suffix@gmail.com")
        val repository = MessengerRepository(firestore, auth)

        // 1. Before registration, /users/{uid} does not exist.
        // observeUserProfile must emit null cleanly (NeedsRegistration) and NEVER throw "Error getting DocumentReference snapshot".
        val initialSnapshot = withTimeout(FLOW_TIMEOUT_MS) {
            repository.observeUserProfile(abobaUid).first()
        }
        assertNull("Unregistered user profile must emit null cleanly", initialSnapshot)

        // 2. Register nickname and verify default non-admin flags
        val nick = "Aboba_$suffix"
        val regResult = withTimeout(DEFAULT_TIMEOUT_MS) {
            repository.registerNickname(nick)
        }
        assertTrue("Registration should succeed: ${regResult.exceptionOrNull()}", regResult.isSuccess)
        val createdProfile = regResult.getOrThrow()
        assertEquals(abobaUid, createdProfile.uid)
        assertFalse("New user must NOT have hasAdminPanel=true", createdProfile.hasAdminPanel)
        assertFalse("New user must NOT have isVerified=true", createdProfile.isVerified)
        assertFalse("aboba.666.777.ali@gmail.com must NOT be admin", repository.isCurrentUserVerifiedAdmin())

        // 3. After registration, observeUserProfile emits the ready UserProfile
        val loadedProfile = withTimeout(FLOW_TIMEOUT_MS) {
            repository.observeUserProfile(abobaUid).first { it != null }
        }
        assertNotNull(loadedProfile)
        assertEquals(nick, loadedProfile!!.username)
    }

    @Test
    fun adminPanelAccess_deniedForRegularUsers_allowedOnlyForServerVerifiedShabanDurov() = runBlocking {
        val suffix = UUID.randomUUID().toString().replace("-", "").take(6)
        val regularEmail = "regular_$suffix@test.com"
        val regularNick = "User_$suffix"

        // 1. Register regular user
        val regularUid = signInTestUser(regularEmail)
        val repository = MessengerRepository(firestore, auth)
        val regularProfile = withTimeout(DEFAULT_TIMEOUT_MS) {
            repository.registerNickname(regularNick)
        }.getOrThrow()
        assertEquals(regularUid, regularProfile.uid)
        assertFalse("Regular user must not be verified admin", repository.isCurrentUserVerifiedAdmin())

        // 2. Regular user attempting admin actions via Repository is rejected with AdminAccessDeniedException
        val giftAttempt = withTimeout(DEFAULT_TIMEOUT_MS) {
            repository.sendGiftToUser(regularNick, regularNick, "👑", "legendary", "Hack")
        }
        assertTrue(giftAttempt.isFailure)
        assertTrue(giftAttempt.exceptionOrNull() is AdminAccessDeniedException)

        val verifyAttempt = withTimeout(DEFAULT_TIMEOUT_MS) {
            repository.setVerificationBadge(regularNick, true, regularNick)
        }
        assertTrue(verifyAttempt.isFailure)
        assertTrue(verifyAttempt.exceptionOrNull() is AdminAccessDeniedException)

        // 3. Regular user attempting to escalate privileges directly in Firestore is rejected by Rules
        try {
            withTimeout(DEFAULT_TIMEOUT_MS) {
                firestore.collection("users").document(regularUid)
                    .update("isVerified", true, "hasAdminPanel", true)
                    .await()
            }
            fail("Regular user must not be able to escalate own privileges in Firestore")
        } catch (e: Exception) {
            val fsEx = checkNotNull(e.unwrapFirestoreException()) { "Expected FirebaseFirestoreException, got $e" }
            assertEquals(FirebaseFirestoreException.Code.PERMISSION_DENIED, fsEx.code)
        }

        // 4. Regular user attempting to overwrite /config/admin is rejected by Rules
        try {
            withTimeout(DEFAULT_TIMEOUT_MS) {
                firestore.collection("config").document("admin")
                    .set(mapOf("adminUid" to regularUid, "adminUsernameLower" to "shabandurov"))
                    .await()
            }
            fail("Regular user must not be able to write /config/admin")
        } catch (e: Exception) {
            val fsEx = checkNotNull(e.unwrapFirestoreException()) { "Expected FirebaseFirestoreException, got $e" }
            assertEquals(FirebaseFirestoreException.Code.PERMISSION_DENIED, fsEx.code)
        }

        // 5. Sign in as ShabanDurov and seed /config/admin on the server with ShabanDurov's UID
        val shabanUid = signInTestUser("shabandurov_$suffix@phonogramm.org")
        seedServerAdminConfig(shabanUid)

        // Register nickname "ShabanDurov" (or if already registered in this emulator run, ensure profile exists)
        val existingShaban = repository.findUserByNickname("ShabanDurov").getOrNull()
        if (existingShaban == null) {
            val shabanReg = withTimeout(DEFAULT_TIMEOUT_MS) {
                repository.registerNickname("ShabanDurov")
            }
            assertTrue("ShabanDurov registration should succeed: ${shabanReg.exceptionOrNull()}", shabanReg.isSuccess)
            assertTrue("Verified ShabanDurov must be recognized as admin", repository.isCurrentUserVerifiedAdmin())

            // Verified ShabanDurov can grant verification badge and send gifts to regular user
            val grantBadgeRes = withTimeout(DEFAULT_TIMEOUT_MS) {
                repository.setVerificationBadge(regularNick, true, "ShabanDurov")
            }
            assertTrue("Verified ShabanDurov should grant badge: ${grantBadgeRes.exceptionOrNull()}", grantBadgeRes.isSuccess)

            val sendGiftRes = withTimeout(DEFAULT_TIMEOUT_MS) {
                repository.sendGiftToUser(regularNick, "ShabanDurov", "👑", "legendary", "От создателя")
            }
            assertTrue("Verified ShabanDurov should send gift: ${sendGiftRes.exceptionOrNull()}", sendGiftRes.isSuccess)
        }
    }

    @Test
    fun fullTwoUserMessengerFlow_registrationSearchChatAndRealtimeMessaging_succeeds() = runBlocking {
        val suffix = UUID.randomUUID().toString().replace("-", "").take(6)
        val aliceEmail = "alice_$suffix@test.com"
        val bobEmail = "bob_$suffix@test.com"
        val charlieEmail = "charlie_$suffix@test.com"

        val aliceNick = "Alice_$suffix"
        val bobNick = "Bob_$suffix"

        // 1. Register Alice
        val aliceUid = signInTestUser(aliceEmail)
        val repository = MessengerRepository(firestore, auth)
        val aliceProfileResult = withTimeout(DEFAULT_TIMEOUT_MS) {
            repository.registerNickname(aliceNick)
        }
        assertTrue("Alice registration should succeed: ${aliceProfileResult.exceptionOrNull()}", aliceProfileResult.isSuccess)
        val aliceProfile = aliceProfileResult.getOrThrow()
        assertEquals(aliceUid, aliceProfile.uid)
        assertEquals(aliceNick, aliceProfile.username)

        // 2. Sign in as Bob and verify case-insensitive duplicate nickname is rejected
        val bobUid = signInTestUser(bobEmail)
        val duplicateResult = withTimeout(DEFAULT_TIMEOUT_MS) {
            repository.registerNickname(aliceNick.uppercase())
        }
        assertTrue("Duplicate nickname registration must fail", duplicateResult.isFailure)
        assertTrue(
            "Expected NicknameTakenException, got ${duplicateResult.exceptionOrNull()}",
            duplicateResult.exceptionOrNull() is NicknameTakenException
        )

        // 3. Register Bob with his own unique nickname
        val bobProfileResult = withTimeout(DEFAULT_TIMEOUT_MS) {
            repository.registerNickname(bobNick)
        }
        assertTrue("Bob registration should succeed: ${bobProfileResult.exceptionOrNull()}", bobProfileResult.isSuccess)
        val bobProfile = bobProfileResult.getOrThrow()
        assertEquals(bobUid, bobProfile.uid)

        // 4. Bob searches for Alice by nickname (case-insensitive)
        val foundAliceResult = withTimeout(DEFAULT_TIMEOUT_MS) {
            repository.findUserByNickname(aliceNick.lowercase())
        }
        assertTrue(foundAliceResult.isSuccess)
        val foundAlice = foundAliceResult.getOrThrow()
        assertNotNull("Bob should find Alice by nickname", foundAlice)
        assertEquals(aliceUid, foundAlice!!.uid)

        // 5. Bob opens/creates direct chat with Alice
        val chatResult = withTimeout(DEFAULT_TIMEOUT_MS) {
            repository.getOrCreateDirectChat(bobProfile, foundAlice)
        }
        assertTrue("Chat creation should succeed: ${chatResult.exceptionOrNull()}", chatResult.isSuccess)
        val chat = chatResult.getOrThrow()

        // 6. Calling getOrCreateDirectChat again returns the exact same deterministic chat without duplicates
        val secondChatResult = withTimeout(DEFAULT_TIMEOUT_MS) {
            repository.getOrCreateDirectChat(bobProfile, foundAlice)
        }
        assertEquals(chat.id, secondChatResult.getOrThrow().id)

        // 7. Bob sends a message to Alice with a reply quote
        val msgResult = withTimeout(DEFAULT_TIMEOUT_MS) {
            repository.sendMessage(
                chat = chat,
                senderProfile = bobProfile,
                rawText = "Привет, Алиса! Это реальный тест.",
                replyToSender = aliceNick,
                replyToText = "Привет!"
            )
        }
        assertTrue("Message send should succeed: ${msgResult.exceptionOrNull()}", msgResult.isSuccess)

        // 8. Sign in as Alice, update Phonogramm profile info, and observe chats and real-time messages
        signInTestUser(aliceEmail)
        val profileUpdateRes = withTimeout(DEFAULT_TIMEOUT_MS) {
            repository.updateProfileInfo("Alice Lumina", "2001-05-14", "Phonogramm tester")
        }
        assertTrue("Profile update should succeed: ${profileUpdateRes.exceptionOrNull()}", profileUpdateRes.isSuccess)

        val aliceChats = withTimeout(FLOW_TIMEOUT_MS) {
            repository.observeUserChats(aliceUid).first { list -> list.any { it.id == chat.id } }
        }
        assertEquals("Привет, Алиса! Это реальный тест.", aliceChats.first { it.id == chat.id }.lastMessageText)

        val aliceMessages = withTimeout(FLOW_TIMEOUT_MS) {
            repository.observeMessages(chat.id, aliceUid).first { list -> list.isNotEmpty() }
        }
        assertEquals(1, aliceMessages.size)
        assertEquals("Привет, Алиса! Это реальный тест.", aliceMessages[0].text)
        assertEquals(bobUid, aliceMessages[0].senderId)
        assertEquals(aliceNick, aliceMessages[0].replyToSender)
        assertEquals("Привет!", aliceMessages[0].replyToText)
        assertTrue("Alice should have starter gift", aliceProfile.parsedGifts.isNotEmpty())
        assertTrue("Alice should have welcome bot message", aliceProfile.parsedSystemMessages.isNotEmpty())

        // 9. Cross-user isolation: Charlie cannot read Alice & Bob's chat or messages
        val charlieUid = signInTestUser(charlieEmail)
        try {
            withTimeout(DEFAULT_TIMEOUT_MS) {
                firestore.collection("chats").document(chat.id).get().await()
            }
            fail("Charlie should not be able to read Alice & Bob's chat")
        } catch (e: Exception) {
            val fsEx = checkNotNull(e.unwrapFirestoreException()) { "Expected FirebaseFirestoreException, got $e" }
            assertEquals(FirebaseFirestoreException.Code.PERMISSION_DENIED, fsEx.code)
        }

        try {
            withTimeout(FLOW_TIMEOUT_MS) {
                repository.observeMessages(chat.id, aliceUid).first()
            }
            fail("Charlie should not be able to observe Alice & Bob's messages")
        } catch (e: Exception) {
            val fsEx = checkNotNull(e.unwrapFirestoreException()) { "Expected FirebaseFirestoreException, got $e" }
            assertEquals(FirebaseFirestoreException.Code.PERMISSION_DENIED, fsEx.code)
        }
    }

    @Test
    fun observeUserChats_unauthenticatedCaller_failsWithPermissionDenied() = runBlocking {
        auth.signOut()
        val repository = MessengerRepository(firestore, auth)
        try {
            withTimeout(FLOW_TIMEOUT_MS) {
                repository.observeUserChats("unauth_uid").first()
            }
            fail("Unauthenticated user must not be able to observe chats")
        } catch (e: Exception) {
            val fsEx = checkNotNull(e.unwrapFirestoreException()) { "Expected FirebaseFirestoreException, got $e" }
            assertEquals(FirebaseFirestoreException.Code.PERMISSION_DENIED, fsEx.code)
        }
    }

    @Test
    fun webRtcCallSignalingLifecycle_offerAnswerIceMuteVideoBusyDeclineCancelEnd_andSecurityRules() = runBlocking {
        val suffix = UUID.randomUUID().toString().replace("-", "").take(6)
        val callerEmail = "caller_$suffix@test.com"
        val calleeEmail = "callee_$suffix@test.com"
        val intruderEmail = "intruder_$suffix@test.com"

        val callerUid = signInTestUser(callerEmail)
        val repository = MessengerRepository(firestore, auth)
        val callerProfile = withTimeout(DEFAULT_TIMEOUT_MS) {
            repository.registerNickname("Caller_$suffix")
        }.getOrThrow()

        val calleeUid = signInTestUser(calleeEmail)
        val calleeProfile = withTimeout(DEFAULT_TIMEOUT_MS) {
            repository.registerNickname("Callee_$suffix")
        }.getOrThrow()

        // 1. Caller initiates outgoing audio call
        signInTestUser(callerEmail)
        val outgoingResult = withTimeout(DEFAULT_TIMEOUT_MS) {
            repository.startOutgoingCall(caller = callerProfile, callee = calleeProfile, isVideo = false)
        }
        assertTrue("startOutgoingCall should succeed: ${outgoingResult.exceptionOrNull()}", outgoingResult.isSuccess)
        val session = outgoingResult.getOrThrow()
        assertEquals(com.example.data.model.CallSession.STATUS_RINGING, session.status)

        // 2. Caller publishes WebRTC SDP Offer and ICE candidate
        val sampleOffer = "v=0\r\no=- 1001 2 IN IP4 127.0.0.1\r\ns=-\r\nt=0 0\r\nm=audio 9 UDP/TLS/RTP/SAVPF 111\r\n"
        withTimeout(DEFAULT_TIMEOUT_MS) {
            repository.publishWebRtcOffer(session.callId, sampleOffer)
            repository.publishWebRtcIceCandidate(
                callId = session.callId,
                isCaller = true,
                candidateJson = """{"sdpMid":"0","sdpMLineIndex":0,"candidate":"candidate:1 1 udp 2122260223 192.168.1.2 50000 typ host"}"""
            )
        }

        // 3. Callee observes incoming call with Offer SDP & Caller ICE candidate, then accepts and publishes Answer SDP
        signInTestUser(calleeEmail)
        val observedRinging = withTimeout(FLOW_TIMEOUT_MS) {
            repository.observeCallSession(session.callId).first { it != null && it.offerSdp.isNotBlank() }
        }
        assertNotNull(observedRinging)
        assertEquals(sampleOffer, observedRinging!!.offerSdp)
        assertEquals(1, observedRinging.callerCandidates.size)

        val sampleAnswer = "v=0\r\no=- 2002 2 IN IP4 127.0.0.1\r\ns=-\r\nt=0 0\r\nm=audio 9 UDP/TLS/RTP/SAVPF 111\r\n"
        withTimeout(DEFAULT_TIMEOUT_MS) {
            repository.updateCallStatus(session.callId, com.example.data.model.CallSession.STATUS_ACCEPTED, calleeVideoOnAccept = false)
            repository.publishWebRtcAnswer(session.callId, sampleAnswer, calleeVideoEnabled = false)
            repository.publishWebRtcIceCandidate(
                callId = session.callId,
                isCaller = false,
                candidateJson = """{"sdpMid":"0","sdpMLineIndex":0,"candidate":"candidate:2 1 udp 2122260223 192.168.1.3 50001 typ host"}"""
            )
            repository.updateCallMuteState(session.callId, isCaller = false, muted = true)
            repository.updateCallVideoState(session.callId, isCaller = false, videoEnabled = true)
        }

        // 4. Caller observes ACCEPTED state, Answer SDP, Callee ICE candidate, mute & video flags
        signInTestUser(callerEmail)
        val observedAccepted = withTimeout(FLOW_TIMEOUT_MS) {
            repository.observeCallSession(session.callId).first {
                it != null &&
                    it.status == com.example.data.model.CallSession.STATUS_ACCEPTED &&
                    it.answerSdp.isNotBlank() &&
                    it.calleeMuted &&
                    it.calleeVideoEnabled
            }
        }
        assertNotNull(observedAccepted)
        assertEquals(sampleAnswer, observedAccepted!!.answerSdp)
        assertEquals(1, observedAccepted.calleeCandidates.size)
        assertTrue(observedAccepted.peerMuted(callerUid))
        assertTrue(observedAccepted.peerVideoEnabled(callerUid))

        // 5. Non-participant intruder cannot read or modify the call document
        val intruderUid = signInTestUser(intruderEmail)
        try {
            withTimeout(DEFAULT_TIMEOUT_MS) {
                firestore.collection("calls").document(session.callId).get().await()
            }
            fail("Non-participant intruder ($intruderUid) must not be able to read call document")
        } catch (e: Exception) {
            val fsEx = checkNotNull(e.unwrapFirestoreException()) { "Expected FirebaseFirestoreException, got $e" }
            assertEquals(FirebaseFirestoreException.Code.PERMISSION_DENIED, fsEx.code)
        }

        // 6. Callee ends the call -> status transitions to ENDED for both participants
        signInTestUser(calleeEmail)
        withTimeout(DEFAULT_TIMEOUT_MS) {
            repository.updateCallStatus(session.callId, com.example.data.model.CallSession.STATUS_ENDED)
        }
        val endedSnap = withTimeout(FLOW_TIMEOUT_MS) {
            repository.observeCallSession(session.callId).first {
                it?.status == com.example.data.model.CallSession.STATUS_ENDED
            }
        }
        assertNotNull(endedSnap)
    }

    private companion object {
        const val DEFAULT_TIMEOUT_MS = 5000L
        const val FLOW_TIMEOUT_MS = 4000L
    }
}
