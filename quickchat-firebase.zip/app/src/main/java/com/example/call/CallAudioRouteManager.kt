package com.example.call

import android.content.Context
import android.media.AudioAttributes
import android.media.AudioDeviceInfo
import android.media.AudioFocusRequest
import android.media.AudioManager
import android.os.Build
import java.util.concurrent.atomic.AtomicBoolean

/**
 * Dedicated Android communication audio route & focus controller for WebRTC voice/video calls.
 * - Acquires exclusive voice communication audio focus.
 * - Configures [AudioManager.MODE_IN_COMMUNICATION] for hardware echo cancellation & low-latency voice routing.
 * - Switches between speakerphone, earpiece, Bluetooth SCO, and wired headsets.
 * - Guarantees complete restoration of system audio state when the call ends or fails.
 */
class CallAudioRouteManager(context: Context) {
    private val appContext = context.applicationContext
    private val audioManager = appContext.getSystemService(Context.AUDIO_SERVICE) as? AudioManager

    private val isAcquired = AtomicBoolean(false)
    private var savedMode: Int = AudioManager.MODE_NORMAL
    private var savedSpeakerphoneOn: Boolean = false
    private var savedMicrophoneMute: Boolean = false
    private var focusRequest: AudioFocusRequest? = null

    private val focusChangeListener = AudioManager.OnAudioFocusChangeListener { _ -> }

    /**
     * Activates communication audio mode and routes output according to [enableSpeakerphone].
     */
    fun acquireCallAudioRoute(enableSpeakerphone: Boolean = true) {
        val am = audioManager ?: return
        if (!isAcquired.getAndSet(true)) {
            try {
                savedMode = am.mode
                @Suppress("DEPRECATION")
                savedSpeakerphoneOn = am.isSpeakerphoneOn
                savedMicrophoneMute = am.isMicrophoneMute
            } catch (_: Exception) {
            }

            requestCommunicationAudioFocus(am)

            try {
                am.mode = AudioManager.MODE_IN_COMMUNICATION
                am.isMicrophoneMute = false
                ensureAudibleVoiceVolume(am)
            } catch (_: Exception) {
            }
        }
        setSpeakerphoneEnabled(enableSpeakerphone)
    }

    /**
     * Switches between speakerphone and earpiece (respecting active Bluetooth/wired headset if earpiece is selected).
     */
    fun setSpeakerphoneEnabled(enabled: Boolean) {
        val am = audioManager ?: return
        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
                val availableDevices = am.availableCommunicationDevices
                val targetDevice = if (enabled) {
                    availableDevices.firstOrNull { it.type == AudioDeviceInfo.TYPE_BUILTIN_SPEAKER }
                } else {
                    availableDevices.firstOrNull {
                        it.type == AudioDeviceInfo.TYPE_BLUETOOTH_SCO ||
                            it.type == AudioDeviceInfo.TYPE_BLE_HEADSET ||
                            it.type == AudioDeviceInfo.TYPE_WIRED_HEADSET ||
                            it.type == AudioDeviceInfo.TYPE_WIRED_HEADPHONES ||
                            it.type == AudioDeviceInfo.TYPE_USB_HEADSET
                    } ?: availableDevices.firstOrNull {
                        it.type == AudioDeviceInfo.TYPE_BUILTIN_EARPIECE
                    }
                }
                if (targetDevice != null) {
                    am.setCommunicationDevice(targetDevice)
                }
            }
            @Suppress("DEPRECATION")
            am.isSpeakerphoneOn = enabled
        } catch (_: Exception) {
            try {
                @Suppress("DEPRECATION")
                am.isSpeakerphoneOn = enabled
            } catch (_: Exception) {
            }
        }
    }

    /**
     * Releases communication audio mode, clears communication device, and restores previous Android audio state.
     */
    fun releaseCallAudioRoute() {
        if (!isAcquired.getAndSet(false)) return
        val am = audioManager ?: return
        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
                am.clearCommunicationDevice()
            }
        } catch (_: Exception) {
        }
        try {
            @Suppress("DEPRECATION")
            am.isSpeakerphoneOn = savedSpeakerphoneOn
            am.isMicrophoneMute = savedMicrophoneMute
            am.mode = savedMode
        } catch (_: Exception) {
        }
        abandonCommunicationAudioFocus(am)
    }

    fun isAudioRouteActive(): Boolean = isAcquired.get()

    private fun requestCommunicationAudioFocus(am: AudioManager) {
        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                val attrs = AudioAttributes.Builder()
                    .setUsage(AudioAttributes.USAGE_VOICE_COMMUNICATION)
                    .setContentType(AudioAttributes.CONTENT_TYPE_SPEECH)
                    .build()
                val req = AudioFocusRequest.Builder(AudioManager.AUDIOFOCUS_GAIN_TRANSIENT_EXCLUSIVE)
                    .setAudioAttributes(attrs)
                    .setAcceptsDelayedFocusGain(false)
                    .setOnAudioFocusChangeListener(focusChangeListener)
                    .build()
                focusRequest = req
                am.requestAudioFocus(req)
            } else {
                @Suppress("DEPRECATION")
                am.requestAudioFocus(
                    focusChangeListener,
                    AudioManager.STREAM_VOICE_CALL,
                    AudioManager.AUDIOFOCUS_GAIN_TRANSIENT_EXCLUSIVE
                )
            }
        } catch (_: Exception) {
        }
    }

    private fun abandonCommunicationAudioFocus(am: AudioManager) {
        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                focusRequest?.let { am.abandonAudioFocusRequest(it) }
                focusRequest = null
            } else {
                @Suppress("DEPRECATION")
                am.abandonAudioFocus(focusChangeListener)
            }
        } catch (_: Exception) {
        }
    }

    private fun ensureAudibleVoiceVolume(am: AudioManager) {
        try {
            val maxVoice = am.getStreamMaxVolume(AudioManager.STREAM_VOICE_CALL)
            val curVoice = am.getStreamVolume(AudioManager.STREAM_VOICE_CALL)
            if (maxVoice > 0 && curVoice <= 1) {
                am.setStreamVolume(
                    AudioManager.STREAM_VOICE_CALL,
                    (maxVoice * 0.75).toInt().coerceAtLeast(2),
                    0
                )
            }
        } catch (_: Exception) {
        }
    }
}
