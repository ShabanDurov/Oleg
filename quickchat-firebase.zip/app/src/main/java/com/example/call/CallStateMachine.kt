package com.example.call

import com.example.data.model.CallSession
import org.json.JSONObject

/**
 * Deterministic states for the real-time WebRTC call lifecycle.
 */
enum class CallPhase {
    IDLE,
    OUTGOING,
    INCOMING,
    CONNECTING,
    ACTIVE,
    RECONNECTING,
    ENDING,
    ENDED
}

/**
 * Explicit reason why a call session ended.
 */
enum class CallEndReason(val russianTitle: String) {
    NONE(""),
    HANGUP_LOCAL("Звонок завершён"),
    HANGUP_REMOTE("Собеседник завершил звонок"),
    DECLINED_LOCAL("Вы отклонили вызов"),
    DECLINED_REMOTE("Абонент отклонил вызов"),
    CANCELLED_LOCAL("Вызов отменён"),
    CANCELLED_REMOTE("Вызов отменён собеседником"),
    NO_ANSWER_TIMEOUT("Абонент не отвечает"),
    BUSY("Абонент занят в другом звонке"),
    PERMISSION_DENIED("Нет доступа к микрофону"),
    NETWORK_FAILURE("Соединение прервано из-за ошибки сети"),
    ERROR("Не удалось установить соединение")
}

/**
 * Immutable UI & domain model representing the current state of the call engine.
 */
data class CallUiModel(
    val phase: CallPhase = CallPhase.IDLE,
    val session: CallSession? = null,
    val isIncoming: Boolean = false,
    val isMuted: Boolean = false,
    val isPeerMuted: Boolean = false,
    val isSpeakerOn: Boolean = true,
    val isLocalVideoEnabled: Boolean = false,
    val isRemoteVideoEnabled: Boolean = false,
    val useFrontCamera: Boolean = true,
    val isMinimized: Boolean = false,
    val elapsedSeconds: Int = 0,
    val micLevel: Float = 0f,
    val statusTextOverride: String = "",
    val endReason: CallEndReason = CallEndReason.NONE
) {
    val isCallVisible: Boolean
        get() = phase != CallPhase.IDLE && session != null

    val isOngoingMediaPhase: Boolean
        get() = phase == CallPhase.CONNECTING || phase == CallPhase.ACTIVE || phase == CallPhase.RECONNECTING

    val formattedElapsedTime: String
        get() = "%02d:%02d".format(elapsedSeconds / 60, elapsedSeconds % 60)

    fun formattedStatusLabel(): String {
        if (statusTextOverride.isNotBlank()) return statusTextOverride
        return when (phase) {
            CallPhase.IDLE -> ""
            CallPhase.OUTGOING -> "Вызов абонента..."
            CallPhase.INCOMING -> if (session?.isVideo == true) "Входящий видеозвонок..." else "Входящий аудиозвонок..."
            CallPhase.CONNECTING -> "Установка защищённого WebRTC-соединения..."
            CallPhase.ACTIVE -> {
                val mins = elapsedSeconds / 60
                val secs = elapsedSeconds % 60
                "%02d:%02d • HD Voice (Opus)".format(mins, secs)
            }
            CallPhase.RECONNECTING -> "Переподключение медиапотока..."
            CallPhase.ENDING -> endReason.russianTitle.ifBlank { "Завершение вызова..." }
            CallPhase.ENDED -> endReason.russianTitle.ifBlank { "Звонок завершён" }
        }
    }
}

/**
 * Compact JSON representation of a WebRTC ICE Candidate stored in Firestore `/calls/{callId}`.
 */
data class IceCandidatePayload(
    val sdpMid: String,
    val sdpMLineIndex: Int,
    val sdp: String
) {
    fun toJsonString(): String {
        val obj = JSONObject()
        obj.put("sdpMid", sdpMid)
        obj.put("sdpMLineIndex", sdpMLineIndex)
        obj.put("sdp", sdp)
        obj.put("candidate", sdp)
        return obj.toString()
    }

    companion object {
        fun fromJsonString(raw: String): IceCandidatePayload? {
            if (raw.isBlank()) return null
            return try {
                val obj = JSONObject(raw)
                val sdp = obj.optString("sdp", "").ifBlank {
                    obj.optString("candidate", "")
                }
                if (sdp.isBlank()) return null
                IceCandidatePayload(
                    sdpMid = obj.optString("sdpMid", "0"),
                    sdpMLineIndex = obj.optInt("sdpMLineIndex", 0),
                    sdp = sdp
                )
            } catch (_: Exception) {
                null
            }
        }
    }
}

/**
 * Pure state-transition validator and reducer for the call state machine.
 * Guarantees deterministic transitions and prevents invalid state jumps or race conditions.
 */
object CallStateReducer {

    fun canStartNewCall(currentPhase: CallPhase): Boolean {
        return currentPhase == CallPhase.IDLE || currentPhase == CallPhase.ENDED
    }

    fun canAcceptIncomingCall(currentPhase: CallPhase): Boolean {
        return currentPhase == CallPhase.INCOMING
    }

    fun transitionToOutgoing(session: CallSession, isVideo: Boolean): CallUiModel {
        return CallUiModel(
            phase = CallPhase.OUTGOING,
            session = session,
            isIncoming = false,
            isMuted = false,
            isPeerMuted = false,
            isSpeakerOn = true,
            isLocalVideoEnabled = isVideo,
            isRemoteVideoEnabled = false,
            useFrontCamera = true,
            isMinimized = false,
            elapsedSeconds = 0,
            endReason = CallEndReason.NONE
        )
    }

    fun transitionToIncoming(session: CallSession): CallUiModel {
        return CallUiModel(
            phase = CallPhase.INCOMING,
            session = session,
            isIncoming = true,
            isMuted = false,
            isPeerMuted = session.callerMuted,
            isSpeakerOn = true,
            isLocalVideoEnabled = false,
            isRemoteVideoEnabled = session.callerVideoEnabled,
            useFrontCamera = true,
            isMinimized = false,
            elapsedSeconds = 0,
            endReason = CallEndReason.NONE
        )
    }

    fun transitionToConnecting(
        current: CallUiModel,
        session: CallSession,
        localVideoEnabled: Boolean,
        remoteVideoEnabled: Boolean
    ): CallUiModel {
        return current.copy(
            phase = CallPhase.CONNECTING,
            session = session,
            isIncoming = false,
            isLocalVideoEnabled = localVideoEnabled,
            isRemoteVideoEnabled = remoteVideoEnabled,
            statusTextOverride = "",
            endReason = CallEndReason.NONE
        )
    }

    fun transitionToActive(current: CallUiModel): CallUiModel {
        if (current.phase == CallPhase.ENDING || current.phase == CallPhase.ENDED || current.phase == CallPhase.IDLE) {
            return current
        }
        return current.copy(
            phase = CallPhase.ACTIVE,
            isIncoming = false,
            statusTextOverride = "",
            endReason = CallEndReason.NONE
        )
    }

    fun transitionToReconnecting(current: CallUiModel): CallUiModel {
        if (current.phase != CallPhase.ACTIVE && current.phase != CallPhase.CONNECTING) {
            return current
        }
        return current.copy(
            phase = CallPhase.RECONNECTING,
            statusTextOverride = "Связь нестабильна • переподключение..."
        )
    }

    fun transitionToEnding(current: CallUiModel, reason: CallEndReason): CallUiModel {
        if (current.phase == CallPhase.IDLE) return current
        return current.copy(
            phase = CallPhase.ENDING,
            isIncoming = false,
            isLocalVideoEnabled = false,
            isRemoteVideoEnabled = false,
            isMinimized = false,
            statusTextOverride = reason.russianTitle,
            endReason = reason
        )
    }

    fun transitionToIdle(): CallUiModel = CallUiModel(phase = CallPhase.IDLE)
}
