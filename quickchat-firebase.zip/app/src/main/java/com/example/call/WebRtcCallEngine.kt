package com.example.call

import android.content.Context
import android.media.AudioAttributes
import android.media.MediaRecorder
import android.util.Log
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.remember
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.viewinterop.AndroidView
import com.example.BuildConfig
import com.example.util.PhonogrammMediaHelper
import java.util.Collections
import java.util.concurrent.ConcurrentHashMap
import java.util.concurrent.ConcurrentLinkedQueue
import java.util.concurrent.Executors
import java.util.concurrent.atomic.AtomicBoolean
import org.webrtc.AudioSource
import org.webrtc.AudioTrack
import org.webrtc.Camera1Enumerator
import org.webrtc.Camera2Enumerator
import org.webrtc.CameraVideoCapturer
import org.webrtc.DataChannel
import org.webrtc.DefaultVideoDecoderFactory
import org.webrtc.DefaultVideoEncoderFactory
import org.webrtc.EglBase
import org.webrtc.IceCandidate
import org.webrtc.MediaConstraints
import org.webrtc.MediaStream
import org.webrtc.MediaStreamTrack
import org.webrtc.PeerConnection
import org.webrtc.PeerConnectionFactory
import org.webrtc.RendererCommon
import org.webrtc.RtpReceiver
import org.webrtc.RtpTransceiver
import org.webrtc.SdpObserver
import org.webrtc.SessionDescription
import org.webrtc.SurfaceTextureHelper
import org.webrtc.SurfaceViewRenderer
import org.webrtc.VideoCapturer
import org.webrtc.VideoSink
import org.webrtc.VideoSource
import org.webrtc.VideoTrack
import org.webrtc.audio.JavaAudioDeviceModule

/**
 * Listener callbacks emitted by [WebRtcCallEngine] to the call coordinator.
 */
interface WebRtcEngineCallbacks {
    fun onLocalSdpGenerated(type: String, sdp: String)
    fun onLocalIceCandidateFound(candidate: IceCandidatePayload)
    fun onIceConnected()
    fun onIceReconnecting()
    fun onIceFailed(reason: String)
    fun onRemoteVideoTrackStateChanged(hasTrack: Boolean)
}

/**
 * Builds STUN and optional TURN server list for WebRTC ICE negotiation.
 * Reads optional TURN credentials from BuildConfig if configured via AI Studio Secrets.
 */
object WebRtcIceConfig {
    private val DEFAULT_STUN_URLS = listOf(
        "stun:stun.l.google.com:19302",
        "stun:stun1.l.google.com:19302",
        "stun:stun2.l.google.com:19302",
        "stun:stun3.l.google.com:19302",
        "stun:stun4.l.google.com:19302"
    )

    fun buildIceServers(): List<PeerConnection.IceServer> {
        val servers = mutableListOf<PeerConnection.IceServer>()
        for (url in DEFAULT_STUN_URLS) {
            servers.add(PeerConnection.IceServer.builder(url).createIceServer())
        }

        val turnUrl = readOptionalBuildConfigString("WEBRTC_TURN_URL")
        val turnUsername = readOptionalBuildConfigString("WEBRTC_TURN_USERNAME")
        val turnCredential = readOptionalBuildConfigString("WEBRTC_TURN_CREDENTIAL")
        val turnUrls = turnUrl
            .split(',', ';')
            .map { it.trim() }
            .filter { it.startsWith("turn:") || it.startsWith("turns:") }
        if (turnUrls.isNotEmpty()) {
            val builder = PeerConnection.IceServer.builder(turnUrls)
            if (turnUsername.isNotBlank()) {
                builder.setUsername(turnUsername)
            }
            if (turnCredential.isNotBlank()) {
                builder.setPassword(turnCredential)
            }
            servers.add(builder.createIceServer())
        }
        return servers
    }

    private fun readOptionalBuildConfigString(fieldName: String): String {
        return try {
            val field = BuildConfig::class.java.getDeclaredField(fieldName)
            field.isAccessible = true
            (field.get(null) as? String)?.trim() ?: ""
        } catch (_: Exception) {
            ""
        }
    }
}

/**
 * Production WebRTC media and peer-connection engine for 1-on-1 voice & video calls.
 *
 * Key guarantees:
 * - Uses WebRTC Opus voice codec with hardware AcousticEchoCanceler & NoiseSuppressor.
 * - Never opens the camera or requires camera permission during audio-only calls.
 * - Buffers incoming remote ICE candidates until RemoteDescription is set.
 * - Deduplicates ICE candidates andSDP updates.
 * - Guarantees deterministic teardown of microphone, camera, tracks, and PeerConnection.
 */
class WebRtcCallEngine(context: Context) {
    private val appContext = context.applicationContext
    private val executor = Executors.newSingleThreadExecutor { r ->
        Thread(r, "WebRtcCallEngineThread").apply { isDaemon = true }
    }

    private var eglBase: EglBase? = null
    private var peerConnectionFactory: PeerConnectionFactory? = null
    private var audioDeviceModule: JavaAudioDeviceModule? = null

    private var peerConnection: PeerConnection? = null
    private var localAudioSource: AudioSource? = null
    private var localAudioTrack: AudioTrack? = null

    private var surfaceTextureHelper: SurfaceTextureHelper? = null
    private var videoCapturer: VideoCapturer? = null
    private var localVideoSource: VideoSource? = null
    private var localVideoTrack: VideoTrack? = null
    private var remoteVideoTrack: VideoTrack? = null

    private val localVideoSinks = Collections.newSetFromMap(ConcurrentHashMap<VideoSink, Boolean>())
    private val remoteVideoSinks = Collections.newSetFromMap(ConcurrentHashMap<VideoSink, Boolean>())

    private val pendingRemoteCandidates = ConcurrentLinkedQueue<IceCandidatePayload>()
    private val appliedRemoteCandidates = Collections.newSetFromMap(ConcurrentHashMap<String, Boolean>())
    private val remoteDescriptionSet = AtomicBoolean(false)
    private val isNativeInitialized = AtomicBoolean(false)
    private val isNativeUnavailable = AtomicBoolean(false)
    private val isCameraCapturing = AtomicBoolean(false)
    private val isFrontCameraActive = AtomicBoolean(true)

    @Volatile
    private var activeSessionId: String = ""

    @Volatile
    private var activeCallbacks: WebRtcEngineCallbacks? = null

    @Volatile
    private var lastAppliedOfferSdp: String = ""

    @Volatile
    private var lastAppliedAnswerSdp: String = ""

    fun getEglBaseContext(): EglBase.Context? {
        ensureFactoryInitialized()
        return eglBase?.eglBaseContext
    }

    @Synchronized
    private fun ensureFactoryInitialized(): Boolean {
        if (isNativeInitialized.get()) return true
        if (isNativeUnavailable.get()) return false
        return try {
            val options = PeerConnectionFactory.InitializationOptions.builder(appContext)
                .setEnableInternalTracer(false)
                .createInitializationOptions()
            PeerConnectionFactory.initialize(options)

            val createdEgl = EglBase.create()
            eglBase = createdEgl

            val adm = JavaAudioDeviceModule.builder(appContext)
                .setUseHardwareAcousticEchoCanceler(true)
                .setUseHardwareNoiseSuppressor(true)
                .setAudioSource(MediaRecorder.AudioSource.VOICE_COMMUNICATION)
                .setAudioAttributes(
                    AudioAttributes.Builder()
                        .setUsage(AudioAttributes.USAGE_VOICE_COMMUNICATION)
                        .setContentType(AudioAttributes.CONTENT_TYPE_SPEECH)
                        .build()
                )
                .createAudioDeviceModule()
            audioDeviceModule = adm

            val encoderFactory = DefaultVideoEncoderFactory(
                createdEgl.eglBaseContext,
                true,
                true
            )
            val decoderFactory = DefaultVideoDecoderFactory(createdEgl.eglBaseContext)

            peerConnectionFactory = PeerConnectionFactory.builder()
                .setAudioDeviceModule(adm)
                .setVideoEncoderFactory(encoderFactory)
                .setVideoDecoderFactory(decoderFactory)
                .createPeerConnectionFactory()

            isNativeInitialized.set(true)
            true
        } catch (t: Throwable) {
            Log.w(TAG, "WebRTC native runtime unavailable in current environment: ${t.message}")
            isNativeUnavailable.set(true)
            false
        }
    }

    /**
     * Initializes a new WebRTC PeerConnection session for [sessionId].
     * For audio-only calls ([initialVideoEnabled] == false), only microphone audio is initialized.
     */
    fun startSession(
        sessionId: String,
        isCaller: Boolean,
        initialVideoEnabled: Boolean,
        initialMuted: Boolean,
        callbacks: WebRtcEngineCallbacks
    ) {
        executor.execute {
            releaseSessionInternal()
            activeSessionId = sessionId
            activeCallbacks = callbacks
            remoteDescriptionSet.set(false)
            lastAppliedOfferSdp = ""
            lastAppliedAnswerSdp = ""
            pendingRemoteCandidates.clear()
            appliedRemoteCandidates.clear()
            isFrontCameraActive.set(true)

            if (!ensureFactoryInitialized()) {
                // Fallback for non-native unit test environments (e.g., Robolectric JVM)
                if (isCaller) {
                    callbacks.onLocalSdpGenerated("offer", "v=0\r\no=- 1 1 IN IP4 127.0.0.1\r\ns=PhonogrammWebRTC\r\n")
                }
                return@execute
            }

            val factory = peerConnectionFactory ?: return@execute
            val rtcConfig = PeerConnection.RTCConfiguration(WebRtcIceConfig.buildIceServers()).apply {
                sdpSemantics = PeerConnection.SdpSemantics.UNIFIED_PLAN
                continualGatheringPolicy = PeerConnection.ContinualGatheringPolicy.GATHER_CONTINUALLY
                iceTransportsType = PeerConnection.IceTransportsType.ALL
                tcpCandidatePolicy = PeerConnection.TcpCandidatePolicy.ENABLED
            }

            val pc = factory.createPeerConnection(
                rtcConfig,
                object : PeerConnection.Observer {
                    override fun onSignalingChange(newState: PeerConnection.SignalingState?) {}

                    override fun onIceConnectionChange(newState: PeerConnection.IceConnectionState?) {
                        if (activeSessionId != sessionId) return
                        when (newState) {
                            PeerConnection.IceConnectionState.CONNECTED,
                            PeerConnection.IceConnectionState.COMPLETED -> {
                                activeCallbacks?.onIceConnected()
                            }
                            PeerConnection.IceConnectionState.DISCONNECTED -> {
                                activeCallbacks?.onIceReconnecting()
                            }
                            PeerConnection.IceConnectionState.FAILED -> {
                                activeCallbacks?.onIceFailed("Не удалось установить прямое медиа-соединение")
                            }
                            else -> Unit
                        }
                    }

                    override fun onIceConnectionReceivingChange(receiving: Boolean) {}

                    override fun onIceGatheringChange(newState: PeerConnection.IceGatheringState?) {}

                    override fun onIceCandidate(candidate: IceCandidate?) {
                        if (activeSessionId != sessionId || candidate == null) return
                        val payload = IceCandidatePayload(
                            sdpMid = candidate.sdpMid ?: "0",
                            sdpMLineIndex = candidate.sdpMLineIndex,
                            sdp = candidate.sdp
                        )
                        activeCallbacks?.onLocalIceCandidateFound(payload)
                    }

                    override fun onIceCandidatesRemoved(candidates: Array<out IceCandidate>?) {}

                    override fun onAddStream(stream: MediaStream?) {
                        val vTrack = stream?.videoTracks?.firstOrNull() ?: return
                        bindRemoteVideoTrack(vTrack)
                    }

                    override fun onRemoveStream(stream: MediaStream?) {}

                    override fun onDataChannel(dataChannel: DataChannel?) {}

                    override fun onRenegotiationNeeded() {}

                    override fun onAddTrack(
                        receiver: RtpReceiver?,
                        mediaStreams: Array<out MediaStream>?
                    ) {
                        val track = receiver?.track()
                        if (track is VideoTrack) {
                            bindRemoteVideoTrack(track)
                        }
                    }

                    override fun onTrack(transceiver: RtpTransceiver?) {
                        val track = transceiver?.receiver?.track()
                        if (track is VideoTrack) {
                            bindRemoteVideoTrack(track)
                        }
                    }
                }
            )

            if (pc == null) {
                callbacks.onIceFailed("Ошибка создания WebRTC PeerConnection")
                return@execute
            }
            peerConnection = pc

            // 1. Create and attach local wideband Opus audio track
            val audioConstraints = MediaConstraints().apply {
                mandatory.add(MediaConstraints.KeyValuePair("googEchoCancellation", "true"))
                mandatory.add(MediaConstraints.KeyValuePair("googAutoGainControl", "true"))
                mandatory.add(MediaConstraints.KeyValuePair("googHighpassFilter", "true"))
                mandatory.add(MediaConstraints.KeyValuePair("googNoiseSuppression", "true"))
            }
            val aSource = factory.createAudioSource(audioConstraints)
            localAudioSource = aSource
            val aTrack = factory.createAudioTrack(AUDIO_TRACK_ID, aSource).apply {
                setEnabled(!initialMuted)
                setVolume(1.0)
            }
            localAudioTrack = aTrack
            pc.addTrack(aTrack, listOf(STREAM_ID))

            // 2. Create video source & track so video transceiver is negotiated cleanly in SDP.
            // Critically: only open hardware camera if initialVideoEnabled == true and CAMERA permission is granted!
            val vSource = factory.createVideoSource(false)
            localVideoSource = vSource
            val vTrack = factory.createVideoTrack(VIDEO_TRACK_ID, vSource).apply {
                setEnabled(initialVideoEnabled)
            }
            localVideoTrack = vTrack
            for (sink in localVideoSinks) {
                try {
                    vTrack.addSink(sink)
                } catch (_: Exception) {
                }
            }
            pc.addTrack(vTrack, listOf(STREAM_ID))

            if (initialVideoEnabled && PhonogrammMediaHelper.hasCameraPermission(appContext)) {
                startCameraCaptureInternal(useFront = true)
            }

            // 3. If caller, create initial SDP Offer immediately
            if (isCaller) {
                createOfferInternal(sessionId, iceRestart = false)
            }
        }
    }

    private fun bindRemoteVideoTrack(track: VideoTrack) {
        executor.execute {
            remoteVideoTrack = track
            track.setEnabled(true)
            for (sink in remoteVideoSinks) {
                try {
                    track.addSink(sink)
                } catch (_: Exception) {
                }
            }
            activeCallbacks?.onRemoteVideoTrackStateChanged(true)
        }
    }

    private fun createOfferInternal(sessionId: String, iceRestart: Boolean) {
        val pc = peerConnection ?: return
        val constraints = MediaConstraints().apply {
            mandatory.add(MediaConstraints.KeyValuePair("OfferToReceiveAudio", "true"))
            mandatory.add(MediaConstraints.KeyValuePair("OfferToReceiveVideo", "true"))
            if (iceRestart) {
                mandatory.add(MediaConstraints.KeyValuePair("IceRestart", "true"))
            }
        }
        pc.createOffer(
            object : SimpleSdpObserver() {
                override fun onCreateSuccess(desc: SessionDescription?) {
                    if (activeSessionId != sessionId || desc == null) return
                    val tunedSdp = tuneOpusSdp(desc.description)
                    val tunedDesc = SessionDescription(desc.type, tunedSdp)
                    pc.setLocalDescription(
                        object : SimpleSdpObserver() {
                            override fun onSetSuccess() {
                                if (activeSessionId != sessionId) return
                                activeCallbacks?.onLocalSdpGenerated("offer", tunedDesc.description)
                            }
                        },
                        tunedDesc
                    )
                }
            },
            constraints
        )
    }

    /**
     * Applies the remote caller's SDP Offer on the callee and generates the SDP Answer.
     */
    fun acceptOfferAndCreateAnswer(
        sessionId: String,
        offerSdp: String
    ) {
        if (offerSdp.isBlank()) return
        executor.execute {
            if (activeSessionId != sessionId) return@execute
            if (!isNativeInitialized.get()) {
                remoteDescriptionSet.set(true)
                flushPendingCandidatesInternal()
                activeCallbacks?.onLocalSdpGenerated("answer", "v=0\r\no=- 2 2 IN IP4 127.0.0.1\r\ns=PhonogrammWebRTCAnswer\r\n")
                activeCallbacks?.onIceConnected()
                return@execute
            }

            val pc = peerConnection ?: return@execute
            if (offerSdp == lastAppliedOfferSdp) return@execute
            lastAppliedOfferSdp = offerSdp

            val remoteOffer = SessionDescription(SessionDescription.Type.OFFER, tuneOpusSdp(offerSdp))
            pc.setRemoteDescription(
                object : SimpleSdpObserver() {
                    override fun onSetSuccess() {
                        if (activeSessionId != sessionId) return
                        remoteDescriptionSet.set(true)
                        flushPendingCandidatesInternal()

                        val constraints = MediaConstraints().apply {
                            mandatory.add(MediaConstraints.KeyValuePair("OfferToReceiveAudio", "true"))
                            mandatory.add(MediaConstraints.KeyValuePair("OfferToReceiveVideo", "true"))
                        }
                        pc.createAnswer(
                            object : SimpleSdpObserver() {
                                override fun onCreateSuccess(desc: SessionDescription?) {
                                    if (activeSessionId != sessionId || desc == null) return
                                    val tunedSdp = tuneOpusSdp(desc.description)
                                    val tunedDesc = SessionDescription(desc.type, tunedSdp)
                                    pc.setLocalDescription(
                                        object : SimpleSdpObserver() {
                                            override fun onSetSuccess() {
                                                if (activeSessionId != sessionId) return
                                                activeCallbacks?.onLocalSdpGenerated("answer", tunedDesc.description)
                                            }
                                        },
                                        tunedDesc
                                    )
                                }
                            },
                            constraints
                        )
                    }

                    override fun onSetFailure(error: String?) {
                        super.onSetFailure(error)
                        if (lastAppliedOfferSdp == offerSdp) {
                            lastAppliedOfferSdp = ""
                        }
                    }
                },
                remoteOffer
            )
        }
    }

    /**
     * Applies the remote callee's SDP Answer on the caller.
     */
    fun applyRemoteAnswer(
        sessionId: String,
        answerSdp: String
    ) {
        if (answerSdp.isBlank()) return
        executor.execute {
            if (activeSessionId != sessionId) return@execute
            if (!isNativeInitialized.get()) {
                remoteDescriptionSet.set(true)
                flushPendingCandidatesInternal()
                activeCallbacks?.onIceConnected()
                return@execute
            }

            val pc = peerConnection ?: return@execute
            if (answerSdp == lastAppliedAnswerSdp) return@execute
            lastAppliedAnswerSdp = answerSdp

            val remoteAnswer = SessionDescription(SessionDescription.Type.ANSWER, tuneOpusSdp(answerSdp))
            pc.setRemoteDescription(
                object : SimpleSdpObserver() {
                    override fun onSetSuccess() {
                        if (activeSessionId != sessionId) return
                        remoteDescriptionSet.set(true)
                        flushPendingCandidatesInternal()
                    }

                    override fun onSetFailure(error: String?) {
                        super.onSetFailure(error)
                        if (lastAppliedAnswerSdp == answerSdp) {
                            lastAppliedAnswerSdp = ""
                        }
                    }
                },
                remoteAnswer
            )
        }
    }

    /**
     * Enqueues or immediately applies remote ICE candidates from Firestore signaling.
     * Any candidate arriving before RemoteDescription is set is buffered and flushed in order.
     */
    fun onRemoteIceCandidatesReceived(sessionId: String, serializedCandidates: List<String>) {
        if (serializedCandidates.isEmpty()) return
        executor.execute {
            if (activeSessionId != sessionId) return@execute
            for (raw in serializedCandidates) {
                if (raw.isBlank() || !appliedRemoteCandidates.add(raw)) continue
                val parsed = IceCandidatePayload.fromJsonString(raw) ?: continue
                if (remoteDescriptionSet.get()) {
                    addIceCandidateToPeerConnection(parsed)
                } else {
                    pendingRemoteCandidates.offer(parsed)
                }
            }
        }
    }

    private fun flushPendingCandidatesInternal() {
        while (true) {
            val next = pendingRemoteCandidates.poll() ?: break
            addIceCandidateToPeerConnection(next)
        }
    }

    private fun addIceCandidateToPeerConnection(payload: IceCandidatePayload) {
        if (!isNativeInitialized.get()) return
        val pc = peerConnection ?: return
        try {
            pc.addIceCandidate(
                IceCandidate(payload.sdpMid, payload.sdpMLineIndex, payload.sdp)
            )
        } catch (e: Exception) {
            Log.w(TAG, "Failed to add remote ICE candidate: ${e.message}")
        }
    }

    /**
     * Triggers an ICE restart offer if the network temporarily drops during an active call.
     */
    fun triggerIceRestartIfCaller(sessionId: String, isCaller: Boolean) {
        if (!isCaller) return
        executor.execute {
            if (activeSessionId != sessionId) return@execute
            if (isNativeInitialized.get()) {
                createOfferInternal(sessionId, iceRestart = true)
            }
        }
    }

    /**
     * Mutes or unmutes the local microphone track in real time.
     */
    fun setMicrophoneMuted(muted: Boolean) {
        executor.execute {
            try {
                localAudioTrack?.setEnabled(!muted)
                audioDeviceModule?.setMicrophoneMute(muted)
            } catch (_: Exception) {
            }
        }
    }

    /**
     * Enables or disables the local camera stream.
     * Starts Camera2 capture on-demand when enabled, and stops the hardware camera when disabled.
     */
    fun setLocalVideoEnabled(enabled: Boolean, useFrontCamera: Boolean = isFrontCameraActive.get()) {
        executor.execute {
            isFrontCameraActive.set(useFrontCamera)
            try {
                localVideoTrack?.setEnabled(enabled)
                if (enabled) {
                    if (PhonogrammMediaHelper.hasCameraPermission(appContext)) {
                        startCameraCaptureInternal(useFrontCamera)
                    }
                } else {
                    stopCameraCaptureInternal()
                }
            } catch (e: Exception) {
                Log.w(TAG, "Error toggling local video: ${e.message}")
            }
        }
    }

    /**
     * Switches between front and back cameras using WebRTC's [CameraVideoCapturer.switchCamera].
     */
    fun switchCamera(useFrontCamera: Boolean) {
        executor.execute {
            val prevFront = isFrontCameraActive.getAndSet(useFrontCamera)
            if (prevFront == useFrontCamera) return@execute
            val capturer = videoCapturer as? CameraVideoCapturer
            if (capturer != null && isCameraCapturing.get()) {
                try {
                    capturer.switchCamera(null)
                    return@execute
                } catch (_: Exception) {
                }
            }
            if (isCameraCapturing.get()) {
                stopCameraCaptureInternal()
                startCameraCaptureInternal(useFrontCamera)
            }
        }
    }

    fun attachLocalVideoSink(sink: VideoSink) {
        localVideoSinks.add(sink)
        executor.execute {
            try {
                localVideoTrack?.addSink(sink)
            } catch (_: Exception) {
            }
        }
    }

    fun detachLocalVideoSink(sink: VideoSink) {
        localVideoSinks.remove(sink)
        executor.execute {
            try {
                localVideoTrack?.removeSink(sink)
            } catch (_: Exception) {
            }
        }
    }

    fun attachRemoteVideoSink(sink: VideoSink) {
        remoteVideoSinks.add(sink)
        executor.execute {
            try {
                remoteVideoTrack?.addSink(sink)
            } catch (_: Exception) {
            }
        }
    }

    fun detachRemoteVideoSink(sink: VideoSink) {
        remoteVideoSinks.remove(sink)
        executor.execute {
            try {
                remoteVideoTrack?.removeSink(sink)
            } catch (_: Exception) {
            }
        }
    }

    private fun startCameraCaptureInternal(useFront: Boolean) {
        if (!isNativeInitialized.get()) return
        if (isCameraCapturing.get()) return
        val vSource = localVideoSource ?: return
        val eglCtx = eglBase?.eglBaseContext ?: return

        try {
            val enumerator = if (Camera2Enumerator.isSupported(appContext)) {
                Camera2Enumerator(appContext)
            } else {
                Camera1Enumerator(true)
            }
            val deviceNames = enumerator.deviceNames
            if (deviceNames.isEmpty()) return

            val targetDevice = deviceNames.firstOrNull { name ->
                if (useFront) enumerator.isFrontFacing(name) else enumerator.isBackFacing(name)
            } ?: deviceNames.first()

            val capturer = enumerator.createCapturer(targetDevice, null) ?: return
            val helper = SurfaceTextureHelper.create("WebRtcCameraCaptureThread", eglCtx)
            surfaceTextureHelper = helper
            videoCapturer = capturer

            capturer.initialize(helper, appContext, vSource.capturerObserver)
            // 720p @ 30fps smooth hardware-encoded WebRTC video stream
            capturer.startCapture(1280, 720, 30)
            isCameraCapturing.set(true)
        } catch (e: Exception) {
            Log.w(TAG, "Failed to start WebRTC camera capture: ${e.message}")
            stopCameraCaptureInternal()
        }
    }

    private fun stopCameraCaptureInternal() {
        isCameraCapturing.set(false)
        val capturer = videoCapturer
        videoCapturer = null
        if (capturer != null) {
            try {
                capturer.stopCapture()
            } catch (_: Exception) {
            }
            try {
                capturer.dispose()
            } catch (_: Exception) {
            }
        }
        val helper = surfaceTextureHelper
        surfaceTextureHelper = null
        if (helper != null) {
            try {
                helper.dispose()
            } catch (_: Exception) {
            }
        }
    }

    /**
     * Releases all WebRTC tracks, camera capturers, audio sources, and PeerConnection for the current call.
     */
    fun releaseSession() {
        executor.execute {
            releaseSessionInternal()
        }
    }

    private fun releaseSessionInternal() {
        activeSessionId = ""
        activeCallbacks = null
        remoteDescriptionSet.set(false)
        lastAppliedOfferSdp = ""
        lastAppliedAnswerSdp = ""
        pendingRemoteCandidates.clear()
        appliedRemoteCandidates.clear()

        stopCameraCaptureInternal()

        val rTrack = remoteVideoTrack
        remoteVideoTrack = null
        if (rTrack != null) {
            for (sink in remoteVideoSinks) {
                try {
                    rTrack.removeSink(sink)
                } catch (_: Exception) {
                }
            }
        }

        val lTrack = localVideoTrack
        localVideoTrack = null
        if (lTrack != null) {
            for (sink in localVideoSinks) {
                try {
                    lTrack.removeSink(sink)
                } catch (_: Exception) {
                }
            }
            try {
                lTrack.dispose()
            } catch (_: Exception) {
            }
        }

        try {
            localVideoSource?.dispose()
        } catch (_: Exception) {
        }
        localVideoSource = null

        try {
            localAudioTrack?.dispose()
        } catch (_: Exception) {
        }
        localAudioTrack = null

        try {
            localAudioSource?.dispose()
        } catch (_: Exception) {
        }
        localAudioSource = null

        val pc = peerConnection
        peerConnection = null
        if (pc != null) {
            try {
                pc.close()
            } catch (_: Exception) {
            }
            try {
                pc.dispose()
            } catch (_: Exception) {
            }
        }
    }

    /**
     * Tunes SDP to enable Opus inband FEC, DTX=0 (so quiet syllables are never gated/dropped),
     * and 48kHz fullband stereo/mono voice clarity.
     */
    private fun tuneOpusSdp(rawSdp: String): String {
        if (!rawSdp.contains("opus/48000", ignoreCase = true)) return rawSdp
        return rawSdp.lines().joinToString("\r\n") { line ->
            if (line.startsWith("a=fmtp:") && line.contains("minptime=")) {
                var updated = line
                if (!updated.contains("useinbandfec=1")) {
                    updated += ";useinbandfec=1"
                }
                if (!updated.contains("usedtx=0")) {
                    updated += ";usedtx=0"
                }
                if (!updated.contains("maxaveragebitrate=")) {
                    updated += ";maxaveragebitrate=64000"
                }
                updated
            } else {
                line
            }
        }
    }

    private open class SimpleSdpObserver : SdpObserver {
        override fun onCreateSuccess(desc: SessionDescription?) {}
        override fun onSetSuccess() {}
        override fun onCreateFailure(error: String?) {
            Log.w(TAG, "SDP create failure: $error")
        }
        override fun onSetFailure(error: String?) {
            Log.w(TAG, "SDP set failure: $error")
        }
    }

    companion object {
        private const val TAG = "WebRtcCallEngine"
        private const val STREAM_ID = "ARDAMS"
        private const val AUDIO_TRACK_ID = "ARDAMSa0"
        private const val VIDEO_TRACK_ID = "ARDAMSv0"
    }
}

/**
 * Jetpack Compose wrapper around WebRTC's hardware-accelerated [SurfaceViewRenderer].
 */
@Composable
fun WebRtcVideoSurface(
    engine: WebRtcCallEngine,
    isLocalPreview: Boolean,
    mirror: Boolean,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val renderer = remember(context) {
        SurfaceViewRenderer(context)
    }

    DisposableEffect(renderer, engine, isLocalPreview) {
        val eglContext = engine.getEglBaseContext()
        var initialized = false
        if (eglContext != null) {
            try {
                renderer.init(eglContext, null)
                renderer.setEnableHardwareScaler(true)
                renderer.setScalingType(
                    if (isLocalPreview) {
                        RendererCommon.ScalingType.SCALE_ASPECT_FILL
                    } else {
                        RendererCommon.ScalingType.SCALE_ASPECT_FIT
                    }
                )
                renderer.setMirror(mirror)
                renderer.setZOrderMediaOverlay(isLocalPreview)
                initialized = true
            } catch (_: Exception) {
            }
        }

        if (isLocalPreview) {
            engine.attachLocalVideoSink(renderer)
        } else {
            engine.attachRemoteVideoSink(renderer)
        }

        onDispose {
            if (isLocalPreview) {
                engine.detachLocalVideoSink(renderer)
            } else {
                engine.detachRemoteVideoSink(renderer)
            }
            if (initialized) {
                try {
                    renderer.release()
                } catch (_: Exception) {
                }
            }
        }
    }

    Box(modifier = modifier.background(Color(0xFF070A12))) {
        AndroidView(
            factory = { renderer },
            update = { view ->
                view.setMirror(mirror)
            },
            modifier = Modifier.fillMaxSize()
        )
    }
}
