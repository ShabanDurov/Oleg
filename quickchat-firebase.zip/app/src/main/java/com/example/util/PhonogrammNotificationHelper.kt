package com.example.util

import android.Manifest
import android.annotation.SuppressLint
import android.app.ActivityManager
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import android.util.Log
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat
import androidx.core.content.ContextCompat
import com.example.MainActivity
import com.example.R
import com.example.data.model.CallSession
import com.example.data.model.IncomingMessageNotification
import com.example.data.model.SystemBotMessage
import com.google.firebase.firestore.DocumentSnapshot
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.ListenerRegistration
import java.util.Collections
import java.util.concurrent.ConcurrentHashMap
import java.util.concurrent.atomic.AtomicInteger
import kotlin.math.abs
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

object PhonogrammNotificationHelper {

    private const val TAG = "PgNotifications"

    const val CHANNEL_ID = "phonogramm_messages_channel_v2"
    const val CHANNEL_NAME = "Сообщения Oleg"
    const val CHANNEL_DESCRIPTION = "Мгновенные уведомления о новых входящих сообщениях"

    const val CALL_CHANNEL_ID = "phonogramm_calls_channel_v1"
    const val CALL_CHANNEL_NAME = "Звонки Oleg"
    const val CALL_CHANNEL_DESCRIPTION = "Входящие аудио- и видеозвонки Oleg"
    private const val CALL_NOTIFICATION_ID = 88001

    const val EXTRA_OPEN_CHAT_USERNAME = "extra_open_chat_username"
    const val EXTRA_OPEN_CHAT_IS_SYSTEM = "extra_open_chat_is_system"
    const val EXTRA_OPEN_CALL_ID = "extra_open_call_id"

    private const val PREFS_NAME = "pg_notification_engine_prefs"
    private const val KEY_NOTIFIED_IDS = "notified_msg_ids"
    private const val KEY_LAST_ACTIVE_TS = "last_active_ts"

    private val notificationSeq = AtomicInteger(1)

    private val _isActivityInForeground = MutableStateFlow(true)
    val isActivityInForeground: StateFlow<Boolean> = _isActivityInForeground.asStateFlow()

    private val _inAppNotification = MutableStateFlow<IncomingMessageNotification?>(null)
    val inAppNotification: StateFlow<IncomingMessageNotification?> = _inAppNotification.asStateFlow()

    private val _incomingCallSession = MutableStateFlow<CallSession?>(null)
    val incomingCallSession: StateFlow<CallSession?> = _incomingCallSession.asStateFlow()

    private var monitoredUserId: String? = null
    private var lastAppContext: Context? = null
    private var chatsListener: ListenerRegistration? = null
    private var callsListener: ListenerRegistration? = null
    private var profileSystemListener: ListenerRegistration? = null
    private val messageListenersByChatId = ConcurrentHashMap<String, ListenerRegistration>()
    private val knownMessageIdsByChatId = ConcurrentHashMap<String, MutableSet<String>>()
    private val initializedChatBaselines = Collections.synchronizedSet(mutableSetOf<String>())
    private var hasCompletedInitialChatsSnapshot = false
    private var hasInitializedSystemBaseline = false
    private val knownSystemMessageIds = Collections.synchronizedSet(mutableSetOf<String>())
    private val dispatchedNotificationIds = Collections.synchronizedSet(mutableSetOf<String>())
    private val dispatchedCallSessionIds = Collections.synchronizedSet(mutableSetOf<String>())
    private val peerAvatarCache = ConcurrentHashMap<String, String>()
    private val peerDisplayNameCache = ConcurrentHashMap<String, String>()

    fun setActivityInForeground(context: Context, inForeground: Boolean) {
        _isActivityInForeground.value = inForeground
        try {
            context.applicationContext
                .getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
                .edit()
                .putLong(KEY_LAST_ACTIVE_TS, System.currentTimeMillis())
                .apply()
        } catch (_: Exception) {
        }
    }

    fun dismissInAppNotification() {
        _inAppNotification.value = null
    }

    fun clearIncomingCallSession(context: Context? = null) {
        _incomingCallSession.value = null
        if (context != null) {
            try {
                NotificationManagerCompat.from(context.applicationContext).cancel(CALL_NOTIFICATION_ID)
            } catch (_: Exception) {
            }
        }
    }

    fun updatePeerMetadata(username: String, displayName: String, avatarUrl: String) {
        val clean = username.trim().removePrefix("@").lowercase()
        if (clean.isNotBlank()) {
            if (displayName.isNotBlank()) peerDisplayNameCache[clean] = displayName
            if (avatarUrl.isNotBlank()) peerAvatarCache[clean] = avatarUrl
        }
    }

    fun ensureNotificationChannel(context: Context) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val manager = context.getSystemService(Context.NOTIFICATION_SERVICE) as? NotificationManager
                ?: return
            if (manager.getNotificationChannel(CHANNEL_ID) == null) {
                val msgChannel = NotificationChannel(
                    CHANNEL_ID,
                    CHANNEL_NAME,
                    NotificationManager.IMPORTANCE_HIGH
                ).apply {
                    description = CHANNEL_DESCRIPTION
                    enableVibration(true)
                    vibrationPattern = longArrayOf(0L, 180L, 90L, 180L)
                    setShowBadge(true)
                }
                manager.createNotificationChannel(msgChannel)
            }
            if (manager.getNotificationChannel(CALL_CHANNEL_ID) == null) {
                val callChannel = NotificationChannel(
                    CALL_CHANNEL_ID,
                    CALL_CHANNEL_NAME,
                    NotificationManager.IMPORTANCE_HIGH
                ).apply {
                    description = CALL_CHANNEL_DESCRIPTION
                    enableVibration(true)
                    vibrationPattern = longArrayOf(0L, 400L, 200L, 400L, 200L, 400L)
                    setShowBadge(true)
                }
                manager.createNotificationChannel(callChannel)
            }
        }
    }

    fun hasNotificationPermission(context: Context): Boolean {
        return if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            ContextCompat.checkSelfPermission(
                context,
                Manifest.permission.POST_NOTIFICATIONS
            ) == PackageManager.PERMISSION_GRANTED
        } else {
            true
        }
    }

    fun isProcessInForeground(context: Context): Boolean {
        val activityManager = context.getSystemService(Context.ACTIVITY_SERVICE) as? ActivityManager
            ?: return false
        val appProcesses = activityManager.runningAppProcesses ?: return false
        val packageName = context.packageName
        for (appProcess in appProcesses) {
            if (appProcess.processName == packageName) {
                return appProcess.importance == ActivityManager.RunningAppProcessInfo.IMPORTANCE_FOREGROUND
            }
        }
        return false
    }

    /**
     * Starts persistent Firestore listeners for the authenticated [userId] at the application level
     * so notifications fire on every single incoming message and call whether the user is inside or outside the app.
     */
    @Synchronized
    fun startMonitoring(context: Context, userId: String) {
        val appContext = context.applicationContext
        lastAppContext = appContext
        ensureNotificationChannel(appContext)
        if (userId.isBlank()) {
            stopMonitoring(appContext)
            return
        }
        if (monitoredUserId == userId && chatsListener != null && callsListener != null) {
            return
        }

        stopMonitoring(stopService = false)
        monitoredUserId = userId

        try {
            val serviceIntent = Intent(appContext, PhonogrammNotificationService::class.java).apply {
                putExtra(PhonogrammNotificationService.EXTRA_USER_ID, userId)
            }
            appContext.startService(serviceIntent)
        } catch (_: Exception) {
        }

        val prefs = appContext.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
        val savedIds = prefs.getStringSet(KEY_NOTIFIED_IDS, emptySet()) ?: emptySet()
        dispatchedNotificationIds.addAll(savedIds)
        val lastActiveTs = prefs.getLong(KEY_LAST_ACTIVE_TS, System.currentTimeMillis() - 60_000L)

        val databaseId = try {
            appContext.getString(R.string.firestore_database_id)
        } catch (_: Exception) {
            "(default)"
        }
        val db = FirebaseFirestore.getInstance(databaseId)

        // 1. Observe /users/{userId} for incoming systemMessages (gifts, verification badges, 6-digit security codes)
        profileSystemListener = db.collection("users").document(userId)
            .addSnapshotListener { snapshot, error ->
                if (error != null || snapshot == null || !snapshot.exists()) {
                    return@addSnapshotListener
                }
                val rawList = (snapshot.get("systemMessages") as? List<*>)
                    ?.mapNotNull { it as? Map<*, *> }
                    ?.mapNotNull {
                        try {
                            SystemBotMessage.fromMap(it)
                        } catch (_: Exception) {
                            null
                        }
                    } ?: emptyList()

                if (!hasInitializedSystemBaseline) {
                    hasInitializedSystemBaseline = true
                    for (sysMsg in rawList) {
                        val key = sysMsg.id.ifBlank { "sys_${sysMsg.timestamp}_${sysMsg.text.hashCode()}" }
                        knownSystemMessageIds.add(key)
                    }
                    return@addSnapshotListener
                }

                for (sysMsg in rawList) {
                    val key = sysMsg.id.ifBlank { "sys_${sysMsg.timestamp}_${sysMsg.text.hashCode()}" }
                    if (knownSystemMessageIds.add(key)) {
                        dispatchIncomingMessage(
                            context = appContext,
                            notification = IncomingMessageNotification(
                                id = key,
                                chatId = "__system__",
                                senderUsername = "Oleg",
                                senderDisplayName = "Oleg",
                                messageText = sysMsg.text,
                                isSystemBot = true
                            )
                        )
                    }
                }
            }

        // 2. Observe all chats of userId and attach real-time message listeners to /chats/{chatId}/messages
        chatsListener = db.collection("chats")
            .whereArrayContains("participantIds", userId)
            .addSnapshotListener { querySnapshot, error ->
                if (error != null || querySnapshot == null) {
                    if (error != null) {
                        Log.w(TAG, "Error listening to chats for notifications: ${error.message}")
                    }
                    return@addSnapshotListener
                }

                val isFirstChatsSnapshot = !hasCompletedInitialChatsSnapshot
                hasCompletedInitialChatsSnapshot = true

                val currentChatIds = mutableSetOf<String>()
                for (doc in querySnapshot.documents) {
                    val chatId = doc.id
                    if (chatId.isBlank()) continue
                    currentChatIds.add(chatId)

                    val p1Id = doc.getString("participant1Id") ?: ""
                    val p1User = doc.getString("participant1Username") ?: ""
                    val p2User = doc.getString("participant2Username") ?: ""
                    val peerUsername = if (p1Id == userId) p2User else p1User

                    if (!messageListenersByChatId.containsKey(chatId)) {
                        attachChatMessagesListener(
                            appContext = appContext,
                            db = db,
                            chatId = chatId,
                            userId = userId,
                            fallbackPeerUsername = peerUsername,
                            isBrandNewChatAfterInit = !isFirstChatsSnapshot,
                            lastActiveTs = lastActiveTs
                        )
                    }
                }

                val removedChatIds = messageListenersByChatId.keys.filter { it !in currentChatIds }
                for (removedId in removedChatIds) {
                    messageListenersByChatId.remove(removedId)?.remove()
                    knownMessageIdsByChatId.remove(removedId)
                    initializedChatBaselines.remove(removedId)
                }
            }

        // 3. Observe /calls where participantIds contains userId for real-time incoming calls
        callsListener = db.collection("calls")
            .whereArrayContains("participantIds", userId)
            .addSnapshotListener { querySnapshot, error ->
                if (error != null || querySnapshot == null) {
                    if (error != null) {
                        Log.w(TAG, "Error listening to calls for notifications: ${error.message}")
                    }
                    return@addSnapshotListener
                }

                val nowMs = System.currentTimeMillis()
                var activeIncomingRinging: CallSession? = null

                for (doc in querySnapshot.documents) {
                    val callSession = parseCallSessionFromDoc(doc) ?: continue
                    val updatedMs = callSession.updatedAtMillis
                    val isRecent = updatedMs == 0L || (nowMs - updatedMs) <= 90_000L

                    if (callSession.calleeId == userId &&
                        callSession.status == CallSession.STATUS_RINGING &&
                        isRecent
                    ) {
                        activeIncomingRinging = callSession
                        break
                    }
                }

                if (activeIncomingRinging != null) {
                    _incomingCallSession.value = activeIncomingRinging
                    val sessionKey = activeIncomingRinging.sessionId.ifBlank {
                        "${activeIncomingRinging.callId}_${activeIncomingRinging.updatedAtMillis}"
                    }
                    if (dispatchedCallSessionIds.add(sessionKey)) {
                        dispatchIncomingCall(appContext, activeIncomingRinging)
                    }
                } else {
                    if (_incomingCallSession.value != null) {
                        clearIncomingCallSession(appContext)
                    }
                }
            }
    }

    private fun parseCallSessionFromDoc(doc: DocumentSnapshot): CallSession? {
        if (!doc.exists()) return null
        return try {
            val rawData = doc.data ?: return null
            val p1Id = (rawData["participant1Id"] as? String) ?: ""
            val p2Id = (rawData["participant2Id"] as? String) ?: ""
            val pIds = (rawData["participantIds"] as? List<*>)
                ?.mapNotNull { it as? String }
                ?.takeIf { it.size == 2 }
                ?: listOf(p1Id, p2Id).filter { it.isNotBlank() }

            val isVid = (rawData["isVideo"] as? Boolean) ?: false
            CallSession(
                id = doc.id,
                callId = (rawData["callId"] as? String)?.ifBlank { doc.id } ?: doc.id,
                sessionId = (rawData["sessionId"] as? String) ?: "",
                participantIds = pIds,
                participant1Id = p1Id,
                participant2Id = p2Id,
                callerId = (rawData["callerId"] as? String) ?: "",
                callerUsername = (rawData["callerUsername"] as? String) ?: "",
                calleeId = (rawData["calleeId"] as? String) ?: "",
                calleeUsername = (rawData["calleeUsername"] as? String) ?: "",
                isVideo = isVid,
                status = (rawData["status"] as? String) ?: CallSession.STATUS_ENDED,
                callerVideoEnabled = (rawData["callerVideoEnabled"] as? Boolean) ?: isVid,
                calleeVideoEnabled = (rawData["calleeVideoEnabled"] as? Boolean) ?: false,
                callerMuted = (rawData["callerMuted"] as? Boolean) ?: false,
                calleeMuted = (rawData["calleeMuted"] as? Boolean) ?: false,
                offerSdp = (rawData["offerSdp"] as? String) ?: "",
                offerType = (rawData["offerType"] as? String) ?: "offer",
                answerSdp = (rawData["answerSdp"] as? String) ?: "",
                answerType = (rawData["answerType"] as? String) ?: "answer",
                callerCandidates = (rawData["callerCandidates"] as? List<*>)?.mapNotNull { it as? String } ?: emptyList(),
                calleeCandidates = (rawData["calleeCandidates"] as? List<*>)?.mapNotNull { it as? String } ?: emptyList(),
                createdAt = doc.getTimestamp("createdAt", DocumentSnapshot.ServerTimestampBehavior.ESTIMATE),
                updatedAt = doc.getTimestamp("updatedAt", DocumentSnapshot.ServerTimestampBehavior.ESTIMATE)
            )
        } catch (_: Exception) {
            null
        }
    }

    private fun attachChatMessagesListener(
        appContext: Context,
        db: FirebaseFirestore,
        chatId: String,
        userId: String,
        fallbackPeerUsername: String,
        isBrandNewChatAfterInit: Boolean,
        lastActiveTs: Long
    ) {
        val knownIds = knownMessageIdsByChatId.getOrPut(chatId) {
            Collections.synchronizedSet(mutableSetOf())
        }

        val registration = db.collection("chats")
            .document(chatId)
            .collection("messages")
            .whereArrayContains("participantIds", userId)
            .addSnapshotListener { snapshot, error ->
                if (error != null || snapshot == null) {
                    return@addSnapshotListener
                }

                val isFirstSnapshotForChat = initializedChatBaselines.add(chatId)
                val sortedDocs = snapshot.documents.sortedBy { doc ->
                    doc.getTimestamp("createdAt", DocumentSnapshot.ServerTimestampBehavior.ESTIMATE)
                        ?.toDate()?.time ?: 0L
                }

                if (isFirstSnapshotForChat && !isBrandNewChatAfterInit) {
                    val recentCutoff = maxOf(lastActiveTs - 15_000L, System.currentTimeMillis() - 45_000L)
                    for (doc in sortedDocs) {
                        val msgId = doc.id
                        knownIds.add(msgId)
                        val senderId = doc.getString("senderId") ?: ""
                        val isRead = doc.getBoolean("read") ?: false
                        val text = (doc.getString("text") ?: "").trim()
                        val deletedFor = (doc.get("deletedFor") as? List<*>)?.mapNotNull { it as? String } ?: emptyList()
                        val createdMs = doc.getTimestamp("createdAt", DocumentSnapshot.ServerTimestampBehavior.ESTIMATE)
                            ?.toDate()?.time ?: 0L

                        if (senderId.isNotBlank() &&
                            senderId != userId &&
                            !isRead &&
                            text.isNotBlank() &&
                            !deletedFor.contains(userId) &&
                            createdMs >= recentCutoff &&
                            !dispatchedNotificationIds.contains(msgId)
                        ) {
                            val senderUsername = (doc.getString("senderUsername") ?: "")
                                .ifBlank { fallbackPeerUsername }
                                .ifBlank { "пользователя" }
                            val lower = senderUsername.lowercase()
                            dispatchIncomingMessage(
                                context = appContext,
                                notification = IncomingMessageNotification(
                                    id = msgId,
                                    chatId = chatId,
                                    senderUsername = senderUsername,
                                    senderDisplayName = peerDisplayNameCache[lower] ?: senderUsername,
                                    senderAvatarUrl = peerAvatarCache[lower] ?: "",
                                    messageText = text,
                                    isSystemBot = false
                                )
                            )
                        }
                    }
                    return@addSnapshotListener
                }

                for (doc in sortedDocs) {
                    val msgId = doc.id
                    if (msgId.isBlank()) continue
                    val isNewMessageDoc = knownIds.add(msgId)
                    if (!isNewMessageDoc) continue

                    val senderId = doc.getString("senderId") ?: ""
                    val text = (doc.getString("text") ?: "").trim()
                    val deletedFor = (doc.get("deletedFor") as? List<*>)?.mapNotNull { it as? String } ?: emptyList()

                    if (senderId.isNotBlank() &&
                        senderId != userId &&
                        text.isNotBlank() &&
                        !deletedFor.contains(userId)
                    ) {
                        val senderUsername = (doc.getString("senderUsername") ?: "")
                            .ifBlank { fallbackPeerUsername }
                            .ifBlank { "пользователя" }
                        val lower = senderUsername.lowercase()

                        dispatchIncomingMessage(
                            context = appContext,
                            notification = IncomingMessageNotification(
                                id = msgId,
                                chatId = chatId,
                                senderUsername = senderUsername,
                                senderDisplayName = peerDisplayNameCache[lower] ?: senderUsername,
                                senderAvatarUrl = peerAvatarCache[lower] ?: "",
                                messageText = text,
                                isSystemBot = false
                            )
                        )
                    }
                }
            }

        messageListenersByChatId[chatId] = registration
    }

    @Synchronized
    fun stopMonitoring(context: Context? = null, stopService: Boolean = true) {
        val ctx = context?.applicationContext ?: lastAppContext
        monitoredUserId = null
        chatsListener?.remove()
        chatsListener = null
        callsListener?.remove()
        callsListener = null
        profileSystemListener?.remove()
        profileSystemListener = null
        for ((_, reg) in messageListenersByChatId) {
            reg.remove()
        }
        messageListenersByChatId.clear()
        knownMessageIdsByChatId.clear()
        initializedChatBaselines.clear()
        hasCompletedInitialChatsSnapshot = false
        hasInitializedSystemBaseline = false
        knownSystemMessageIds.clear()
        _incomingCallSession.value = null
        if (stopService && ctx != null) {
            try {
                ctx.stopService(Intent(ctx, PhonogrammNotificationService::class.java))
            } catch (_: Exception) {
            }
        }
    }

    /**
     * Dispatches an incoming call notification:
     * - If the user is in the app: shows the in-app banner AND `_incomingCallSession` displays the incoming call screen.
     * - If the user is outside the app: posts a high-priority call push notification AND sets `_incomingCallSession`.
     */
    fun dispatchIncomingCall(
        context: Context,
        callSession: CallSession
    ) {
        val appContext = context.applicationContext
        val callerUsername = callSession.callerUsername.trim().removePrefix("@").ifBlank { "пользователя" }
        val lower = callerUsername.lowercase()
        val callLabel = if (callSession.isVideo) {
            "📹 Входящий видеозвонок от @$callerUsername"
        } else {
            "📞 Входящий аудиозвонок от @$callerUsername"
        }

        val notifObj = IncomingMessageNotification(
            id = callSession.sessionId.ifBlank { "call_${callSession.callId}_${System.nanoTime()}" },
            chatId = callSession.callId,
            senderUsername = callerUsername,
            senderDisplayName = peerDisplayNameCache[lower] ?: callerUsername,
            senderAvatarUrl = peerAvatarCache[lower] ?: "",
            messageText = callLabel,
            isSystemBot = false,
            isCallInvite = true,
            callSessionId = callSession.callId,
            isVideoCall = callSession.isVideo
        )

        val isForeground = _isActivityInForeground.value && isProcessInForeground(appContext)
        if (isForeground) {
            _inAppNotification.value = notifObj
        } else {
            showIncomingCallSystemNotification(appContext, callSession)
        }
    }

    /**
     * Dispatches an incoming message notification:
     * - If the user is currently IN the app (foreground): shows the in-app banner ("Новое сообщение от @...").
     * - If the user is NOT in the app (background/minimized/closed): immediately posts a system push notification.
     */
    fun dispatchIncomingMessage(
        context: Context,
        notification: IncomingMessageNotification
    ) {
        val appContext = context.applicationContext
        val uniqueId = notification.id.ifBlank {
            "${notification.chatId}_${notification.senderUsername}_${System.nanoTime()}"
        }
        if (!dispatchedNotificationIds.add(uniqueId)) {
            return
        }
        persistDispatchedId(appContext, uniqueId)

        val isForeground = _isActivityInForeground.value && isProcessInForeground(appContext)
        if (isForeground) {
            _inAppNotification.value = notification
        } else {
            showIncomingMessageSystemNotification(
                context = appContext,
                senderUsername = notification.senderUsername,
                messageText = notification.messageText,
                chatId = notification.chatId,
                messageId = uniqueId,
                isSystemBot = notification.isSystemBot
            )
        }
    }

    private fun persistDispatchedId(context: Context, id: String) {
        try {
            val prefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
            val current = (prefs.getStringSet(KEY_NOTIFIED_IDS, emptySet()) ?: emptySet()).toMutableSet()
            current.add(id)
            val trimmed = if (current.size > 400) {
                current.toList().takeLast(300).toSet()
            } else {
                current
            }
            prefs.edit().putStringSet(KEY_NOTIFIED_IDS, trimmed).apply()
        } catch (_: Exception) {
        }
    }

    @SuppressLint("MissingPermission")
    fun showIncomingCallSystemNotification(
        context: Context,
        callSession: CallSession
    ) {
        ensureNotificationChannel(context)
        if (!hasNotificationPermission(context)) {
            return
        }

        val cleanCaller = callSession.callerUsername.trim().removePrefix("@").ifBlank { "пользователя" }
        val titleText = if (callSession.isVideo) {
            "📹 Входящий видеозвонок от @$cleanCaller"
        } else {
            "📞 Входящий звонок от @$cleanCaller"
        }
        val bodyText = "Новое сообщение от @$cleanCaller: вам звонят в Oleg. Нажмите, чтобы ответить."

        val launchIntent = Intent(context, MainActivity::class.java).apply {
            flags = Intent.FLAG_ACTIVITY_SINGLE_TOP or Intent.FLAG_ACTIVITY_CLEAR_TOP or Intent.FLAG_ACTIVITY_NEW_TASK
            putExtra(EXTRA_OPEN_CHAT_USERNAME, cleanCaller)
            putExtra(EXTRA_OPEN_CALL_ID, callSession.callId)
        }

        val pendingIntentFlags = PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        val pendingIntent = PendingIntent.getActivity(
            context,
            CALL_NOTIFICATION_ID,
            launchIntent,
            pendingIntentFlags
        )

        val notification = NotificationCompat.Builder(context, CALL_CHANNEL_ID)
            .setSmallIcon(R.mipmap.ic_launcher_round)
            .setContentTitle(titleText)
            .setContentText(bodyText)
            .setTicker(titleText)
            .setWhen(System.currentTimeMillis())
            .setShowWhen(true)
            .setOnlyAlertOnce(false)
            .setOngoing(true)
            .setStyle(
                NotificationCompat.BigTextStyle()
                    .setBigContentTitle(titleText)
                    .bigText(bodyText)
            )
            .setPriority(NotificationCompat.PRIORITY_MAX)
            .setCategory(NotificationCompat.CATEGORY_CALL)
            .setDefaults(NotificationCompat.DEFAULT_ALL)
            .setAutoCancel(true)
            .setContentIntent(pendingIntent)
            .build()

        try {
            NotificationManagerCompat.from(context).notify(CALL_NOTIFICATION_ID, notification)
        } catch (_: SecurityException) {
        }
    }

    @SuppressLint("MissingPermission")
    fun showIncomingMessageSystemNotification(
        context: Context,
        senderUsername: String,
        messageText: String,
        chatId: String = "",
        messageId: String = "",
        isSystemBot: Boolean = false
    ) {
        ensureNotificationChannel(context)
        if (!hasNotificationPermission(context)) {
            return
        }

        val cleanSender = senderUsername.trim().removePrefix("@").ifBlank { "пользователя" }
        val formattedSender = if (isSystemBot) "Oleg" else "@$cleanSender"
        val titleText = "Новое сообщение от $formattedSender"
        val bodyText = if (messageText.isNotBlank()) {
            "Новое сообщение от $formattedSender: $messageText"
        } else {
            "Новое сообщение от $formattedSender"
        }

        val launchIntent = Intent(context, MainActivity::class.java).apply {
            flags = Intent.FLAG_ACTIVITY_SINGLE_TOP or Intent.FLAG_ACTIVITY_CLEAR_TOP or Intent.FLAG_ACTIVITY_NEW_TASK
            putExtra(EXTRA_OPEN_CHAT_USERNAME, cleanSender)
            putExtra(EXTRA_OPEN_CHAT_IS_SYSTEM, isSystemBot)
        }

        val uniqueSeq = notificationSeq.incrementAndGet()
        val requestCode = abs((messageId.ifBlank { "${chatId}_${uniqueSeq}" }).hashCode())
        val pendingIntentFlags = PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        val pendingIntent = PendingIntent.getActivity(
            context,
            requestCode,
            launchIntent,
            pendingIntentFlags
        )

        val notification = NotificationCompat.Builder(context, CHANNEL_ID)
            .setSmallIcon(R.mipmap.ic_launcher_round)
            .setContentTitle(titleText)
            .setContentText(bodyText)
            .setTicker(titleText)
            .setWhen(System.currentTimeMillis())
            .setShowWhen(true)
            .setOnlyAlertOnce(false)
            .setStyle(
                NotificationCompat.BigTextStyle()
                    .setBigContentTitle(titleText)
                    .bigText(messageText.ifBlank { titleText })
            )
            .setPriority(NotificationCompat.PRIORITY_MAX)
            .setCategory(NotificationCompat.CATEGORY_MESSAGE)
            .setDefaults(NotificationCompat.DEFAULT_ALL)
            .setGroup("pg_chat_group_${cleanSender.lowercase()}")
            .setAutoCancel(true)
            .setContentIntent(pendingIntent)
            .build()

        val notificationId = 20000 + (uniqueSeq % 65000)
        try {
            NotificationManagerCompat.from(context).notify(notificationId, notification)
        } catch (_: SecurityException) {
            // Permission revoked at runtime
        }
    }
}
