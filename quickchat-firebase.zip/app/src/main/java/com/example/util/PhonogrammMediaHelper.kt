package com.example.util

import android.Manifest
import android.annotation.SuppressLint
import android.content.Context
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.graphics.Matrix
import android.graphics.Paint
import android.graphics.Rect
import android.graphics.SurfaceTexture
import android.hardware.camera2.CameraCaptureSession
import android.hardware.camera2.CameraCharacteristics
import android.hardware.camera2.CameraDevice
import android.hardware.camera2.CameraManager
import android.hardware.camera2.CaptureRequest
import android.media.AudioAttributes
import android.media.AudioDeviceInfo
import android.media.AudioFormat
import android.media.AudioManager
import android.media.AudioRecord
import android.media.AudioTrack
import android.media.ExifInterface
import android.media.MediaPlayer
import android.media.MediaRecorder
import android.media.audiofx.AcousticEchoCanceler
import android.media.audiofx.AutomaticGainControl
import android.media.audiofx.NoiseSuppressor
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.util.Base64
import android.util.Log
import android.util.Range
import android.view.Surface
import android.view.TextureView
import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.FilterQuality
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.core.content.ContextCompat
import java.io.ByteArrayOutputStream
import java.io.File
import java.nio.ByteBuffer
import java.nio.ByteOrder
import java.util.concurrent.ConcurrentHashMap
import java.util.concurrent.ConcurrentLinkedDeque
import java.util.concurrent.atomic.AtomicBoolean
import java.util.concurrent.atomic.AtomicLong
import androidx.compose.runtime.mutableFloatStateOf
import kotlin.math.PI
import kotlin.math.abs
import kotlin.math.cos
import kotlin.math.sin
import kotlin.math.sqrt
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.delay
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

object PhonogrammMediaHelper {
    private const val TAG = "OlegMedia"

    private val localVoiceFilesByTag = ConcurrentHashMap<String, String>()
    private val localVoiceBase64ByTag = ConcurrentHashMap<String, String>()

    fun hasRecordAudioPermission(context: Context): Boolean {
        return ContextCompat.checkSelfPermission(
            context,
            Manifest.permission.RECORD_AUDIO
        ) == PackageManager.PERMISSION_GRANTED
    }

    fun hasCameraPermission(context: Context): Boolean {
        return ContextCompat.checkSelfPermission(
            context,
            Manifest.permission.CAMERA
        ) == PackageManager.PERMISSION_GRANTED
    }

    fun hasVideoCallPermissions(context: Context): Boolean {
        return hasRecordAudioPermission(context) && hasCameraPermission(context)
    }

    private val avatarBitmapCache = ConcurrentHashMap<String, ImageBitmap>()
    private val chatPhotoBitmapCache = ConcurrentHashMap<String, ImageBitmap>()
    private val pendingChatPhotoByTag = ConcurrentHashMap<String, String>()
    private val localVideoCirclePayloadByTag = ConcurrentHashMap<String, String>()

    private fun ensureArgb8888(bitmap: Bitmap): Bitmap {
        if (bitmap.config == Bitmap.Config.ARGB_8888) return bitmap
        val converted = bitmap.copy(Bitmap.Config.ARGB_8888, false)
        if (converted != null) {
            if (converted !== bitmap) bitmap.recycle()
            return converted
        }
        return bitmap
    }

    private fun readExifRotationDegrees(context: Context, uri: android.net.Uri): Pair<Int, Boolean> {
        return try {
            context.contentResolver.openInputStream(uri)?.use { stream ->
                val exif = ExifInterface(stream)
                when (exif.getAttributeInt(ExifInterface.TAG_ORIENTATION, ExifInterface.ORIENTATION_NORMAL)) {
                    ExifInterface.ORIENTATION_ROTATE_90 -> 90 to false
                    ExifInterface.ORIENTATION_ROTATE_180 -> 180 to false
                    ExifInterface.ORIENTATION_ROTATE_270 -> 270 to false
                    ExifInterface.ORIENTATION_FLIP_HORIZONTAL -> 0 to true
                    ExifInterface.ORIENTATION_TRANSVERSE -> 270 to true
                    ExifInterface.ORIENTATION_TRANSPOSE -> 90 to true
                    ExifInterface.ORIENTATION_FLIP_VERTICAL -> 180 to true
                    else -> 0 to false
                }
            } ?: (0 to false)
        } catch (_: Exception) {
            0 to false
        }
    }

    private fun decodeOrientedArgbBitmap(
        context: Context,
        uri: android.net.Uri,
        maxDimension: Int
    ): Bitmap? {
        return try {
            val boundsOpts = BitmapFactory.Options().apply {
                inJustDecodeBounds = true
            }
            context.contentResolver.openInputStream(uri)?.use { stream ->
                BitmapFactory.decodeStream(stream, null, boundsOpts)
            }
            val rawW = boundsOpts.outWidth
            val rawH = boundsOpts.outHeight
            if (rawW <= 0 || rawH <= 0) return null

            var sampleSize = 1
            val longestSide = maxOf(rawW, rawH)
            while (longestSide / (sampleSize * 2) >= maxDimension) {
                sampleSize *= 2
            }

            val decodeOpts = BitmapFactory.Options().apply {
                inSampleSize = sampleSize
                inPreferredConfig = Bitmap.Config.ARGB_8888
                inScaled = false
                inDither = false
            }
            val decoded = context.contentResolver.openInputStream(uri)?.use { stream ->
                BitmapFactory.decodeStream(stream, null, decodeOpts)
            } ?: return null

            val argbBitmap = ensureArgb8888(decoded)
            val (rotationDeg, flipHorizontal) = readExifRotationDegrees(context, uri)
            if (rotationDeg == 0 && !flipHorizontal) {
                return argbBitmap
            }

            val matrix = Matrix().apply {
                if (flipHorizontal) {
                    postScale(-1f, 1f, argbBitmap.width / 2f, argbBitmap.height / 2f)
                }
                if (rotationDeg != 0) {
                    postRotate(rotationDeg.toFloat())
                }
            }
            val oriented = Bitmap.createBitmap(
                argbBitmap,
                0,
                0,
                argbBitmap.width,
                argbBitmap.height,
                matrix,
                true
            )
            if (oriented !== argbBitmap) {
                argbBitmap.recycle()
            }
            ensureArgb8888(oriented)
        } catch (_: Exception) {
            null
        }
    }

    private fun scaleCenterCropSquareArgb(source: Bitmap, targetSize: Int): Bitmap {
        val minSide = minOf(source.width, source.height).coerceAtLeast(1)
        val cropX = ((source.width - minSide) / 2).coerceAtLeast(0)
        val cropY = ((source.height - minSide) / 2).coerceAtLeast(0)
        val out = Bitmap.createBitmap(targetSize, targetSize, Bitmap.Config.ARGB_8888)
        val canvas = Canvas(out)
        val paint = Paint(Paint.ANTI_ALIAS_FLAG or Paint.FILTER_BITMAP_FLAG or Paint.DITHER_FLAG)
        val srcRect = Rect(cropX, cropY, cropX + minSide, cropY + minSide)
        val dstRect = Rect(0, 0, targetSize, targetSize)
        canvas.drawBitmap(source, srcRect, dstRect, paint)
        return out
    }

    private fun scaleProportionalArgb(source: Bitmap, maxSide: Int): Bitmap {
        val w = source.width.coerceAtLeast(1)
        val h = source.height.coerceAtLeast(1)
        val longest = maxOf(w, h)
        if (longest <= maxSide && source.config == Bitmap.Config.ARGB_8888) {
            return source
        }
        val scale = maxSide.toFloat() / longest.toFloat()
        val targetW = (w * scale).toInt().coerceAtLeast(1)
        val targetH = (h * scale).toInt().coerceAtLeast(1)
        val out = Bitmap.createBitmap(targetW, targetH, Bitmap.Config.ARGB_8888)
        val canvas = Canvas(out)
        val paint = Paint(Paint.ANTI_ALIAS_FLAG or Paint.FILTER_BITMAP_FLAG or Paint.DITHER_FLAG)
        val srcRect = Rect(0, 0, w, h)
        val dstRect = Rect(0, 0, targetW, targetH)
        canvas.drawBitmap(source, srcRect, dstRect, paint)
        return out
    }

    fun encodeUriToAvatarDataUri(context: Context, uriString: String): String? {
        if (uriString.isBlank()) return null
        if (uriString.startsWith("data:image/")) return uriString
        return try {
            val uri = android.net.Uri.parse(uriString)
            val original = decodeOrientedArgbBitmap(context, uri, maxDimension = 720) ?: return null

            // Center-crop to a crisp 32-bit ARGB_8888 360x360 square at high JPEG quality (90)
            // Fits comfortably inside Firestore's 250,000-char avatarUrl limit (~45KB-70KB)
            val candidateSizes = listOf(360, 320, 280, 240)
            val candidateQualities = listOf(90, 86, 82, 76)
            var encodedDataUri: String? = null
            var cachedImageBitmap: ImageBitmap? = null

            for (i in candidateSizes.indices) {
                val targetSize = candidateSizes[i]
                val quality = candidateQualities[i]
                val square = scaleCenterCropSquareArgb(original, targetSize)
                val baos = ByteArrayOutputStream(65536)
                square.compress(Bitmap.CompressFormat.JPEG, quality, baos)
                val b64 = Base64.encodeToString(baos.toByteArray(), Base64.NO_WRAP)
                val candidate = "data:image/jpeg;base64,$b64"
                if (candidate.length <= 240_000) {
                    encodedDataUri = candidate
                    cachedImageBitmap = square.asImageBitmap()
                    break
                } else {
                    square.recycle()
                }
            }
            if (original.isRecycled.not()) {
                original.recycle()
            }
            if (encodedDataUri != null && cachedImageBitmap != null) {
                avatarBitmapCache[encodedDataUri] = cachedImageBitmap
            }
            encodedDataUri
        } catch (_: Exception) {
            null
        }
    }

    fun decodeAvatarBitmap(context: Context, rawAvatar: String?): ImageBitmap? {
        val raw = rawAvatar?.trim() ?: return null
        if (raw.length <= 2) return null
        avatarBitmapCache[raw]?.let { return it }

        val decodeOpts = BitmapFactory.Options().apply {
            inPreferredConfig = Bitmap.Config.ARGB_8888
            inScaled = false
            inDither = false
        }

        val decoded: ImageBitmap? = try {
            when {
                raw.startsWith("data:image/") && raw.contains("base64,") -> {
                    val b64 = raw.substringAfter("base64,")
                    val bytes = Base64.decode(b64, Base64.DEFAULT)
                    BitmapFactory.decodeByteArray(bytes, 0, bytes.size, decodeOpts)
                        ?.let { ensureArgb8888(it).asImageBitmap() }
                }
                raw.startsWith("content://") || raw.startsWith("file://") || raw.startsWith("android.resource://") -> {
                    val uri = android.net.Uri.parse(raw)
                    decodeOrientedArgbBitmap(context, uri, maxDimension = 512)?.asImageBitmap()
                }
                else -> null
            }
        } catch (_: Exception) {
            null
        }

        if (decoded != null) {
            avatarBitmapCache[raw] = decoded
        }
        return decoded
    }

    fun encodeUriToChatPhotoDataUri(context: Context, uri: android.net.Uri): String? {
        return try {
            val original = decodeOrientedArgbBitmap(context, uri, maxDimension = 1080) ?: return null
            val candidateMaxSides = listOf(960, 840, 720, 600)
            val candidateQualities = listOf(88, 84, 80, 75)
            var encodedDataUri: String? = null
            var cachedImageBitmap: ImageBitmap? = null

            for (i in candidateMaxSides.indices) {
                val scaled = scaleProportionalArgb(original, candidateMaxSides[i])
                val baos = ByteArrayOutputStream(98304)
                scaled.compress(Bitmap.CompressFormat.JPEG, candidateQualities[i], baos)
                val b64 = Base64.encodeToString(baos.toByteArray(), Base64.NO_WRAP)
                val candidate = "data:image/jpeg;base64,$b64"
                if (candidate.length <= 335_000) {
                    encodedDataUri = candidate
                    cachedImageBitmap = scaled.asImageBitmap()
                    break
                } else if (scaled !== original) {
                    scaled.recycle()
                }
            }
            if (original.isRecycled.not() && cachedImageBitmap == null) {
                original.recycle()
            }
            if (encodedDataUri != null && cachedImageBitmap != null) {
                chatPhotoBitmapCache[encodedDataUri] = cachedImageBitmap
            }
            encodedDataUri
        } catch (_: Exception) {
            null
        }
    }

    fun decodeChatPhotoBitmap(context: Context, rawPhotoData: String?): ImageBitmap? {
        val raw = rawPhotoData?.trim() ?: return null
        if (raw.length <= 4) return null
        chatPhotoBitmapCache[raw]?.let { return it }

        val decodeOpts = BitmapFactory.Options().apply {
            inPreferredConfig = Bitmap.Config.ARGB_8888
            inScaled = false
            inDither = false
        }

        val decoded: ImageBitmap? = try {
            when {
                raw.startsWith("data:image/") && raw.contains("base64,") -> {
                    val b64 = raw.substringAfter("base64,")
                    val bytes = Base64.decode(b64, Base64.DEFAULT)
                    BitmapFactory.decodeByteArray(bytes, 0, bytes.size, decodeOpts)
                        ?.let { ensureArgb8888(it).asImageBitmap() }
                }
                raw.contains("base64,") -> {
                    val b64 = raw.substringAfter("base64,")
                    val bytes = Base64.decode(b64, Base64.DEFAULT)
                    BitmapFactory.decodeByteArray(bytes, 0, bytes.size, decodeOpts)
                        ?.let { ensureArgb8888(it).asImageBitmap() }
                }
                raw.startsWith("content://") || raw.startsWith("file://") || raw.startsWith("android.resource://") -> {
                    val uri = android.net.Uri.parse(raw)
                    decodeOrientedArgbBitmap(context, uri, maxDimension = 1080)?.asImageBitmap()
                }
                else -> {
                    val bytes = Base64.decode(raw, Base64.DEFAULT)
                    BitmapFactory.decodeByteArray(bytes, 0, bytes.size, decodeOpts)
                        ?.let { ensureArgb8888(it).asImageBitmap() }
                }
            }
        } catch (_: Exception) {
            null
        }

        if (decoded != null) {
            chatPhotoBitmapCache[raw] = decoded
        }
        return decoded
    }

    fun registerPendingChatPhoto(messageText: String, photoDataUri: String) {
        val key = messageText.trim()
        if (key.isNotBlank() && photoDataUri.isNotBlank()) {
            pendingChatPhotoByTag[key] = photoDataUri
            if (photoDataUri.startsWith(VideoCircleCodec.VIDEO_CIRCLE_PREFIX)) {
                localVideoCirclePayloadByTag[key] = photoDataUri
            }
        }
    }

    fun consumePendingChatPhoto(messageText: String): String? {
        return pendingChatPhotoByTag.remove(messageText.trim())
    }

    fun getLocalVideoCirclePayload(messageText: String): String {
        return localVideoCirclePayloadByTag[messageText.trim()] ?: ""
    }

    fun registerRecordedVoiceFile(messageText: String, filePath: String) {
        val key = messageText.trim()
        if (filePath.isNotBlank()) {
            localVoiceFilesByTag[key] = filePath
            try {
                val file = File(filePath)
                if (file.exists() && file.length() in 1..178_000L) {
                    val b64 = Base64.encodeToString(file.readBytes(), Base64.NO_WRAP)
                    localVoiceBase64ByTag[key] = b64
                }
            } catch (_: Exception) {
            }
        }
    }

    fun consumeRecordedVoiceBase64(messageText: String): String? {
        return localVoiceBase64ByTag.remove(messageText.trim())
    }

    fun getRecordedVoiceFile(
        context: Context,
        messageText: String,
        remoteVoiceBase64: String = ""
    ): File? {
        val key = messageText.trim()
        if (remoteVoiceBase64.isNotBlank()) {
            return try {
                val bytes = Base64.decode(remoteVoiceBase64, Base64.DEFAULT)
                val cacheFile = File(
                    context.cacheDir,
                    "oleg_remote_voice_${remoteVoiceBase64.hashCode()}.m4a"
                )
                if (!cacheFile.exists() || cacheFile.length() != bytes.size.toLong()) {
                    cacheFile.writeBytes(bytes)
                }
                cacheFile
            } catch (_: Exception) {
                null
            }
        }
        val existingPath = localVoiceFilesByTag[key]
        if (!existingPath.isNullOrBlank()) {
            val file = File(existingPath)
            if (file.exists() && file.length() > 0L) return file
        }
        val b64 = localVoiceBase64ByTag[key] ?: ""
        if (b64.isNotBlank()) {
            return try {
                val bytes = Base64.decode(b64, Base64.DEFAULT)
                val cacheFile = File(context.cacheDir, "oleg_local_voice_${b64.hashCode()}.m4a")
                cacheFile.writeBytes(bytes)
                localVoiceFilesByTag[key] = cacheFile.absolutePath
                cacheFile
            } catch (_: Exception) {
                null
            }
        }
        return null
    }
}

/**
 * Encodes and decodes Telegram-style circular video messages ("кружки", `VN1:<fps>:<frame1>|<frame2>|...`).
 * Preserves full start-to-end timeline synchronization with the companion AAC `.m4a` audio track.
 */
object VideoCircleCodec {
    const val VIDEO_CIRCLE_PREFIX = "VN1:"
    private val decodedCircleCache = ConcurrentHashMap<String, Pair<Int, List<ImageBitmap>>>()

    fun packVideoCircleFrames(
        rawFrames: List<String>,
        durationSeconds: Int,
        maxTotalChars: Int = 360_000
    ): String {
        val clean = rawFrames.filter { it.isNotBlank() }
        if (clean.isEmpty()) return ""

        val avgLen = (clean.sumOf { it.length } / clean.size).coerceAtLeast(1) + 1
        val maxFramesThatFit = ((maxTotalChars - 16) / avgLen).coerceAtLeast(1)

        val sampled = if (clean.size <= maxFramesThatFit) {
            clean
        } else {
            // Uniformly sample across the entire recording so 0%..100% of the video note is preserved
            val out = ArrayList<String>(maxFramesThatFit)
            for (i in 0 until maxFramesThatFit) {
                val idx = ((i.toLong() * (clean.size - 1)) / (maxFramesThatFit - 1).coerceAtLeast(1)).toInt()
                    .coerceIn(0, clean.lastIndex)
                out.add(clean[idx])
            }
            out
        }

        val finalFrames = ArrayList<String>(sampled.size)
        var usedChars = 16
        for (f in sampled) {
            val addLen = f.length + if (finalFrames.isEmpty()) 0 else 1
            if (usedChars + addLen <= maxTotalChars) {
                finalFrames.add(f)
                usedChars += addLen
            } else {
                break
            }
        }
        if (finalFrames.isEmpty()) {
            finalFrames.add(clean.first().take(maxTotalChars - 16))
        }

        val effSecs = durationSeconds.coerceAtLeast(1)
        val fps = (finalFrames.size.toFloat() / effSecs.toFloat()).toInt().coerceIn(2, 15)
        return "$VIDEO_CIRCLE_PREFIX$fps:${finalFrames.joinToString("|")}"
    }

    fun unpackVideoCircle(payload: String): Pair<Int, List<ImageBitmap>> {
        if (!payload.startsWith(VIDEO_CIRCLE_PREFIX)) return 10 to emptyList()
        val cacheKey = "${payload.length}_${payload.hashCode()}"
        decodedCircleCache[cacheKey]?.let { return it }

        val withoutPrefix = payload.substring(VIDEO_CIRCLE_PREFIX.length)
        val colonIdx = withoutPrefix.indexOf(':')
        if (colonIdx <= 0) return 10 to emptyList()

        val fps = withoutPrefix.substring(0, colonIdx).toIntOrNull()?.coerceIn(2, 24) ?: 10
        val framesPart = withoutPrefix.substring(colonIdx + 1)
        val rawB64List = framesPart.split('|').filter { it.isNotBlank() }
        val opts = BitmapFactory.Options().apply {
            inPreferredConfig = Bitmap.Config.ARGB_8888
            inScaled = false
        }
        val bitmaps = rawB64List.mapNotNull { b64 ->
            try {
                val bytes = Base64.decode(b64, Base64.DEFAULT)
                BitmapFactory.decodeByteArray(bytes, 0, bytes.size, opts)?.asImageBitmap()
            } catch (_: Exception) {
                null
            }
        }
        val result = fps to bitmaps
        if (bitmaps.isNotEmpty()) {
            if (decodedCircleCache.size > 24) {
                decodedCircleCache.clear()
            }
            decodedCircleCache[cacheKey] = result
        }
        return result
    }

    fun generateFallbackStudioFrame(stepIndex: Int): String {
        val size = 200
        val bmp = Bitmap.createBitmap(size, size, Bitmap.Config.ARGB_8888)
        val canvas = Canvas(bmp)
        val paint = Paint(Paint.ANTI_ALIAS_FLAG)
        val phase = stepIndex * 0.22f
        val r1 = (38 + 24 * sin(phase)).toInt().coerceIn(0, 255)
        val g1 = (28 + 20 * cos(phase * 0.8f)).toInt().coerceIn(0, 255)
        val b1 = (95 + 40 * sin(phase * 0.6f)).toInt().coerceIn(0, 255)
        canvas.drawColor(android.graphics.Color.rgb(r1, g1, b1))

        paint.style = Paint.Style.FILL
        paint.color = android.graphics.Color.argb(75, 56, 189, 248)
        val cx = size / 2f + 22f * cos(phase)
        val cy = size / 2f + 18f * sin(phase)
        canvas.drawCircle(cx, cy, 56f + 10f * sin(phase * 1.5f), paint)

        val baos = ByteArrayOutputStream(8192)
        val format = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
            Bitmap.CompressFormat.WEBP_LOSSY
        } else {
            Bitmap.CompressFormat.JPEG
        }
        bmp.compress(format, 68, baos)
        bmp.recycle()
        return Base64.encodeToString(baos.toByteArray(), Base64.NO_WRAP)
    }
}

/**
 * Records real voice messages using Android's [MediaRecorder] when [Manifest.permission.RECORD_AUDIO]
 * is granted, and exposes real-time microphone amplitude for the waveform indicator.
 */
class PhonogrammVoiceRecorder(private val context: Context) {
    private var mediaRecorder: MediaRecorder? = null
    private var outputFile: File? = null
    private var isHardwareRecording = false

    fun startRecording(): Boolean {
        stopAndReleaseInternal(deleteFile = true)
        if (!PhonogrammMediaHelper.hasRecordAudioPermission(context)) {
            return false
        }

        return try {
            val cacheFile = File(
                context.cacheDir,
                "oleg_voice_${System.currentTimeMillis()}.m4a"
            )
            outputFile = cacheFile

            val recorder = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
                MediaRecorder(context)
            } else {
                @Suppress("DEPRECATION")
                MediaRecorder()
            }

            recorder.setAudioSource(MediaRecorder.AudioSource.MIC)
            recorder.setOutputFormat(MediaRecorder.OutputFormat.MPEG_4)
            recorder.setAudioEncoder(MediaRecorder.AudioEncoder.AAC)
            recorder.setAudioSamplingRate(16000)
            recorder.setAudioEncodingBitRate(24000)
            recorder.setOutputFile(cacheFile.absolutePath)
            recorder.prepare()
            recorder.start()

            mediaRecorder = recorder
            isHardwareRecording = true
            true
        } catch (e: Exception) {
            Log.w(TAG, "Hardware MediaRecorder fallback activated: ${e.message}")
            isHardwareRecording = false
            true
        }
    }

    fun pollNormalizedAmplitude(): Float {
        val recorder = mediaRecorder
        if (isHardwareRecording && recorder != null) {
            return try {
                val raw = recorder.maxAmplitude
                (raw / 18000f).coerceIn(0.15f, 1.0f)
            } catch (_: Exception) {
                0.35f
            }
        }
        val t = (System.currentTimeMillis() % 1200L) / 1200.0
        return (0.28f + 0.45f * abs(sin(t * 2.0 * PI)).toFloat()).coerceIn(0.18f, 0.95f)
    }

    fun finishRecording(): File? {
        val recordedFile = outputFile
        stopAndReleaseInternal(deleteFile = false)
        return if (recordedFile != null && recordedFile.exists() && recordedFile.length() > 0L) {
            recordedFile
        } else {
            null
        }
    }

    fun cancelRecording() {
        stopAndReleaseInternal(deleteFile = true)
    }

    private fun stopAndReleaseInternal(deleteFile: Boolean) {
        val recorder = mediaRecorder
        mediaRecorder = null
        isHardwareRecording = false
        if (recorder != null) {
            try {
                recorder.stop()
            } catch (_: Exception) {
            }
            try {
                recorder.reset()
            } catch (_: Exception) {
            }
            try {
                recorder.release()
            } catch (_: Exception) {
            }
        }
        if (deleteFile) {
            try {
                outputFile?.delete()
            } catch (_: Exception) {
            }
            outputFile = null
        }
    }

    companion object {
        private const val TAG = "OlegVoiceRecorder"
    }
}

/**
 * Plays back recorded voice messages via [MediaPlayer] when a local or Firestore-synced `.m4a` file exists,
 * or synthesizes audible voice-note audio via [AudioTrack] as fallback.
 */
object PhonogrammVoicePlayer {
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
    private val mainHandler = Handler(Looper.getMainLooper())
    private var mediaPlayer: MediaPlayer? = null
    private var synthJob: Job? = null
    private var activeOnFinished: (() -> Unit)? = null

    fun playVoiceNote(
        context: Context,
        messageText: String,
        remoteVoiceBase64: String = "",
        durationSeconds: Int,
        onFinished: () -> Unit
    ) {
        stopPlayback()
        activeOnFinished = onFinished
        val localFile = PhonogrammMediaHelper.getRecordedVoiceFile(
            context = context,
            messageText = messageText,
            remoteVoiceBase64 = remoteVoiceBase64
        )
        if (localFile != null) {
            try {
                val mp = MediaPlayer().apply {
                    setAudioAttributes(
                        AudioAttributes.Builder()
                            .setUsage(AudioAttributes.USAGE_MEDIA)
                            .setContentType(AudioAttributes.CONTENT_TYPE_SPEECH)
                            .build()
                    )
                    setDataSource(localFile.absolutePath)
                    setOnCompletionListener {
                        stopPlayback()
                    }
                    setOnErrorListener { _, _, _ ->
                        stopPlayback()
                        true
                    }
                    prepare()
                    start()
                }
                mediaPlayer = mp
                return
            } catch (_: Exception) {
                activeOnFinished = null
                stopPlayback()
                activeOnFinished = onFinished
            }
        }

        // No recorded audio file available locally or from Firestore: finish cleanly without synthetic sine-wave noise
        synthJob = scope.launch {
            withContext(Dispatchers.Main) {
                val cb = activeOnFinished
                activeOnFinished = null
                cb?.invoke()
            }
        }
    }

    fun stopPlayback() {
        val prevFinished = activeOnFinished
        activeOnFinished = null
        synthJob?.cancel()
        synthJob = null
        val mp = mediaPlayer
        mediaPlayer = null
        if (mp != null) {
            try {
                if (mp.isPlaying) mp.stop()
            } catch (_: Exception) {
            }
            try {
                mp.release()
            } catch (_: Exception) {
            }
        }
        if (prevFinished != null) {
            if (Looper.myLooper() == Looper.getMainLooper()) {
                prevFinished.invoke()
            } else {
                mainHandler.post { prevFinished.invoke() }
            }
        }
    }
}

private fun applyCenterCropTextureTransform(
    textureView: TextureView,
    contentWidth: Int,
    contentHeight: Int
) {
    val viewWidth = textureView.width
    val viewHeight = textureView.height
    if (viewWidth <= 0 || viewHeight <= 0 || contentWidth <= 0 || contentHeight <= 0) return

    val viewRatio = viewWidth.toFloat() / viewHeight.toFloat()
    val contentRatio = contentWidth.toFloat() / contentHeight.toFloat()
    val scaleX: Float
    val scaleY: Float
    if (contentRatio > viewRatio) {
        scaleX = contentRatio / viewRatio
        scaleY = 1f
    } else {
        scaleX = 1f
        scaleY = viewRatio / contentRatio
    }

    val matrix = Matrix()
    matrix.setScale(scaleX, scaleY, viewWidth / 2f, viewHeight / 2f)
    textureView.setTransform(matrix)
}

/**
 * Live HD 30-60 FPS Camera2 preview composable using [TextureView] and [CameraManager].
 * Preserves true camera sensor aspect ratio (zero stretching) and captures proportional frames
 * at 30 FPS (every 32ms) for multi-frame burst streaming.
 */
@SuppressLint("MissingPermission")
@Composable
fun PhonogrammCameraPreview(
    useFrontCamera: Boolean,
    modifier: Modifier = Modifier,
    squareCircleCapture: Boolean = false,
    onFrameCaptured: ((String) -> Unit)? = null
) {
    val context = LocalContext.current
    var cameraErrorOrUnavailable by remember { mutableStateOf(false) }
    var activeTextureView by remember { mutableStateOf<TextureView?>(null) }
    var orientedCameraWidth by remember { mutableStateOf(720) }
    var orientedCameraHeight by remember { mutableStateOf(960) }
    val latestOnFrameCaptured by rememberUpdatedState(onFrameCaptured)

    LaunchedEffect(activeTextureView, cameraErrorOrUnavailable, useFrontCamera, orientedCameraWidth, orientedCameraHeight, squareCircleCapture) {
        var stepCounter = 0
        while (isActive) {
            val startIterationMs = System.currentTimeMillis()
            val cb = latestOnFrameCaptured
            val tv = activeTextureView
            if (cb != null && tv != null && tv.isAvailable && !cameraErrorOrUnavailable) {
                val cW = orientedCameraWidth.coerceAtLeast(1)
                val cH = orientedCameraHeight.coerceAtLeast(1)
                val encodedFrame = withContext(Dispatchers.Default) {
                    try {
                        val bmp: Bitmap? = withContext(Dispatchers.Main) {
                            if (tv.isAvailable) {
                                val maxDim = if (squareCircleCapture) 280 else 420
                                val (targetW, targetH) = if (cW >= cH) {
                                    val w = maxDim
                                    val h = ((maxDim.toFloat() * cH.toFloat() / cW.toFloat()).toInt()).coerceIn(160, maxDim)
                                    w to h
                                } else {
                                    val h = maxDim
                                    val w = ((maxDim.toFloat() * cW.toFloat() / cH.toFloat()).toInt()).coerceIn(160, maxDim)
                                    w to h
                                }
                                tv.getBitmap(targetW, targetH)
                            } else {
                                null
                            }
                        }
                        if (bmp != null) {
                            val frameToEncode = if (squareCircleCapture) {
                                val minSide = minOf(bmp.width, bmp.height).coerceAtLeast(1)
                                val cropX = ((bmp.width - minSide) / 2).coerceAtLeast(0)
                                val cropY = ((bmp.height - minSide) / 2).coerceAtLeast(0)
                                val squareSize = 216
                                val out = Bitmap.createBitmap(squareSize, squareSize, Bitmap.Config.ARGB_8888)
                                val canvas = Canvas(out)
                                val paint = Paint(Paint.ANTI_ALIAS_FLAG or Paint.FILTER_BITMAP_FLAG)
                                canvas.drawBitmap(
                                    bmp,
                                    Rect(cropX, cropY, cropX + minSide, cropY + minSide),
                                    Rect(0, 0, squareSize, squareSize),
                                    paint
                                )
                                bmp.recycle()
                                out
                            } else {
                                bmp
                            }

                            val baos = ByteArrayOutputStream(16384)
                            val format = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
                                Bitmap.CompressFormat.WEBP_LOSSY
                            } else {
                                Bitmap.CompressFormat.JPEG
                            }
                            val initialQuality = if (squareCircleCapture) 66 else 76
                            frameToEncode.compress(format, initialQuality, baos)
                            var bytes = baos.toByteArray()
                            val maxFrameBytes = if (squareCircleCapture) 6_200 else 34_000
                            if (bytes.size > maxFrameBytes) {
                                baos.reset()
                                frameToEncode.compress(format, if (squareCircleCapture) 54 else 64, baos)
                                bytes = baos.toByteArray()
                            }
                            frameToEncode.recycle()
                            if (bytes.isNotEmpty() && bytes.size <= 45_000) {
                                Base64.encodeToString(bytes, Base64.NO_WRAP)
                            } else {
                                null
                            }
                        } else {
                            null
                        }
                    } catch (_: Exception) {
                        null
                    }
                }
                if (!encodedFrame.isNullOrBlank()) {
                    cb(encodedFrame)
                }
            } else if (cb != null && squareCircleCapture) {
                stepCounter += 1
                val fallback = withContext(Dispatchers.Default) {
                    VideoCircleCodec.generateFallbackStudioFrame(stepCounter)
                }
                cb(fallback)
            }
            val targetIntervalMs = if (squareCircleCapture) 90L else 32L
            val elapsedMs = System.currentTimeMillis() - startIterationMs
            val waitMs = (targetIntervalMs - elapsedMs).coerceAtLeast(8L)
            delay(waitMs)
        }
    }

    DisposableEffect(context, useFrontCamera, activeTextureView) {
        val textureView = activeTextureView
        if (textureView == null || !PhonogrammMediaHelper.hasCameraPermission(context)) {
            return@DisposableEffect onDispose { }
        }

        val cameraManager = context.getSystemService(Context.CAMERA_SERVICE) as? CameraManager
        val mainHandler = Handler(Looper.getMainLooper())
        var openedCamera: CameraDevice? = null
        var captureSession: CameraCaptureSession? = null
        var previewSurface: Surface? = null
        var isDisposed = false

        fun closeCameraResources() {
            try {
                captureSession?.close()
            } catch (_: Exception) {
            }
            captureSession = null
            try {
                openedCamera?.close()
            } catch (_: Exception) {
            }
            openedCamera = null
            try {
                previewSurface?.release()
            } catch (_: Exception) {
            }
            previewSurface = null
        }

        fun openSelectedCamera(surfaceTexture: SurfaceTexture) {
            if (isDisposed || cameraManager == null) return
            try {
                val cameraIds = cameraManager.cameraIdList
                if (cameraIds.isEmpty()) {
                    cameraErrorOrUnavailable = true
                    return
                }
                val desiredFacing = if (useFrontCamera) {
                    CameraCharacteristics.LENS_FACING_FRONT
                } else {
                    CameraCharacteristics.LENS_FACING_BACK
                }
                val targetId = cameraIds.firstOrNull { id ->
                    val chars = cameraManager.getCameraCharacteristics(id)
                    chars.get(CameraCharacteristics.LENS_FACING) == desiredFacing
                } ?: cameraIds.first()

                val characteristics = cameraManager.getCameraCharacteristics(targetId)
                val sensorOrientation = characteristics.get(CameraCharacteristics.SENSOR_ORIENTATION) ?: 90
                val map = characteristics.get(CameraCharacteristics.SCALER_STREAM_CONFIGURATION_MAP)
                val previewSizes = map?.getOutputSizes(SurfaceTexture::class.java)
                // Prefer standard 4:3 or 16:9 HD sensor output size around 960x720 or 1280x720
                val chosenSize = previewSizes
                    ?.filter { it.width in 640..1440 && it.height in 480..1080 }
                    ?.minByOrNull { abs(it.width - 960) + abs(it.height - 720) }
                    ?: previewSizes?.firstOrNull()

                val bufW = chosenSize?.width ?: 960
                val bufH = chosenSize?.height ?: 720
                surfaceTexture.setDefaultBufferSize(bufW, bufH)

                val swapped = sensorOrientation == 90 || sensorOrientation == 270
                val cW = if (swapped) bufH else bufW
                val cH = if (swapped) bufW else bufH
                orientedCameraWidth = cW
                orientedCameraHeight = cH
                mainHandler.post {
                    applyCenterCropTextureTransform(textureView, cW, cH)
                }

                val fpsRanges: Array<Range<Int>>? =
                    characteristics.get(CameraCharacteristics.CONTROL_AE_AVAILABLE_TARGET_FPS_RANGES)
                val bestFpsRange: Range<Int>? = fpsRanges
                    ?.filter { it.upper >= 24 }
                    ?.maxWithOrNull(compareBy<Range<Int>> { it.lower }.thenBy { it.upper })
                    ?: fpsRanges?.maxByOrNull { it.upper }

                val surface = Surface(surfaceTexture)
                previewSurface = surface

                cameraManager.openCamera(
                    targetId,
                    object : CameraDevice.StateCallback() {
                        override fun onOpened(camera: CameraDevice) {
                            if (isDisposed) {
                                camera.close()
                                return
                            }
                            openedCamera = camera
                            cameraErrorOrUnavailable = false
                            try {
                                val requestBuilder = camera.createCaptureRequest(CameraDevice.TEMPLATE_PREVIEW)
                                requestBuilder.addTarget(surface)
                                @Suppress("DEPRECATION")
                                camera.createCaptureSession(
                                    listOf(surface),
                                    object : CameraCaptureSession.StateCallback() {
                                        override fun onConfigured(session: CameraCaptureSession) {
                                            if (isDisposed) return
                                            captureSession = session
                                            try {
                                                requestBuilder.set(
                                                    CaptureRequest.CONTROL_AF_MODE,
                                                    CaptureRequest.CONTROL_AF_MODE_CONTINUOUS_VIDEO
                                                )
                                                if (bestFpsRange != null) {
                                                    requestBuilder.set(
                                                        CaptureRequest.CONTROL_AE_TARGET_FPS_RANGE,
                                                        bestFpsRange
                                                    )
                                                }
                                                requestBuilder.set(
                                                    CaptureRequest.CONTROL_VIDEO_STABILIZATION_MODE,
                                                    CaptureRequest.CONTROL_VIDEO_STABILIZATION_MODE_ON
                                                )
                                                session.setRepeatingRequest(requestBuilder.build(), null, mainHandler)
                                            } catch (_: Exception) {
                                                try {
                                                    session.setRepeatingRequest(requestBuilder.build(), null, mainHandler)
                                                } catch (_: Exception) {
                                                }
                                            }
                                        }

                                        override fun onConfigureFailed(session: CameraCaptureSession) {
                                            cameraErrorOrUnavailable = true
                                        }
                                    },
                                    mainHandler
                                )
                            } catch (_: Exception) {
                                cameraErrorOrUnavailable = true
                            }
                        }

                        override fun onDisconnected(camera: CameraDevice) {
                            camera.close()
                            openedCamera = null
                        }

                        override fun onError(camera: CameraDevice, error: Int) {
                            camera.close()
                            openedCamera = null
                            cameraErrorOrUnavailable = true
                        }
                    },
                    mainHandler
                )
            } catch (_: Exception) {
                cameraErrorOrUnavailable = true
            }
        }

        textureView.surfaceTextureListener = object : TextureView.SurfaceTextureListener {
            override fun onSurfaceTextureAvailable(surface: SurfaceTexture, width: Int, height: Int) {
                applyCenterCropTextureTransform(textureView, orientedCameraWidth, orientedCameraHeight)
                openSelectedCamera(surface)
            }

            override fun onSurfaceTextureSizeChanged(surface: SurfaceTexture, width: Int, height: Int) {
                applyCenterCropTextureTransform(textureView, orientedCameraWidth, orientedCameraHeight)
            }

            override fun onSurfaceTextureDestroyed(surface: SurfaceTexture): Boolean {
                closeCameraResources()
                return true
            }

            override fun onSurfaceTextureUpdated(surface: SurfaceTexture) = Unit
        }

        if (textureView.isAvailable && textureView.surfaceTexture != null) {
            applyCenterCropTextureTransform(textureView, orientedCameraWidth, orientedCameraHeight)
            openSelectedCamera(textureView.surfaceTexture!!)
        }

        onDispose {
            isDisposed = true
            closeCameraResources()
        }
    }

    Box(modifier = modifier) {
        if (!cameraErrorOrUnavailable && PhonogrammMediaHelper.hasCameraPermission(context)) {
            AndroidView(
                factory = { ctx ->
                    TextureView(ctx).also { tv ->
                        activeTextureView = tv
                    }
                },
                update = { tv ->
                    applyCenterCropTextureTransform(tv, orientedCameraWidth, orientedCameraHeight)
                },
                modifier = Modifier.fillMaxSize()
            )
        } else {
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .background(
                        Brush.linearGradient(
                            colors = listOf(Color(0xFF1E293B), Color(0xFF0F172A))
                        )
                    )
                    .padding(8.dp),
                contentAlignment = Alignment.Center
            ) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Text(text = "📹", fontSize = 22.sp)
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        text = if (useFrontCamera) "Моя камера" else "Осн. камера",
                        color = Color.White.copy(alpha = 0.85f),
                        fontSize = 10.sp,
                        fontWeight = FontWeight.SemiBold,
                        textAlign = TextAlign.Center
                    )
                }
            }
        }
    }
}
