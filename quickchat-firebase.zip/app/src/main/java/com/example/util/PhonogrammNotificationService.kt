package com.example.util

import android.app.Service
import android.content.Intent
import android.os.IBinder
import com.google.firebase.Firebase
import com.google.firebase.auth.auth

/**
 * Background service that keeps Cloud Firestore incoming-message listeners active
 * when the user minimizes or exits the app so push notifications ("Новое сообщение от @...")
 * arrive reliably in real time on every message.
 */
class PhonogrammNotificationService : Service() {

    override fun onCreate() {
        super.onCreate()
        PhonogrammNotificationHelper.ensureNotificationChannel(applicationContext)
        val currentUid = Firebase.auth.currentUser?.uid
        if (!currentUid.isNullOrBlank()) {
            PhonogrammNotificationHelper.startMonitoring(applicationContext, currentUid)
        }
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        PhonogrammNotificationHelper.ensureNotificationChannel(applicationContext)
        val uidFromIntent = intent?.getStringExtra(EXTRA_USER_ID)
        val effectiveUid = uidFromIntent?.takeIf { it.isNotBlank() } ?: Firebase.auth.currentUser?.uid
        if (!effectiveUid.isNullOrBlank()) {
            PhonogrammNotificationHelper.startMonitoring(applicationContext, effectiveUid)
            return START_STICKY
        } else {
            stopSelf()
            return START_NOT_STICKY
        }
    }

    override fun onBind(intent: Intent?): IBinder? = null

    companion object {
        const val EXTRA_USER_ID = "extra_user_id"
    }
}
