package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.systemBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.foundation.Image
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.res.painterResource
import androidx.credentials.CredentialManager
import com.example.R
import com.example.ui.auth.attemptAutoSignIn
import com.example.ui.auth.onGoogleSignInClicked
import com.example.ui.theme.LocalDeviceOptimizationMode
import com.example.ui.theme.LocalPhonogrammPalette

@Composable
fun AuthScreen(
    onAuthSuccess: () -> Unit,
    modifier: Modifier = Modifier
) {
    val palette = LocalPhonogrammPalette.current
    val isOldDevice = LocalDeviceOptimizationMode.current.isOldDeviceMode
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val credentialManager = remember(context) { CredentialManager.create(context) }

    var isLoading by remember { mutableStateOf(true) }
    var errorMessage by remember { mutableStateOf<String?>(null) }
    var selectedTab by remember { mutableStateOf("login") }

    LaunchedEffect(Unit) {
        attemptAutoSignIn(
            context = context,
            credentialManager = credentialManager,
            onAuthSuccess = {
                isLoading = false
                onAuthSuccess()
            },
            onUnauthenticated = {
                isLoading = false
            },
            scope = scope
        )
    }

    val triggerGoogleSignIn: () -> Unit = {
        if (!isLoading) {
            isLoading = true
            errorMessage = null
            onGoogleSignInClicked(
                context = context,
                credentialManager = credentialManager,
                onAuthSuccess = {
                    isLoading = false
                    onAuthSuccess()
                },
                onAuthError = { err ->
                    isLoading = false
                    errorMessage = err
                },
                scope = scope,
                onAuthCancelled = {
                    isLoading = false
                }
            )
        }
    }

    // #auth-modal background (dual radial glow from CSS lines 1397-1402)
    Box(
        modifier = modifier
            .fillMaxSize()
            .background(palette.bg)
            .then(
                if (isOldDevice) {
                    Modifier
                } else {
                    Modifier.drawBehind {
                        drawRect(
                            brush = Brush.radialGradient(
                                colors = listOf(
                                    Color(0xFF6366F1).copy(alpha = 0.22f),
                                    Color.Transparent
                                ),
                                center = Offset(size.width * 0.2f, size.height * 0.2f),
                                radius = size.maxDimension * 0.6f
                            )
                        )
                        drawRect(
                            brush = Brush.radialGradient(
                                colors = listOf(
                                    Color(0xFF06B6D4).copy(alpha = 0.16f),
                                    Color.Transparent
                                ),
                                center = Offset(size.width * 0.8f, size.height * 0.8f),
                                radius = size.maxDimension * 0.6f
                            )
                        )
                    }
                }
            )
            .systemBarsPadding()
            .padding(horizontal = 20.dp),
        contentAlignment = Alignment.Center
    ) {
        // .auth-card (max-width: 390px, border-radius: 24px, padding: 38px 32px, surfaceElevated, borderStrong)
        Surface(
            modifier = Modifier
                .fillMaxWidth()
                .widthIn(max = 390.dp)
                .then(
                    if (isOldDevice) Modifier else Modifier.shadow(28.dp, RoundedCornerShape(24.dp))
                )
                .clip(RoundedCornerShape(24.dp))
                .border(1.dp, palette.borderStrong, RoundedCornerShape(24.dp)),
            color = palette.surfaceElevated,
            shape = RoundedCornerShape(24.dp)
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 28.dp, vertical = 34.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                // .auth-logo with Oleg cosmic star brand avatar
                Box(
                    modifier = Modifier
                        .size(72.dp)
                        .then(
                            if (isOldDevice) Modifier
                            else Modifier.shadow(16.dp, RoundedCornerShape(22.dp), spotColor = palette.primary)
                        )
                        .clip(RoundedCornerShape(22.dp))
                        .background(Color(0xFF0C0926))
                        .border(1.5.dp, palette.primary.copy(alpha = 0.45f), RoundedCornerShape(22.dp)),
                    contentAlignment = Alignment.Center
                ) {
                    Image(
                        painter = painterResource(id = R.drawable.oleg_logo),
                        contentDescription = "Oleg",
                        contentScale = ContentScale.Crop,
                        modifier = Modifier.fillMaxSize()
                    )
                }

                Spacer(modifier = Modifier.height(20.dp))

                Text(
                    text = "Oleg",
                    color = palette.text,
                    fontSize = 24.sp,
                    fontWeight = FontWeight.ExtraBold
                )

                Spacer(modifier = Modifier.height(6.dp))

                Text(
                    text = "Быстрый и безопасный мессенджер.\nАвторизуйтесь для продолжения.",
                    color = palette.textSecondary,
                    fontSize = 13.5.sp,
                    textAlign = TextAlign.Center,
                    lineHeight = 19.sp
                )

                Spacer(modifier = Modifier.height(22.dp))

                // .auth-mode-tabs ("Вход" / "Регистрация")
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(14.dp))
                        .background(palette.bg)
                        .border(1.dp, palette.border, RoundedCornerShape(14.dp))
                        .padding(4.dp),
                    horizontalArrangement = Arrangement.spacedBy(4.dp)
                ) {
                    listOf("login" to "Вход", "register" to "Регистрация").forEach { (key, title) ->
                        val active = selectedTab == key
                        Box(
                            modifier = Modifier
                                .weight(1f)
                                .clip(RoundedCornerShape(10.dp))
                                .background(
                                    if (active) palette.surfaceElevated else Color.Transparent
                                )
                                .then(
                                    if (active) {
                                        Modifier.border(1.dp, palette.borderStrong, RoundedCornerShape(10.dp))
                                    } else {
                                        Modifier
                                    }
                                )
                                .clickable { selectedTab = key }
                                .padding(vertical = 9.dp),
                            contentAlignment = Alignment.Center
                        ) {
                            Text(
                                text = title,
                                color = if (active) palette.text else palette.textSecondary,
                                fontSize = 13.sp,
                                fontWeight = FontWeight.Bold
                            )
                        }
                    }
                }

                Spacer(modifier = Modifier.height(18.dp))

                // Cloud identity card explaining Google Sign-In + Nickname flow
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(14.dp))
                        .background(palette.bg)
                        .border(1.dp, palette.border, RoundedCornerShape(14.dp))
                        .padding(14.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Text(
                        text = if (selectedTab == "login") {
                            "🔐 Облачная авторизация Firebase"
                        } else {
                            "✨ Создание нового профиля"
                        },
                        color = palette.primary,
                        fontSize = 12.5.sp,
                        fontWeight = FontWeight.Bold
                    )
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        text = if (selectedTab == "login") {
                            "Войдите через Google аккаунт для мгновенной синхронизации ваших чатов, подарков и статуса."
                        } else {
                            "Подключите Google аккаунт, чтобы на следующем шаге выбрать уникальный @юзернейм и дату рождения."
                        },
                        color = palette.textSecondary,
                        fontSize = 12.sp,
                        textAlign = TextAlign.Center,
                        lineHeight = 17.sp
                    )
                }

                if (!errorMessage.isNullOrBlank()) {
                    Spacer(modifier = Modifier.height(14.dp))
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(12.dp))
                            .background(palette.errorSoft)
                            .border(1.dp, palette.error.copy(alpha = 0.35f), RoundedCornerShape(12.dp))
                            .padding(horizontal = 14.dp, vertical = 10.dp)
                            .testTag("auth_error_banner")
                    ) {
                        Text(
                            text = errorMessage ?: "",
                            color = palette.error,
                            fontSize = 12.5.sp,
                            fontWeight = FontWeight.SemiBold,
                            textAlign = TextAlign.Center,
                            modifier = Modifier.fillMaxWidth()
                        )
                    }
                }

                Spacer(modifier = Modifier.height(18.dp))

                // .auth-btn (width: 100%, padding: 14px, border-radius: 14px, background: var(--msg-out-bg))
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(50.dp)
                        .shadow(12.dp, RoundedCornerShape(14.dp), spotColor = palette.primary)
                        .clip(RoundedCornerShape(14.dp))
                        .background(palette.msgOutBrush)
                        .clickable(enabled = !isLoading, onClick = triggerGoogleSignIn)
                        .testTag("google_sign_in_button"),
                    contentAlignment = Alignment.Center
                ) {
                    if (isLoading) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.Center
                        ) {
                            CircularProgressIndicator(
                                modifier = Modifier.size(18.dp),
                                strokeWidth = 2.dp,
                                color = Color.White
                            )
                            Spacer(modifier = Modifier.width(10.dp))
                            Text(
                                text = "Вход...",
                                color = Color.White,
                                fontSize = 14.5.sp,
                                fontWeight = FontWeight.Bold
                            )
                        }
                    } else {
                        Text(
                            text = if (selectedTab == "login") {
                                "Войти в мессенджер (Google)"
                            } else {
                                "Создать аккаунт через Google"
                            },
                            color = Color.White,
                            fontSize = 14.5.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }
                }
            }
        }
    }
}
