package com.example.ui.screens

import android.Manifest
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.net.Uri
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.scaleIn
import androidx.compose.animation.scaleOut
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.filled.Send
import androidx.compose.animation.core.animateDpAsState
import androidx.compose.foundation.Canvas
import androidx.compose.material.icons.filled.AttachFile
import androidx.compose.material.icons.filled.Call
import androidx.compose.material.icons.filled.Cameraswitch
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.ContentCopy
import androidx.compose.material.icons.filled.KeyboardArrowDown
import androidx.compose.material.icons.filled.Mic
import androidx.compose.material.icons.filled.MoreVert
import androidx.compose.material.icons.filled.Pause
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Videocam
import androidx.compose.material.icons.filled.VolumeOff
import androidx.compose.material.icons.filled.VolumeUp
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.Icon
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.derivedStateOf
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.focus.onFocusChanged
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.FilterQuality
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.input.KeyboardCapitalization
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import com.example.data.model.ChatMessage
import com.example.data.model.DirectChat
import com.example.data.model.SystemBotMessage
import com.example.data.model.UserProfile
import com.example.ui.components.PhonogrammAvatar
import com.example.ui.components.PhonogrammSpatialChatBackground
import com.example.ui.components.VerifiedBadgeIcon
import com.example.ui.components.dashedRoundedBorder
import com.example.ui.components.rememberPresenceClockMillis
import com.example.ui.theme.LocalDeviceOptimizationMode
import com.example.ui.theme.LocalMessageFontSizeSp
import com.example.ui.theme.LocalPhonogrammPalette
import com.example.ui.viewmodel.UiState
import com.example.util.PhonogrammCameraPreview
import com.example.util.PhonogrammMediaHelper
import com.example.util.PhonogrammVoicePlayer
import com.example.util.PhonogrammVoiceRecorder
import com.example.util.VideoCircleCodec
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

@OptIn(ExperimentalFoundationApi::class)
@Composable
fun ChatDetailScreen(
    isSystemBotChat: Boolean,
    chat: DirectChat?,
    peerProfile: UserProfile?,
    currentUserProfile: UserProfile,
    messagesState: UiState<List<ChatMessage>>,
    replyingToMessage: ChatMessage?,
    isSending: Boolean,
    sendError: String?,
    onSendMessage: (String, () -> Unit) -> Unit,
    onSetReplyToMessage: (ChatMessage?) -> Unit,
    onOpenMessageActions: (ChatMessage) -> Unit,
    onOpenClearChatModal: () -> Unit,
    onOpenPeerProfile: (String) -> Unit,
    onStartAudioCall: (String) -> Unit,
    onStartVideoCall: (String) -> Unit,
    onClearSendError: () -> Unit,
    onBack: () -> Unit,
    onShowToast: (String) -> Unit = {},
    modifier: Modifier = Modifier
) {
    val palette = LocalPhonogrammPalette.current
    val isOldDeviceMode = LocalDeviceOptimizationMode.current.isOldDeviceMode
    val fontSizeSp = LocalMessageFontSizeSp.current
    val context = LocalContext.current

    val peerUsername = remember(isSystemBotChat, chat, peerProfile?.username, currentUserProfile.uid) {
        if (isSystemBotChat) {
            "__system__"
        } else {
            peerProfile?.username?.takeIf { it.isNotBlank() }
                ?: chat?.otherParticipantUsername(currentUserProfile.uid)?.takeIf { it.isNotBlank() }
                ?: chat?.otherParticipantId(currentUserProfile.uid)
                ?: ""
        }
    }

    var messageInput by rememberSaveable(peerUsername) { mutableStateOf("") }
    var showHeaderDropdown by remember { mutableStateOf(false) }
    var isInputFocused by remember { mutableStateOf(false) }

    // Attachment, Voice Record & Telegram Video Circle ("кружок") state
    var pendingAttachmentUri by remember { mutableStateOf<Uri?>(null) }
    var pendingAttachmentName by remember { mutableStateOf<String?>(null) }
    var pendingAttachmentDataUri by remember { mutableStateOf<String?>(null) }
    var isEncodingAttachment by remember { mutableStateOf(false) }
    var fullscreenPhotoDataUri by remember { mutableStateOf<String?>(null) }
    var isRecordingVoice by remember { mutableStateOf(false) }
    var isRecordingVideoCircle by remember { mutableStateOf(false) }
    var useFrontCameraForCircle by remember { mutableStateOf(true) }
    val capturedCircleFrames = remember { androidx.compose.runtime.mutableStateListOf<String>() }
    var voiceSeconds by remember { mutableIntStateOf(0) }
    var micAmplitude by remember { mutableFloatStateOf(0.25f) }

    val listState = rememberLazyListState()
    val coroutineScope = rememberCoroutineScope()

    val voiceRecorder = remember(context) { PhonogrammVoiceRecorder(context) }

    DisposableEffect(voiceRecorder) {
        onDispose {
            voiceRecorder.cancelRecording()
            PhonogrammVoicePlayer.stopPlayback()
        }
    }

    LaunchedEffect(peerUsername) {
        if (isRecordingVoice || isRecordingVideoCircle) {
            voiceRecorder.cancelRecording()
            capturedCircleFrames.clear()
            isRecordingVoice = false
            isRecordingVideoCircle = false
        }
        PhonogrammVoicePlayer.stopPlayback()
    }

    val finishAndSendRecording: () -> Unit = {
        val effectiveSecs = voiceSeconds.coerceAtLeast(1)
        val effMins = (effectiveSecs / 60).toString().padStart(2, '0')
        val effRemSecs = (effectiveSecs % 60).toString().padStart(2, '0')
        val durationFormatted = "$effMins:$effRemSecs"
        val recordedFile = voiceRecorder.finishRecording()

        if (isRecordingVideoCircle) {
            val circleMsgText = "🎥 Кружок ($durationFormatted)"
            if (recordedFile != null) {
                PhonogrammMediaHelper.registerRecordedVoiceFile(
                    circleMsgText,
                    recordedFile.absolutePath
                )
            }
            val framesSnapshot = capturedCircleFrames.toList().ifEmpty {
                listOf(
                    VideoCircleCodec.generateFallbackStudioFrame(1),
                    VideoCircleCodec.generateFallbackStudioFrame(2),
                    VideoCircleCodec.generateFallbackStudioFrame(3)
                )
            }
            val packedPayload = VideoCircleCodec.packVideoCircleFrames(
                rawFrames = framesSnapshot,
                durationSeconds = effectiveSecs
            )
            if (packedPayload.isNotBlank()) {
                PhonogrammMediaHelper.registerPendingChatPhoto(
                    circleMsgText,
                    packedPayload
                )
            }
            capturedCircleFrames.clear()
            isRecordingVideoCircle = false
            onSendMessage(circleMsgText) {}
        } else if (isRecordingVoice) {
            val voiceMsgText = "🎤 Голосовое сообщение ($durationFormatted)"
            if (recordedFile != null) {
                PhonogrammMediaHelper.registerRecordedVoiceFile(
                    voiceMsgText,
                    recordedFile.absolutePath
                )
            }
            isRecordingVoice = false
            onSendMessage(voiceMsgText) {}
        }
    }

    val voiceRecordPermissionLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.RequestPermission()
    ) { granted ->
        if (granted) {
            PhonogrammVoicePlayer.stopPlayback()
            if (voiceRecorder.startRecording()) {
                isRecordingVideoCircle = false
                isRecordingVoice = true
            }
        } else {
            onShowToast("Для записи голосовых сообщений необходимо разрешение на использование микрофона 🎤")
        }
    }

    val videoCirclePermissionsLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.RequestMultiplePermissions()
    ) { permissions ->
        val micGranted = permissions[Manifest.permission.RECORD_AUDIO] == true ||
            PhonogrammMediaHelper.hasRecordAudioPermission(context)
        val camGranted = permissions[Manifest.permission.CAMERA] == true ||
            PhonogrammMediaHelper.hasCameraPermission(context)
        if (micGranted && camGranted) {
            PhonogrammVoicePlayer.stopPlayback()
            capturedCircleFrames.clear()
            if (voiceRecorder.startRecording()) {
                isRecordingVoice = false
                isRecordingVideoCircle = true
            }
        } else {
            onShowToast("Для записи видеокружка необходим доступ к камере и микрофону 🎥🎤")
        }
    }

    val audioCallPermissionLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.RequestPermission()
    ) { granted ->
        if (granted) {
            onStartAudioCall(peerUsername)
        } else {
            onShowToast("Для совершения аудиозвонка необходимо разрешение на использование микрофона 🎤")
        }
    }

    val videoCallPermissionsLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.RequestMultiplePermissions()
    ) { permissions ->
        val micGranted = permissions[Manifest.permission.RECORD_AUDIO] == true ||
            PhonogrammMediaHelper.hasRecordAudioPermission(context)
        val camGranted = permissions[Manifest.permission.CAMERA] == true ||
            PhonogrammMediaHelper.hasCameraPermission(context)
        when {
            micGranted && camGranted -> onStartVideoCall(peerUsername)
            micGranted -> {
                onShowToast("Доступ к камере отклонён — звонок запущен в аудиорежиме 🎤")
                onStartAudioCall(peerUsername)
            }
            else -> {
                onShowToast("Для видеозвонка необходим доступ к микрофону и камере 🎤📹")
            }
        }
    }

    val photoPickerLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.PickVisualMedia()
    ) { uri ->
        if (uri != null) {
            pendingAttachmentUri = uri
            pendingAttachmentName = "Фотография_${System.currentTimeMillis() % 10000}.jpg"
            isEncodingAttachment = true
            coroutineScope.launch {
                val encoded = kotlinx.coroutines.withContext(kotlinx.coroutines.Dispatchers.Default) {
                    PhonogrammMediaHelper.encodeUriToChatPhotoDataUri(context, uri)
                }
                pendingAttachmentDataUri = encoded
                isEncodingAttachment = false
                if (encoded == null) {
                    onShowToast("Не удалось обработать выбранное фото")
                    pendingAttachmentUri = null
                    pendingAttachmentName = null
                }
            }
        }
    }

    LaunchedEffect(isRecordingVoice, isRecordingVideoCircle) {
        if (isRecordingVoice || isRecordingVideoCircle) {
            voiceSeconds = 0
            var tickCount = 0
            while (isRecordingVoice || isRecordingVideoCircle) {
                delay(200L)
                micAmplitude = voiceRecorder.pollNormalizedAmplitude()
                tickCount += 1
                if (tickCount % 5 == 0) {
                    voiceSeconds += 1
                    if (voiceSeconds >= 60) {
                        finishAndSendRecording()
                        break
                    }
                }
            }
        } else {
            micAmplitude = 0.2f
        }
    }

    BackHandler {
        if (isRecordingVoice || isRecordingVideoCircle) {
            voiceRecorder.cancelRecording()
            capturedCircleFrames.clear()
            isRecordingVoice = false
            isRecordingVideoCircle = false
        } else {
            PhonogrammVoicePlayer.stopPlayback()
            onBack()
        }
    }

    val directMessages = (messagesState as? UiState.Success)?.data ?: emptyList()
    val systemMessages = currentUserProfile.parsedSystemMessages
    val totalItemCount = if (isSystemBotChat) systemMessages.size else directMessages.size

    LaunchedEffect(totalItemCount) {
        if (totalItemCount > 0) {
            listState.animateScrollToItem(totalItemCount - 1)
        }
    }

    val showScrollBottomBtn by remember {
        derivedStateOf {
            val layoutInfo = listState.layoutInfo
            val totalItems = layoutInfo.totalItemsCount
            if (totalItems == 0) false
            else {
                val lastVisible = layoutInfo.visibleItemsInfo.lastOrNull()?.index ?: 0
                lastVisible < totalItems - 2
            }
        }
    }

    val nowMillis = rememberPresenceClockMillis()
    val peerDisplayName = when {
        isSystemBotChat -> "Oleg"
        peerProfile != null -> peerProfile.effectiveDisplayName
        else -> peerUsername
    }
    val peerVerified = isSystemBotChat || (peerProfile?.isVerified == true) ||
        peerUsername.equals("ShabanDurov", ignoreCase = true)
    val isPeerOnline = !isSystemBotChat && (peerProfile?.isEffectivelyOnline(nowMillis) == true)
    val peerStatusText = when {
        isSystemBotChat -> "официальный системный бот"
        peerProfile != null -> peerProfile.formatPresenceStatus(nowMillis)
        else -> "не в сети"
    }

    Scaffold(
        modifier = modifier.fillMaxSize(),
        containerColor = palette.bg,
        contentWindowInsets = WindowInsets(0, 0, 0, 0),
        topBar = {
            // HTML .chat-header (height: 64px, padding: 0 22px, background: var(--surface-floating), border-bottom: 1px solid var(--border))
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(if (isOldDeviceMode) palette.surfaceElevated else palette.surfaceFloating)
            ) {
                Row(
                    modifier = Modifier
                        .statusBarsPadding()
                        .fillMaxWidth()
                        .height(64.dp)
                        .padding(horizontal = 16.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    // .back-btn (38x38dp, border-radius: 12px, background: var(--surface-subtle), border: 1px solid var(--border))
                    Box(
                        modifier = Modifier
                            .size(38.dp)
                            .clip(RoundedCornerShape(12.dp))
                            .background(palette.surfaceSubtle)
                            .border(1.dp, palette.border, RoundedCornerShape(12.dp))
                            .clickable(onClick = onBack)
                            .testTag("chat_back_button"),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                            contentDescription = "Назад",
                            tint = palette.text,
                            modifier = Modifier.size(18.dp)
                        )
                    }

                    Spacer(modifier = Modifier.width(12.dp))

                    // .chat-header-user
                    Row(
                        modifier = Modifier
                            .weight(1f)
                            .clip(RoundedCornerShape(12.dp))
                            .clickable(enabled = !isSystemBotChat) { onOpenPeerProfile(peerUsername) }
                            .padding(vertical = 4.dp, horizontal = 4.dp)
                            .testTag("chat_header_profile_trigger"),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        PhonogrammAvatar(
                            username = peerDisplayName,
                            customEmojiOrText = peerProfile?.avatarUrl,
                            size = 42.dp,
                            cornerRadius = 14.dp,
                            fontSize = 15.sp,
                            isBot = isSystemBotChat,
                            showOnlineDot = isPeerOnline
                        )

                        Spacer(modifier = Modifier.width(12.dp))

                        Column(modifier = Modifier.weight(1f)) {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(5.dp)
                            ) {
                                Text(
                                    text = if (isSystemBotChat) {
                                        "Oleg"
                                    } else {
                                        "$peerDisplayName (@${peerProfile?.username ?: peerUsername})"
                                    },
                                    color = palette.text,
                                    fontSize = 15.sp,
                                    fontWeight = FontWeight.Bold,
                                    maxLines = 1,
                                    overflow = TextOverflow.Ellipsis,
                                    modifier = Modifier.testTag("chat_header_title")
                                )
                                if (peerVerified) {
                                    VerifiedBadgeIcon(size = 15.dp)
                                }
                            }
                            Spacer(modifier = Modifier.height(2.dp))
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(6.dp)
                            ) {
                                if (isPeerOnline) {
                                    Box(
                                        modifier = Modifier
                                            .size(7.dp)
                                            .clip(CircleShape)
                                            .background(palette.online)
                                    )
                                }
                                Text(
                                    text = peerStatusText,
                                    color = if (isPeerOnline) palette.online else palette.textSecondary,
                                    fontSize = 12.sp,
                                    fontWeight = FontWeight.Medium,
                                    maxLines = 1,
                                    overflow = TextOverflow.Ellipsis
                                )
                            }
                        }
                    }

                    // .chat-header-actions (.call-action-btn 38x38dp, radius 11dp)
                    Row(
                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        if (!isSystemBotChat) {
                            CallHeaderActionButton(
                                icon = Icons.Default.Call,
                                contentDescription = "Аудиозвонок",
                                onClick = {
                                    if (PhonogrammMediaHelper.hasRecordAudioPermission(context)) {
                                        onStartAudioCall(peerUsername)
                                    } else {
                                        audioCallPermissionLauncher.launch(Manifest.permission.RECORD_AUDIO)
                                    }
                                },
                                testTag = "chat_audio_call_btn"
                            )
                            CallHeaderActionButton(
                                icon = Icons.Default.Videocam,
                                contentDescription = "Видеозвонок",
                                onClick = {
                                    if (PhonogrammMediaHelper.hasVideoCallPermissions(context)) {
                                        onStartVideoCall(peerUsername)
                                    } else {
                                        videoCallPermissionsLauncher.launch(
                                            arrayOf(
                                                Manifest.permission.RECORD_AUDIO,
                                                Manifest.permission.CAMERA
                                            )
                                        )
                                    }
                                },
                                testTag = "chat_video_call_btn"
                            )
                        }

                        Box {
                            CallHeaderActionButton(
                                icon = Icons.Default.MoreVert,
                                contentDescription = "Меню чата",
                                onClick = { showHeaderDropdown = true },
                                testTag = "chat_more_menu_btn"
                            )

                            DropdownMenu(
                                expanded = showHeaderDropdown,
                                onDismissRequest = { showHeaderDropdown = false },
                                modifier = Modifier
                                    .background(palette.surfaceElevated)
                                    .border(1.dp, palette.borderStrong, RoundedCornerShape(14.dp))
                            ) {
                                if (!isSystemBotChat) {
                                    DropdownMenuItem(
                                        text = {
                                            Text(
                                                "👤 Профиль собеседника",
                                                color = palette.text,
                                                fontSize = 13.5.sp,
                                                fontWeight = FontWeight.SemiBold
                                            )
                                        },
                                        onClick = {
                                            showHeaderDropdown = false
                                            onOpenPeerProfile(peerUsername)
                                        }
                                    )
                                }
                                DropdownMenuItem(
                                    text = {
                                        Text(
                                            "🧹 Очистить историю чата",
                                            color = palette.error,
                                            fontSize = 13.5.sp,
                                            fontWeight = FontWeight.SemiBold
                                        )
                                    },
                                    onClick = {
                                        showHeaderDropdown = false
                                        onOpenClearChatModal()
                                    }
                                )
                            }
                        }
                    }
                }

                Box(
                    modifier = Modifier
                        .align(Alignment.BottomCenter)
                        .fillMaxWidth()
                        .height(1.dp)
                        .background(palette.border)
                )
            }
        },
        bottomBar = {
            if (isSystemBotChat) {
                // System chat read-only footer
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .background(palette.surfaceFloating)
                        .navigationBarsPadding()
                ) {
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(1.dp)
                            .background(palette.border)
                            .align(Alignment.TopCenter)
                    )
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 20.dp, vertical = 14.dp)
                            .then(if (isOldDeviceMode) Modifier.padding(bottom = 14.dp) else Modifier),
                        horizontalArrangement = Arrangement.Center,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "🔒 Официальный системный канал Oleg (только чтение)",
                            color = palette.textSecondary,
                            fontSize = 12.5.sp,
                            fontWeight = FontWeight.Medium,
                            textAlign = TextAlign.Center
                        )
                    }
                }
            } else {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .background(if (isOldDeviceMode) palette.surfaceElevated else palette.surfaceFloating)
                        .navigationBarsPadding()
                        .then(if (isOldDeviceMode) Modifier.padding(bottom = 14.dp) else Modifier)
                        .imePadding()
                ) {
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(1.dp)
                            .background(palette.border)
                    )

                    if (!sendError.isNullOrBlank()) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .background(palette.errorSoft)
                                .padding(horizontal = 16.dp, vertical = 8.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Text(
                                text = sendError,
                                color = palette.error,
                                fontSize = 12.sp,
                                fontWeight = FontWeight.SemiBold,
                                modifier = Modifier.weight(1f)
                            )
                            Icon(
                                imageVector = Icons.Default.Close,
                                contentDescription = "Закрыть ошибку",
                                tint = palette.error,
                                modifier = Modifier
                                    .size(16.dp)
                                    .clickable(onClick = onClearSendError)
                            )
                        }
                    }

                    // Telegram-style Circular Video Note ("Кружок") Recording Studio
                    AnimatedVisibility(visible = isRecordingVideoCircle) {
                        val progressFraction = (voiceSeconds.coerceIn(0, 60) / 60f).coerceIn(0.03f, 1f)
                        val mins = (voiceSeconds / 60).toString().padStart(2, '0')
                        val secs = (voiceSeconds % 60).toString().padStart(2, '0')

                        Box(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(horizontal = 16.dp, vertical = 12.dp),
                            contentAlignment = Alignment.Center
                        ) {
                            Box(
                                modifier = Modifier.size(244.dp),
                                contentAlignment = Alignment.Center
                            ) {
                                // Live circular camera preview
                                Box(
                                    modifier = Modifier
                                        .size(226.dp)
                                        .shadow(20.dp, CircleShape, spotColor = palette.primary)
                                        .clip(CircleShape)
                                        .background(Color(0xFF0B101E))
                                        .border(2.dp, palette.borderStrong, CircleShape)
                                ) {
                                    PhonogrammCameraPreview(
                                        useFrontCamera = useFrontCameraForCircle,
                                        squareCircleCapture = true,
                                        modifier = Modifier.fillMaxSize(),
                                        onFrameCaptured = { b64SquareFrame ->
                                            if (capturedCircleFrames.size >= 240) {
                                                for (i in capturedCircleFrames.lastIndex downTo 1 step 2) {
                                                    capturedCircleFrames.removeAt(i)
                                                }
                                            }
                                            capturedCircleFrames.add(b64SquareFrame)
                                        }
                                    )
                                }

                                // Animated 360° circular recording progress ring around the video circle
                                Canvas(modifier = Modifier.fillMaxSize()) {
                                    val strokePx = 4.dp.toPx()
                                    drawCircle(
                                        color = palette.primary.copy(alpha = 0.22f),
                                        style = Stroke(width = strokePx)
                                    )
                                    drawArc(
                                        brush = palette.msgOutBrush,
                                        startAngle = -90f,
                                        sweepAngle = 360f * progressFraction,
                                        useCenter = false,
                                        style = Stroke(width = strokePx, cap = StrokeCap.Round)
                                    )
                                }

                                // Flip Front/Back Camera button on the corner of the circle
                                Box(
                                    modifier = Modifier
                                        .align(Alignment.TopEnd)
                                        .padding(6.dp)
                                        .size(40.dp)
                                        .shadow(8.dp, CircleShape)
                                        .clip(CircleShape)
                                        .background(Color.Black.copy(alpha = 0.65f))
                                        .border(1.dp, Color.White.copy(alpha = 0.28f), CircleShape)
                                        .clickable { useFrontCameraForCircle = !useFrontCameraForCircle }
                                        .testTag("flip_video_circle_camera_button"),
                                    contentAlignment = Alignment.Center
                                ) {
                                    Icon(
                                        imageVector = Icons.Default.Cameraswitch,
                                        contentDescription = "Переключить камеру",
                                        tint = Color.White,
                                        modifier = Modifier.size(20.dp)
                                    )
                                }

                                // Live timer badge at the bottom of the circle
                                Row(
                                    modifier = Modifier
                                        .align(Alignment.BottomCenter)
                                        .padding(bottom = 14.dp)
                                        .clip(RoundedCornerShape(999.dp))
                                        .background(Color.Black.copy(alpha = 0.68f))
                                        .border(1.dp, Color.White.copy(alpha = 0.22f), RoundedCornerShape(999.dp))
                                        .padding(horizontal = 12.dp, vertical = 4.dp),
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                                ) {
                                    Box(
                                        modifier = Modifier
                                            .size(8.dp)
                                            .clip(CircleShape)
                                            .background(palette.error)
                                    )
                                    Text(
                                        text = "$mins:$secs",
                                        color = Color.White,
                                        fontSize = 12.sp,
                                        fontWeight = FontWeight.Bold,
                                        fontFamily = FontFamily.Monospace
                                    )
                                }
                            }
                        }
                    }

                    // #attachment-preview-bar
                    AnimatedVisibility(visible = pendingAttachmentUri != null) {
                        val previewBitmap = remember(pendingAttachmentDataUri, pendingAttachmentUri) {
                            PhonogrammMediaHelper.decodeChatPhotoBitmap(
                                context,
                                pendingAttachmentDataUri ?: pendingAttachmentUri?.toString()
                            )
                        }
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .background(palette.surfaceElevated)
                                .padding(horizontal = 18.dp, vertical = 10.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Box(
                                modifier = Modifier
                                    .size(48.dp)
                                    .clip(RoundedCornerShape(12.dp))
                                    .background(palette.primarySoft)
                                    .border(1.dp, palette.borderStrong, RoundedCornerShape(12.dp)),
                                contentAlignment = Alignment.Center
                            ) {
                                if (previewBitmap != null) {
                                    Image(
                                        bitmap = previewBitmap,
                                        contentDescription = "Миниатюра фото",
                                        contentScale = ContentScale.Crop,
                                        filterQuality = FilterQuality.High,
                                        modifier = Modifier.fillMaxSize()
                                    )
                                } else if (isEncodingAttachment) {
                                    CircularProgressIndicator(
                                        modifier = Modifier.size(18.dp),
                                        strokeWidth = 2.dp,
                                        color = palette.primary
                                    )
                                } else {
                                    Text(text = "📷", fontSize = 20.sp)
                                }
                            }
                            Spacer(modifier = Modifier.width(12.dp))
                            Column(modifier = Modifier.weight(1f)) {
                                Text(
                                    text = pendingAttachmentName ?: "Фотография",
                                    color = palette.text,
                                    fontSize = 13.sp,
                                    fontWeight = FontWeight.Bold,
                                    maxLines = 1,
                                    overflow = TextOverflow.Ellipsis
                                )
                                Text(
                                    text = if (isEncodingAttachment) "Обработка HD-фото..." else "HD-фото готово к отправке",
                                    color = palette.primary,
                                    fontSize = 11.sp,
                                    fontWeight = FontWeight.SemiBold
                                )
                            }
                            Box(
                                modifier = Modifier
                                    .size(28.dp)
                                    .clip(RoundedCornerShape(8.dp))
                                    .clickable {
                                        pendingAttachmentUri = null
                                        pendingAttachmentName = null
                                        pendingAttachmentDataUri = null
                                        isEncodingAttachment = false
                                    },
                                contentAlignment = Alignment.Center
                            ) {
                                Icon(
                                    imageVector = Icons.Default.Close,
                                    contentDescription = "Удалить вложение",
                                    tint = palette.textSecondary,
                                    modifier = Modifier.size(16.dp)
                                )
                            }
                        }
                    }

                    // #reply-preview-bar
                    AnimatedVisibility(visible = replyingToMessage != null) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .background(palette.surfaceElevated)
                                .padding(horizontal = 18.dp, vertical = 8.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Box(
                                modifier = Modifier
                                    .width(3.5.dp)
                                    .height(34.dp)
                                    .clip(RoundedCornerShape(4.dp))
                                    .background(palette.primary)
                            )
                            Spacer(modifier = Modifier.width(10.dp))
                            Column(modifier = Modifier.weight(1f)) {
                                Text(
                                    text = "↩ Ответ @${replyingToMessage?.senderUsername ?: ""}",
                                    color = palette.primary,
                                    fontSize = 12.sp,
                                    fontWeight = FontWeight.Bold
                                )
                                Text(
                                    text = replyingToMessage?.text ?: "",
                                    color = palette.textSecondary,
                                    fontSize = 12.5.sp,
                                    maxLines = 1,
                                    overflow = TextOverflow.Ellipsis
                                )
                            }
                            Box(
                                modifier = Modifier
                                    .size(28.dp)
                                    .clip(RoundedCornerShape(8.dp))
                                    .clickable { onSetReplyToMessage(null) },
                                contentAlignment = Alignment.Center
                            ) {
                                Icon(
                                    imageVector = Icons.Default.Close,
                                    contentDescription = "Отменить ответ",
                                    tint = palette.textSecondary,
                                    modifier = Modifier.size(16.dp)
                                )
                            }
                        }
                    }

                    if (isRecordingVoice || isRecordingVideoCircle) {
                        // #voice-record-bar & Telegram Video Circle ("кружок") recording bar
                        val pulseTransition = rememberInfiniteTransition(label = "voice_pulse")
                        val dotAlpha by pulseTransition.animateFloat(
                            initialValue = 1f,
                            targetValue = 0.25f,
                            animationSpec = infiniteRepeatable(
                                animation = tween(600),
                                repeatMode = RepeatMode.Reverse
                            ),
                            label = "dot_alpha"
                        )
                        val mins = (voiceSeconds / 60).toString().padStart(2, '0')
                        val secs = (voiceSeconds % 60).toString().padStart(2, '0')

                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(horizontal = 18.dp, vertical = 12.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(10.dp)
                        ) {
                            Box(
                                modifier = Modifier
                                    .size(10.dp)
                                    .clip(CircleShape)
                                    .background(palette.error.copy(alpha = dotAlpha))
                            )
                            Text(
                                text = "$mins:$secs",
                                color = palette.text,
                                fontSize = 14.sp,
                                fontWeight = FontWeight.Bold,
                                fontFamily = FontFamily.Monospace
                            )
                            // Live microphone amplitude bars
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(2.5.dp),
                                modifier = Modifier.height(22.dp)
                            ) {
                                val weights = listOf(0.55f, 0.85f, 1.0f, 0.7f, 0.95f, 0.6f)
                                weights.forEach { factor ->
                                    val barDp = (6f + 15f * (micAmplitude * factor).coerceIn(0.15f, 1f)).dp
                                    Box(
                                        modifier = Modifier
                                            .width(3.dp)
                                            .height(barDp)
                                            .clip(RoundedCornerShape(2.dp))
                                            .background(palette.primary)
                                    )
                                }
                            }
                            Text(
                                text = if (isRecordingVideoCircle) "Запись кружка..." else "Запись с микрофона...",
                                color = palette.textSecondary,
                                fontSize = 12.5.sp,
                                modifier = Modifier.weight(1f),
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis
                            )
                            Box(
                                modifier = Modifier
                                    .clip(RoundedCornerShape(10.dp))
                                    .background(palette.errorSoft)
                                    .border(1.dp, palette.error.copy(alpha = 0.3f), RoundedCornerShape(10.dp))
                                    .clickable {
                                        voiceRecorder.cancelRecording()
                                        capturedCircleFrames.clear()
                                        isRecordingVoice = false
                                        isRecordingVideoCircle = false
                                    }
                                    .padding(horizontal = 12.dp, vertical = 7.dp)
                            ) {
                                Text(
                                    text = "Отмена",
                                    color = palette.error,
                                    fontSize = 12.5.sp,
                                    fontWeight = FontWeight.Bold
                                )
                            }
                            Box(
                                modifier = Modifier
                                    .size(42.dp)
                                    .shadow(8.dp, RoundedCornerShape(14.dp), spotColor = palette.primary)
                                    .clip(RoundedCornerShape(14.dp))
                                    .background(palette.msgOutBrush)
                                    .clickable {
                                        finishAndSendRecording()
                                    }
                                    .testTag(if (isRecordingVideoCircle) "send_video_circle_button" else "send_voice_button"),
                                contentAlignment = Alignment.Center
                            ) {
                                Icon(
                                    imageVector = Icons.AutoMirrored.Filled.Send,
                                    contentDescription = if (isRecordingVideoCircle) "Отправить кружок" else "Отправить голосовое",
                                    tint = Color.White,
                                    modifier = Modifier.size(18.dp)
                                )
                            }
                        }
                    } else {
                        // .chat-input-bar (Attach, Video Circle ("Кружок"), Input, Mic, Send)
                        val canSend = (messageInput.trim().isNotEmpty() || (pendingAttachmentUri != null && !isEncodingAttachment)) && !isSending

                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(horizontal = 14.dp, vertical = 10.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            // .attach-file-btn (42x42dp, border-radius: 14px)
                            ComposerToolButton(
                                icon = Icons.Default.AttachFile,
                                contentDescription = "Прикрепить фото или файл",
                                isActive = pendingAttachmentUri != null,
                                onClick = {
                                    photoPickerLauncher.launch(
                                        PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly)
                                    )
                                }
                            )

                            // Telegram-style Video Circle ("Кружок") Record Button replacing Sticker button
                            Box(
                                modifier = Modifier
                                    .size(42.dp)
                                    .clip(RoundedCornerShape(14.dp))
                                    .background(palette.surfaceSubtle)
                                    .border(
                                        width = 1.dp,
                                        color = palette.border,
                                        shape = RoundedCornerShape(14.dp)
                                    )
                                    .clickable {
                                        if (PhonogrammMediaHelper.hasVideoCallPermissions(context)) {
                                            PhonogrammVoicePlayer.stopPlayback()
                                            capturedCircleFrames.clear()
                                            if (voiceRecorder.startRecording()) {
                                                isRecordingVoice = false
                                                isRecordingVideoCircle = true
                                            }
                                        } else {
                                            videoCirclePermissionsLauncher.launch(
                                                arrayOf(
                                                    Manifest.permission.RECORD_AUDIO,
                                                    Manifest.permission.CAMERA
                                                )
                                            )
                                        }
                                    }
                                    .testTag("video_circle_record_button"),
                                contentAlignment = Alignment.Center
                            ) {
                                Box(
                                    modifier = Modifier
                                        .size(28.dp)
                                        .clip(CircleShape)
                                        .border(1.5.dp, palette.primary, CircleShape),
                                    contentAlignment = Alignment.Center
                                ) {
                                    Icon(
                                        imageVector = Icons.Default.Videocam,
                                        contentDescription = "Записать видеокружок",
                                        tint = palette.primary,
                                        modifier = Modifier.size(16.dp)
                                    )
                                }
                            }

                            // .chat-input-bar input (42dp height, radius 14dp, bg, border)
                            Box(
                                modifier = Modifier
                                    .weight(1f)
                                    .height(42.dp)
                                    .clip(RoundedCornerShape(14.dp))
                                    .background(if (isInputFocused) palette.surface else palette.bg)
                                    .border(
                                        width = 1.dp,
                                        color = if (isInputFocused) palette.primary else palette.border,
                                        shape = RoundedCornerShape(14.dp)
                                    )
                                    .padding(horizontal = 14.dp),
                                contentAlignment = Alignment.CenterStart
                            ) {
                                if (messageInput.isEmpty()) {
                                    Text(
                                        text = if (pendingAttachmentUri != null) "Добавить подпись к фото..." else "Написать сообщение...",
                                        color = palette.textTertiary,
                                        fontSize = 14.sp,
                                        maxLines = 1,
                                        overflow = TextOverflow.Ellipsis
                                    )
                                }
                                BasicTextField(
                                    value = messageInput,
                                    onValueChange = { messageInput = it },
                                    singleLine = true,
                                    textStyle = TextStyle(
                                        color = palette.text,
                                        fontSize = 14.sp
                                    ),
                                    cursorBrush = SolidColor(palette.primary),
                                    keyboardOptions = KeyboardOptions(
                                        capitalization = KeyboardCapitalization.Sentences,
                                        imeAction = ImeAction.Send
                                    ),
                                    keyboardActions = KeyboardActions(
                                        onSend = {
                                            if (canSend) {
                                                dispatchMessage(
                                                    context = context,
                                                    messageInput = messageInput,
                                                    pendingAttachmentUri = pendingAttachmentUri,
                                                    pendingAttachmentDataUri = pendingAttachmentDataUri,
                                                    onSendMessage = onSendMessage,
                                                    onCleared = {
                                                        messageInput = ""
                                                        pendingAttachmentUri = null
                                                        pendingAttachmentName = null
                                                        pendingAttachmentDataUri = null
                                                    }
                                                )
                                            }
                                        }
                                    ),
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .onFocusChanged { isInputFocused = it.isFocused }
                                        .testTag("message_input")
                                )
                            }

                            // .mic-record-btn (42x42dp, border-radius: 14px)
                            ComposerToolButton(
                                icon = Icons.Default.Mic,
                                contentDescription = "Записать голосовое сообщение",
                                isActive = false,
                                onClick = {
                                    if (PhonogrammMediaHelper.hasRecordAudioPermission(context)) {
                                        PhonogrammVoicePlayer.stopPlayback()
                                        if (voiceRecorder.startRecording()) {
                                            isRecordingVideoCircle = false
                                            isRecordingVoice = true
                                        }
                                    } else {
                                        voiceRecordPermissionLauncher.launch(Manifest.permission.RECORD_AUDIO)
                                    }
                                },
                                modifier = Modifier.testTag("mic_record_button")
                            )

                            // .send-icon-btn (42x42dp, border-radius: 14px, background: var(--msg-out-bg))
                            Box(
                                modifier = Modifier
                                    .size(42.dp)
                                    .then(
                                        if (canSend) {
                                            Modifier.shadow(
                                                elevation = 8.dp,
                                                shape = RoundedCornerShape(14.dp),
                                                spotColor = palette.primary
                                            )
                                        } else {
                                            Modifier
                                        }
                                    )
                                    .clip(RoundedCornerShape(14.dp))
                                    .background(
                                        brush = if (canSend) {
                                            palette.msgOutBrush
                                        } else {
                                            SolidColor(palette.surfaceSubtle)
                                        }
                                    )
                                    .clickable(enabled = canSend) {
                                        dispatchMessage(
                                            context = context,
                                            messageInput = messageInput,
                                            pendingAttachmentUri = pendingAttachmentUri,
                                            pendingAttachmentDataUri = pendingAttachmentDataUri,
                                            onSendMessage = onSendMessage,
                                            onCleared = {
                                                messageInput = ""
                                                pendingAttachmentUri = null
                                                pendingAttachmentName = null
                                                pendingAttachmentDataUri = null
                                            }
                                        )
                                    }
                                    .testTag("send_message_button"),
                                contentAlignment = Alignment.Center
                            ) {
                                if (isSending) {
                                    CircularProgressIndicator(
                                        modifier = Modifier.size(18.dp),
                                        strokeWidth = 2.dp,
                                        color = Color.White
                                    )
                                } else {
                                    Icon(
                                        imageVector = Icons.AutoMirrored.Filled.Send,
                                        contentDescription = "Отправить",
                                        tint = if (canSend) Color.White else palette.textTertiary,
                                        modifier = Modifier.size(18.dp)
                                    )
                                }
                            }
                        }
                    }
                }
            }
        }
    ) { innerPadding ->
        // #main-chat spatial background (radial glow + 24x24 dot-matrix grid)
        PhonogrammSpatialChatBackground(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
        ) {
            Box(modifier = Modifier.fillMaxSize()) {
                if (!isSystemBotChat && messagesState is UiState.Loading) {
                    CircularProgressIndicator(
                        color = palette.primary,
                        modifier = Modifier.align(Alignment.Center)
                    )
                } else if (totalItemCount == 0) {
                    // HTML .chat-empty-hint glass card
                    Box(
                        modifier = Modifier
                            .align(Alignment.Center)
                            .padding(horizontal = 28.dp)
                            .widthIn(max = 320.dp)
                            .shadow(16.dp, RoundedCornerShape(24.dp))
                            .clip(RoundedCornerShape(24.dp))
                            .background(palette.surfaceElevated)
                            .border(1.dp, palette.border, RoundedCornerShape(24.dp))
                            .padding(horizontal = 24.dp, vertical = 28.dp)
                            .testTag("empty_messages_state"),
                        contentAlignment = Alignment.Center
                    ) {
                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                            Box(
                                modifier = Modifier
                                    .size(64.dp)
                                    .clip(RoundedCornerShape(20.dp))
                                    .background(palette.primarySoft)
                                    .border(1.dp, palette.primary.copy(alpha = 0.2f), RoundedCornerShape(20.dp)),
                                contentAlignment = Alignment.Center
                            ) {
                                Text(
                                    text = if (isSystemBotChat) "🛡️" else "👋",
                                    fontSize = 30.sp
                                )
                            }
                            Spacer(modifier = Modifier.height(14.dp))
                            Text(
                                text = if (isSystemBotChat) "Системные уведомления" else "Сообщений пока нет",
                                color = palette.text,
                                fontSize = 15.sp,
                                fontWeight = FontWeight.Bold,
                                textAlign = TextAlign.Center
                            )
                            Spacer(modifier = Modifier.height(6.dp))
                            Text(
                                text = if (isSystemBotChat) {
                                    "Здесь появляются коды подтверждения входа, подарки и системные оповещения Oleg."
                                } else {
                                    "Отправьте видеокружок, голосовое или текстовое сообщение, чтобы начать диалог с @$peerUsername."
                                },
                                color = palette.textSecondary,
                                fontSize = 13.sp,
                                textAlign = TextAlign.Center,
                                lineHeight = 18.sp
                            )
                        }
                    }
                } else {
                    LazyColumn(
                        state = listState,
                        modifier = Modifier
                            .fillMaxSize()
                            .testTag("messages_list"),
                        contentPadding = PaddingValues(horizontal = 18.dp, vertical = 18.dp),
                        verticalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        // HTML .chat-date-pill ("Сегодня")
                        item(key = "chat_date_pill_header") {
                            Box(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(vertical = 6.dp),
                                contentAlignment = Alignment.Center
                            ) {
                                Box(
                                    modifier = Modifier
                                        .shadow(4.dp, RoundedCornerShape(999.dp))
                                        .clip(RoundedCornerShape(999.dp))
                                        .background(palette.surfaceFloating)
                                        .border(1.dp, palette.border, RoundedCornerShape(999.dp))
                                        .padding(horizontal = 14.dp, vertical = 5.dp)
                                ) {
                                    Text(
                                        text = "Сегодня",
                                        color = palette.textSecondary,
                                        fontSize = 11.5.sp,
                                        fontWeight = FontWeight.SemiBold
                                    )
                                }
                            }
                        }

                        if (isSystemBotChat) {
                            itemsIndexed(
                                items = systemMessages,
                                key = { idx, msg -> msg.id.ifBlank { "sys_$idx" } }
                            ) { _, sysMsg ->
                                SystemAlertMessageBubble(
                                    systemMessage = sysMsg,
                                    onCopyCode = { code ->
                                        val cm = context.getSystemService(Context.CLIPBOARD_SERVICE) as? ClipboardManager
                                        cm?.setPrimaryClip(ClipData.newPlainText("Code", code))
                                    }
                                )
                            }
                        } else {
                            itemsIndexed(
                                items = directMessages,
                                key = { _, msg -> msg.id }
                            ) { index, message ->
                                val isOutgoing = message.senderId == currentUserProfile.uid ||
                                    message.senderUsername.equals(currentUserProfile.username, ignoreCase = true)

                                val prevSameSender = index > 0 &&
                                    directMessages[index - 1].senderUsername.equals(message.senderUsername, ignoreCase = true)
                                val nextSameSender = index < directMessages.size - 1 &&
                                    directMessages[index + 1].senderUsername.equals(message.senderUsername, ignoreCase = true)

                                PhonogrammMessageBubble(
                                    message = message,
                                    isOutgoing = isOutgoing,
                                    prevSameSender = prevSameSender,
                                    nextSameSender = nextSameSender,
                                    fontSizeSp = fontSizeSp,
                                    onClick = { onOpenMessageActions(message) },
                                    onLongClick = { onOpenMessageActions(message) },
                                    onOpenPhotoPreview = { photoUri ->
                                        fullscreenPhotoDataUri = photoUri
                                    }
                                )
                            }
                        }
                    }
                }

                // Full-screen HD photo viewer dialog when tapping an image in chat
                val activeFullscreenPhoto = fullscreenPhotoDataUri
                if (!activeFullscreenPhoto.isNullOrBlank()) {
                    val fullBitmap = remember(activeFullscreenPhoto) {
                        PhonogrammMediaHelper.decodeChatPhotoBitmap(context, activeFullscreenPhoto)
                    }
                    Dialog(
                        onDismissRequest = { fullscreenPhotoDataUri = null },
                        properties = DialogProperties(usePlatformDefaultWidth = false)
                    ) {
                        Box(
                            modifier = Modifier
                                .fillMaxSize()
                                .background(Color.Black.copy(alpha = 0.92f))
                                .clickable { fullscreenPhotoDataUri = null }
                                .padding(16.dp),
                            contentAlignment = Alignment.Center
                        ) {
                            if (fullBitmap != null) {
                                Image(
                                    bitmap = fullBitmap,
                                    contentDescription = "Просмотр фотографии",
                                    contentScale = ContentScale.Fit,
                                    filterQuality = FilterQuality.High,
                                    modifier = Modifier
                                        .fillMaxSize()
                                        .clip(RoundedCornerShape(16.dp))
                                )
                            }
                            Box(
                                modifier = Modifier
                                    .align(Alignment.TopEnd)
                                    .statusBarsPadding()
                                    .padding(8.dp)
                                    .size(44.dp)
                                    .clip(CircleShape)
                                    .background(Color.White.copy(alpha = 0.18f))
                                    .clickable { fullscreenPhotoDataUri = null },
                                contentAlignment = Alignment.Center
                            ) {
                                Icon(
                                    imageVector = Icons.Default.Close,
                                    contentDescription = "Закрыть фото",
                                    tint = Color.White,
                                    modifier = Modifier.size(22.dp)
                                )
                            }
                        }
                    }
                }

                // #scroll-bottom-btn (HTML lines 1011-1041: 42x42dp, border-radius: 14px, surfaceFloating)
                AnimatedVisibility(
                    visible = showScrollBottomBtn,
                    enter = fadeIn() + scaleIn(),
                    exit = fadeOut() + scaleOut(),
                    modifier = Modifier
                        .align(Alignment.BottomEnd)
                        .padding(end = 22.dp, bottom = 16.dp)
                ) {
                    Box(
                        modifier = Modifier
                            .size(42.dp)
                            .shadow(12.dp, RoundedCornerShape(14.dp))
                            .clip(RoundedCornerShape(14.dp))
                            .background(palette.surfaceFloating)
                            .border(1.dp, palette.borderStrong, RoundedCornerShape(14.dp))
                            .clickable {
                                coroutineScope.launch {
                                    if (totalItemCount > 0) {
                                        listState.animateScrollToItem(totalItemCount - 1)
                                    }
                                }
                            }
                            .testTag("scroll_bottom_button"),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = Icons.Default.KeyboardArrowDown,
                            contentDescription = "Вниз к новым сообщениям",
                            tint = palette.text,
                            modifier = Modifier.size(22.dp)
                        )
                    }
                }
            }
        }
    }
}

private fun dispatchMessage(
    context: Context,
    messageInput: String,
    pendingAttachmentUri: Uri?,
    pendingAttachmentDataUri: String?,
    onSendMessage: (String, () -> Unit) -> Unit,
    onCleared: () -> Unit
) {
    val trimmed = messageInput.trim()
    val resolvedPhotoDataUri = pendingAttachmentDataUri
        ?: pendingAttachmentUri?.let { PhonogrammMediaHelper.encodeUriToChatPhotoDataUri(context, it) }

    val finalBody = when {
        !resolvedPhotoDataUri.isNullOrBlank() && trimmed.isNotEmpty() -> trimmed
        !resolvedPhotoDataUri.isNullOrBlank() -> "📷 Фотография"
        else -> trimmed
    }
    if (finalBody.isEmpty()) return

    if (!resolvedPhotoDataUri.isNullOrBlank()) {
        PhonogrammMediaHelper.registerPendingChatPhoto(finalBody, resolvedPhotoDataUri)
    }

    onSendMessage(finalBody) {
        onCleared()
    }
}

@Composable
private fun CallHeaderActionButton(
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    contentDescription: String,
    onClick: () -> Unit,
    testTag: String
) {
    val palette = LocalPhonogrammPalette.current
    Box(
        modifier = Modifier
            .size(38.dp)
            .clip(RoundedCornerShape(11.dp))
            .background(palette.surfaceSubtle)
            .border(1.dp, palette.border, RoundedCornerShape(11.dp))
            .clickable(onClick = onClick)
            .testTag(testTag),
        contentAlignment = Alignment.Center
    ) {
        Icon(
            imageVector = icon,
            contentDescription = contentDescription,
            tint = palette.textSecondary,
            modifier = Modifier.size(18.dp)
        )
    }
}

@Composable
private fun ComposerToolButton(
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    contentDescription: String,
    isActive: Boolean,
    onClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    val palette = LocalPhonogrammPalette.current
    Box(
        modifier = modifier
            .size(42.dp)
            .clip(RoundedCornerShape(14.dp))
            .background(if (isActive) palette.primarySoft else palette.surfaceSubtle)
            .border(
                width = 1.dp,
                color = if (isActive) palette.primary else palette.border,
                shape = RoundedCornerShape(14.dp)
            )
            .clickable(onClick = onClick),
        contentAlignment = Alignment.Center
    ) {
        Icon(
            imageVector = icon,
            contentDescription = contentDescription,
            tint = if (isActive) palette.primary else palette.textSecondary,
            modifier = Modifier.size(20.dp)
        )
    }
}

/**
 * Phonogramm `.message.incoming` and `.message.outgoing` bubble with smart corner grouping,
 * `.msg-reply-quote`, `.msg-voice-note` interactive waveform, and glowing `#A5F3FC` read ticks.
 */
@OptIn(ExperimentalFoundationApi::class)
@Composable
private fun PhonogrammMessageBubble(
    message: ChatMessage,
    isOutgoing: Boolean,
    prevSameSender: Boolean,
    nextSameSender: Boolean,
    fontSizeSp: Int,
    onClick: () -> Unit,
    onLongClick: () -> Unit,
    onOpenPhotoPreview: (String) -> Unit = {}
) {
    val context = LocalContext.current
    val palette = LocalPhonogrammPalette.current
    val isOldDeviceMode = LocalDeviceOptimizationMode.current.isOldDeviceMode

    val topStart = if (!isOutgoing && prevSameSender) 6.dp else 18.dp
    val bottomStart = if (!isOutgoing) (if (nextSameSender) 6.dp else 5.dp) else 18.dp
    val topEnd = if (isOutgoing && prevSameSender) 6.dp else 18.dp
    val bottomEnd = if (isOutgoing) (if (nextSameSender) 6.dp else 5.dp) else 18.dp

    val bubbleShape = RoundedCornerShape(
        topStart = topStart,
        topEnd = topEnd,
        bottomStart = bottomStart,
        bottomEnd = bottomEnd
    )

    val isVideoCircleMessage = message.text.startsWith("🎥 Кружок") ||
        message.imageBase64.startsWith(VideoCircleCodec.VIDEO_CIRCLE_PREFIX)
    val isVoiceMessage = !isVideoCircleMessage && message.text.startsWith("🎤 Голосовое сообщение")
    val rawPhotoSource = remember(message.imageBase64, message.text, isVideoCircleMessage) {
        if (isVideoCircleMessage) {
            ""
        } else {
            when {
                message.imageBase64.isNotBlank() -> message.imageBase64
                message.text.startsWith("data:image/") -> message.text
                else -> ""
            }
        }
    }
    val photoBitmap = remember(rawPhotoSource) {
        if (rawPhotoSource.isNotBlank()) {
            PhonogrammMediaHelper.decodeChatPhotoBitmap(context, rawPhotoSource)
        } else {
            null
        }
    }

    if (isVideoCircleMessage) {
        TelegramVideoCircleMessageRow(
            message = message,
            isOutgoing = isOutgoing,
            prevSameSender = prevSameSender,
            onLongClick = onLongClick
        )
        return
    }

    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(top = if (prevSameSender) 0.dp else 4.dp)
            .testTag("message_bubble_${message.id}"),
        horizontalArrangement = if (isOutgoing) Arrangement.End else Arrangement.Start
    ) {
        Box(
            modifier = Modifier
                .widthIn(min = 92.dp, max = 310.dp)
                .then(
                    if (isOldDeviceMode) {
                        Modifier
                    } else {
                        Modifier.shadow(
                            elevation = if (isOutgoing) 6.dp else 3.dp,
                            shape = bubbleShape,
                            spotColor = if (isOutgoing) palette.primary else Color.Black.copy(alpha = 0.25f)
                        )
                    }
                )
                .clip(bubbleShape)
                .background(
                    brush = if (isOutgoing) palette.msgOutBrush else SolidColor(palette.msgInBg)
                )
                .then(
                    if (!isOutgoing) {
                        Modifier.border(1.dp, palette.msgInBorder, bubbleShape)
                    } else {
                        Modifier
                    }
                )
                .combinedClickable(
                    onClick = onClick,
                    onLongClick = onLongClick
                )
                .padding(
                    horizontal = if (photoBitmap != null) 8.dp else 14.dp,
                    vertical = if (photoBitmap != null) 8.dp else 10.dp
                )
        ) {
            Column {
                // .msg-reply-quote
                if (message.replyToSender.isNotBlank() && message.replyToText.isNotBlank()) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(bottom = 6.dp)
                            .clip(RoundedCornerShape(8.dp))
                            .background(
                                if (isOutgoing) Color.Black.copy(alpha = 0.18f)
                                else palette.primarySoft
                            )
                            .padding(horizontal = 9.dp, vertical = 5.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Box(
                            modifier = Modifier
                                .width(3.dp)
                                .height(26.dp)
                                .clip(RoundedCornerShape(2.dp))
                                .background(if (isOutgoing) Color.White else palette.primary)
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Column {
                            Text(
                                text = "@${message.replyToSender}",
                                color = if (isOutgoing) Color.White else palette.primary,
                                fontSize = 11.5.sp,
                                fontWeight = FontWeight.Bold
                            )
                            Text(
                                text = message.replyToText,
                                color = if (isOutgoing) Color.White.copy(alpha = 0.85f) else palette.textSecondary,
                                fontSize = 12.sp,
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis
                            )
                        }
                    }
                }

                if (isVoiceMessage) {
                    VoiceNoteAttachmentCard(
                        text = message.text,
                        voiceAudioBase64 = message.voiceAudioBase64,
                        isOutgoing = isOutgoing
                    )
                } else if (photoBitmap != null) {
                    val photoAspect = remember(photoBitmap.width, photoBitmap.height) {
                        val w = photoBitmap.width.coerceAtLeast(1).toFloat()
                        val h = photoBitmap.height.coerceAtLeast(1).toFloat()
                        (w / h).coerceIn(0.6f, 1.85f)
                    }
                    Image(
                        bitmap = photoBitmap,
                        contentDescription = "Фотография в чате",
                        contentScale = ContentScale.Crop,
                        filterQuality = FilterQuality.High,
                        modifier = Modifier
                            .fillMaxWidth()
                            .aspectRatio(photoAspect)
                            .heightIn(min = 130.dp, max = 320.dp)
                            .clip(RoundedCornerShape(13.dp))
                            .clickable {
                                if (rawPhotoSource.isNotBlank()) {
                                    onOpenPhotoPreview(rawPhotoSource)
                                }
                            }
                            .testTag("message_photo_${message.id}")
                    )
                    val captionText = message.text.trim()
                    val hasCustomCaption = captionText.isNotEmpty() &&
                        captionText != "📷 Фотография" &&
                        !captionText.startsWith("📷 Фотография:") &&
                        !captionText.startsWith("data:image/")
                    if (hasCustomCaption) {
                        Spacer(modifier = Modifier.height(6.dp))
                        Text(
                            text = captionText,
                            color = if (isOutgoing) Color.White else palette.text,
                            fontSize = fontSizeSp.sp,
                            lineHeight = (fontSizeSp + 5).sp,
                            modifier = Modifier.padding(horizontal = 4.dp)
                        )
                    }
                } else {
                    Text(
                        text = message.text,
                        color = if (isOutgoing) Color.White else palette.text,
                        fontSize = fontSizeSp.sp,
                        lineHeight = (fontSizeSp + 5).sp
                    )
                }

                Spacer(modifier = Modifier.height(3.dp))

                // .message-meta (time + read ticks ✓✓)
                Row(
                    modifier = Modifier.align(Alignment.End),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(4.dp)
                ) {
                    Text(
                        text = remember(message.createdAtMillis) {
                            SimpleDateFormat("HH:mm", Locale.getDefault()).format(Date(message.createdAtMillis))
                        },
                        color = if (isOutgoing) Color.White.copy(alpha = 0.75f) else palette.textSecondary,
                        fontSize = 10.5.sp,
                        fontWeight = FontWeight.Medium
                    )
                    if (isOutgoing) {
                        Text(
                            text = if (message.read) "✓✓" else "✓",
                            color = if (message.read) palette.msgOutTickRead else Color.White.copy(alpha = 0.8f),
                            fontSize = 11.5.sp,
                            fontWeight = FontWeight.ExtraBold
                        )
                    }
                }
            }
        }
    }
}

/**
 * Telegram-style standalone circular video message ("Кружок"):
 * - Rendered as a round video bubble without a rectangular card container.
 * - Silently loops captured camera frames when idle (with a muted badge `🔇`).
 * - When tapped, expands slightly, plays synchronized AAC `.m4a` voice audio from the beginning,
 *   and draws a glowing 360° circular progress arc around the circle border.
 */
@OptIn(ExperimentalFoundationApi::class)
@Composable
private fun TelegramVideoCircleMessageRow(
    message: ChatMessage,
    isOutgoing: Boolean,
    prevSameSender: Boolean,
    onLongClick: () -> Unit
) {
    val context = LocalContext.current
    val palette = LocalPhonogrammPalette.current
    val isOldDeviceMode = LocalDeviceOptimizationMode.current.isOldDeviceMode

    val durationLabel = remember(message.text) {
        Regex("\\((\\d{2}:\\d{2})\\)").find(message.text)?.groupValues?.getOrNull(1) ?: "00:05"
    }
    val parsedDurationSeconds = remember(durationLabel) {
        val parts = durationLabel.split(":")
        val m = parts.getOrNull(0)?.toIntOrNull() ?: 0
        val s = parts.getOrNull(1)?.toIntOrNull() ?: 5
        (m * 60 + s).coerceIn(1, 120)
    }

    val effectivePayload = remember(message.imageBase64, message.text) {
        if (message.imageBase64.startsWith(VideoCircleCodec.VIDEO_CIRCLE_PREFIX)) {
            message.imageBase64
        } else {
            PhonogrammMediaHelper.getLocalVideoCirclePayload(message.text)
        }
    }

    var decodedFrames by remember(effectivePayload) {
        mutableStateOf<List<androidx.compose.ui.graphics.ImageBitmap>>(emptyList())
    }
    var circleFps by remember(effectivePayload) { mutableIntStateOf(10) }

    LaunchedEffect(effectivePayload) {
        if (effectivePayload.isNotBlank()) {
            val (fps, frames) = withContext(Dispatchers.Default) {
                VideoCircleCodec.unpackVideoCircle(effectivePayload)
            }
            circleFps = fps
            decodedFrames = frames
        }
    }

    var isPlayingWithSound by remember { mutableStateOf(false) }
    var currentFrameIndex by remember { mutableIntStateOf(0) }
    var playbackProgress by remember { mutableFloatStateOf(0f) }

    DisposableEffect(message.id) {
        onDispose {
            if (isPlayingWithSound) {
                PhonogrammVoicePlayer.stopPlayback()
            }
        }
    }

    LaunchedEffect(decodedFrames, isPlayingWithSound, circleFps, parsedDurationSeconds) {
        if (decodedFrames.isEmpty()) return@LaunchedEffect
        val totalFrames = decodedFrames.size
        if (isPlayingWithSound) {
            val totalDurationMs = (parsedDurationSeconds * 1000L).coerceAtLeast(1000L)
            val startMs = System.currentTimeMillis()
            while (isActive && isPlayingWithSound) {
                val elapsed = System.currentTimeMillis() - startMs
                val fraction = (elapsed.toFloat() / totalDurationMs.toFloat()).coerceIn(0f, 1f)
                playbackProgress = fraction
                currentFrameIndex = ((fraction * (totalFrames - 1)).toInt()).coerceIn(0, totalFrames - 1)
                if (elapsed >= totalDurationMs) {
                    break
                }
                delay(24L)
            }
        } else {
            playbackProgress = 0f
            val frameIntervalMs = (1000L / circleFps.coerceIn(4, 15)).coerceIn(65L, 180L)
            while (isActive && !isPlayingWithSound) {
                currentFrameIndex = (currentFrameIndex + 1) % totalFrames
                delay(frameIntervalMs)
            }
        }
    }

    val targetDiameter = if (isPlayingWithSound) 238.dp else 212.dp
    val animatedDiameter by animateDpAsState(
        targetValue = targetDiameter,
        animationSpec = tween(durationMillis = 220),
        label = "circle_diameter"
    )

    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(top = if (prevSameSender) 2.dp else 6.dp, bottom = 2.dp)
            .testTag("message_bubble_${message.id}"),
        horizontalArrangement = if (isOutgoing) Arrangement.End else Arrangement.Start
    ) {
        Column(
            horizontalAlignment = if (isOutgoing) Alignment.End else Alignment.Start
        ) {
            if (message.replyToSender.isNotBlank() && message.replyToText.isNotBlank()) {
                Row(
                    modifier = Modifier
                        .padding(bottom = 6.dp)
                        .clip(RoundedCornerShape(12.dp))
                        .background(palette.surfaceFloating)
                        .border(1.dp, palette.borderStrong, RoundedCornerShape(12.dp))
                        .clickable(onClick = onLongClick)
                        .padding(horizontal = 10.dp, vertical = 5.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Box(
                        modifier = Modifier
                            .width(3.dp)
                            .height(22.dp)
                            .clip(RoundedCornerShape(2.dp))
                            .background(palette.primary)
                    )
                    Spacer(modifier = Modifier.width(7.dp))
                    Column {
                        Text(
                            text = "@${message.replyToSender}",
                            color = palette.primary,
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold
                        )
                        Text(
                            text = message.replyToText,
                            color = palette.textSecondary,
                            fontSize = 11.5.sp,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis
                        )
                    }
                }
            }

            Box(
                modifier = Modifier.size(animatedDiameter + 10.dp),
                contentAlignment = Alignment.Center
            ) {
                val activeBitmap = decodedFrames.getOrNull(currentFrameIndex.coerceIn(0, (decodedFrames.size - 1).coerceAtLeast(0)))

                Box(
                    modifier = Modifier
                        .size(animatedDiameter)
                        .then(
                            if (isOldDeviceMode) Modifier
                            else Modifier.shadow(
                                elevation = if (isPlayingWithSound) 16.dp else 8.dp,
                                shape = CircleShape,
                                spotColor = palette.primary
                            )
                        )
                        .clip(CircleShape)
                        .background(
                            Brush.radialGradient(
                                colors = listOf(Color(0xFF1E293B), Color(0xFF0B101E))
                            )
                        )
                        .combinedClickable(
                            onClick = {
                                if (isPlayingWithSound) {
                                    PhonogrammVoicePlayer.stopPlayback()
                                    isPlayingWithSound = false
                                } else {
                                    isPlayingWithSound = true
                                    currentFrameIndex = 0
                                    playbackProgress = 0f
                                    PhonogrammVoicePlayer.playVoiceNote(
                                        context = context,
                                        messageText = message.text,
                                        remoteVoiceBase64 = message.voiceAudioBase64,
                                        durationSeconds = parsedDurationSeconds,
                                        onFinished = {
                                            isPlayingWithSound = false
                                            playbackProgress = 0f
                                        }
                                    )
                                }
                            },
                            onLongClick = onLongClick
                        )
                        .testTag("video_circle_player_${message.id}"),
                    contentAlignment = Alignment.Center
                ) {
                    if (activeBitmap != null) {
                        Image(
                            bitmap = activeBitmap,
                            contentDescription = "Видеокружок",
                            contentScale = ContentScale.Crop,
                            filterQuality = FilterQuality.High,
                            modifier = Modifier.fillMaxSize()
                        )
                    } else {
                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                            Icon(
                                imageVector = Icons.Default.Videocam,
                                contentDescription = null,
                                tint = Color.White,
                                modifier = Modifier.size(36.dp)
                            )
                            Spacer(modifier = Modifier.height(6.dp))
                            Text(
                                text = "Видеокружок",
                                color = Color.White.copy(alpha = 0.85f),
                                fontSize = 12.sp,
                                fontWeight = FontWeight.SemiBold
                            )
                        }
                    }

                    // Subtle bottom vignette inside the circle for duration & sound pill
                    Box(
                        modifier = Modifier
                            .fillMaxSize()
                            .background(
                                Brush.verticalGradient(
                                    0.0f to Color.Transparent,
                                    0.72f to Color.Transparent,
                                    1.0f to Color.Black.copy(alpha = 0.55f)
                                )
                            )
                    )

                    // Duration + Sound/Mute pill inside bottom of circle
                    Row(
                        modifier = Modifier
                            .align(Alignment.BottomCenter)
                            .padding(bottom = 10.dp)
                            .clip(RoundedCornerShape(999.dp))
                            .background(Color.Black.copy(alpha = 0.55f))
                            .padding(horizontal = 9.dp, vertical = 3.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(4.dp)
                    ) {
                        Icon(
                            imageVector = if (isPlayingWithSound) Icons.Default.VolumeUp else Icons.Default.VolumeOff,
                            contentDescription = null,
                            tint = if (isPlayingWithSound) palette.primary else Color.White.copy(alpha = 0.85f),
                            modifier = Modifier.size(13.dp)
                        )
                        Text(
                            text = durationLabel,
                            color = Color.White,
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold,
                            fontFamily = FontFamily.Monospace
                        )
                    }
                }

                // Circular border + animated 360° playback progress ring
                Canvas(modifier = Modifier.size(animatedDiameter + 6.dp)) {
                    val strokePx = 3.dp.toPx()
                    drawCircle(
                        color = if (isOutgoing) palette.primary.copy(alpha = 0.45f) else palette.borderStrong,
                        style = Stroke(width = 2.dp.toPx())
                    )
                    if (isPlayingWithSound) {
                        drawArc(
                            brush = palette.msgOutBrush,
                            startAngle = -90f,
                            sweepAngle = 360f * playbackProgress.coerceIn(0.02f, 1f),
                            useCenter = false,
                            style = Stroke(width = strokePx, cap = StrokeCap.Round)
                        )
                    }
                }

                // Floating Telegram-style timestamp + read ticks pill at bottom-end
                Row(
                    modifier = Modifier
                        .align(Alignment.BottomEnd)
                        .padding(end = 2.dp, bottom = 2.dp)
                        .clip(RoundedCornerShape(999.dp))
                        .background(palette.surfaceFloating.copy(alpha = 0.92f))
                        .border(1.dp, palette.border, RoundedCornerShape(999.dp))
                        .padding(horizontal = 8.dp, vertical = 3.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(4.dp)
                ) {
                    Text(
                        text = remember(message.createdAtMillis) {
                            SimpleDateFormat("HH:mm", Locale.getDefault()).format(Date(message.createdAtMillis))
                        },
                        color = palette.textSecondary,
                        fontSize = 10.sp,
                        fontWeight = FontWeight.SemiBold
                    )
                    if (isOutgoing) {
                        Text(
                            text = if (message.read) "✓✓" else "✓",
                            color = if (message.read) palette.primary else palette.textSecondary,
                            fontSize = 11.sp,
                            fontWeight = FontWeight.ExtraBold
                        )
                    }
                }
            }
        }
    }
}

/**
 * Interactive `.msg-voice-note` waveform player matching HTML lines 1138-1179.
 */
@Composable
private fun VoiceNoteAttachmentCard(
    text: String,
    voiceAudioBase64: String = "",
    isOutgoing: Boolean
) {
    val context = LocalContext.current
    val palette = LocalPhonogrammPalette.current
    var isPlaying by remember { mutableStateOf(false) }
    val durationLabel = remember(text) {
        Regex("\\((\\d{2}:\\d{2})\\)").find(text)?.groupValues?.getOrNull(1) ?: "00:05"
    }
    val parsedDurationSeconds = remember(durationLabel) {
        val parts = durationLabel.split(":")
        val m = parts.getOrNull(0)?.toIntOrNull() ?: 0
        val s = parts.getOrNull(1)?.toIntOrNull() ?: 5
        (m * 60 + s).coerceIn(1, 120)
    }
    val barHeights = remember {
        listOf(10.dp, 18.dp, 14.dp, 24.dp, 16.dp, 26.dp, 12.dp, 20.dp, 25.dp, 15.dp, 19.dp, 11.dp, 17.dp, 13.dp)
    }

    DisposableEffect(text) {
        onDispose {
            if (isPlaying) {
                PhonogrammVoicePlayer.stopPlayback()
            }
        }
    }

    Row(
        modifier = Modifier
            .widthIn(min = 210.dp)
            .padding(vertical = 2.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        Box(
            modifier = Modifier
                .size(38.dp)
                .clip(RoundedCornerShape(12.dp))
                .background(
                    if (isOutgoing) Color.White.copy(alpha = 0.22f)
                    else palette.primary
                )
                .clickable {
                    if (isPlaying) {
                        PhonogrammVoicePlayer.stopPlayback()
                        isPlaying = false
                    } else {
                        isPlaying = true
                        PhonogrammVoicePlayer.playVoiceNote(
                            context = context,
                            messageText = text,
                            remoteVoiceBase64 = voiceAudioBase64,
                            durationSeconds = parsedDurationSeconds,
                            onFinished = { isPlaying = false }
                        )
                    }
                },
            contentAlignment = Alignment.Center
        ) {
            Icon(
                imageVector = if (isPlaying) Icons.Default.Pause else Icons.Default.PlayArrow,
                contentDescription = "Воспроизвести голосовое",
                tint = Color.White,
                modifier = Modifier.size(20.dp)
            )
        }

        Column(modifier = Modifier.weight(1f)) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(26.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(3.dp)
            ) {
                barHeights.forEachIndexed { idx, barHeight ->
                    val activeBar = isPlaying && idx % 2 == 0
                    Box(
                        modifier = Modifier
                            .width(3.dp)
                            .height(if (activeBar) 24.dp else barHeight)
                            .clip(RoundedCornerShape(2.dp))
                            .background(
                                if (isOutgoing) {
                                    Color.White.copy(alpha = if (isPlaying) 0.95f else 0.72f)
                                } else {
                                    palette.primary.copy(alpha = if (isPlaying) 0.95f else 0.65f)
                                }
                            )
                    )
                }
            }
            Spacer(modifier = Modifier.height(2.dp))
            Text(
                text = if (isPlaying) "Воспроизведение • $durationLabel" else "Голосовое • $durationLabel",
                color = if (isOutgoing) Color.White.copy(alpha = 0.85f) else palette.textSecondary,
                fontSize = 11.sp,
                fontWeight = FontWeight.SemiBold,
                fontFamily = FontFamily.Monospace
            )
        }
    }
}

/**
 * Phonogramm `.message.system-alert` card with `3.5dp` left primary accent bar
 * and `.code-badge` (`border: 1.5px dashed var(--primary)`).
 */
@Composable
private fun SystemAlertMessageBubble(
    systemMessage: SystemBotMessage,
    onCopyCode: (String) -> Unit
) {
    val palette = LocalPhonogrammPalette.current
    val shape = RoundedCornerShape(18.dp)

    val extractedCode: String? = remember(systemMessage.text, systemMessage.code) {
        if (systemMessage.code.isNotBlank()) {
            systemMessage.code
        } else {
            Regex("\\b(\\d{6})\\b").find(systemMessage.text)?.value
        }
    }

    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 4.dp)
            .testTag("system_message_${systemMessage.id}"),
        horizontalArrangement = Arrangement.Start
    ) {
        Row(
            modifier = Modifier
                .widthIn(max = 350.dp)
                .shadow(10.dp, shape)
                .clip(shape)
                .background(palette.surfaceElevated)
                .border(1.dp, palette.borderStrong, shape)
        ) {
            // Left 3.5px solid var(--primary) stripe
            Box(
                modifier = Modifier
                    .width(4.dp)
                    .fillMaxHeight()
                    .background(palette.primary)
            )

            Column(
                modifier = Modifier.padding(horizontal = 16.dp, vertical = 14.dp)
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    Text(
                        text = "🛡️ Oleg Security",
                        color = palette.primary,
                        fontSize = 13.sp,
                        fontWeight = FontWeight.ExtraBold
                    )
                    VerifiedBadgeIcon(size = 14.dp)
                }

                Spacer(modifier = Modifier.height(6.dp))

                Text(
                    text = systemMessage.text,
                    color = palette.text,
                    fontSize = 13.5.sp,
                    lineHeight = 19.sp
                )

                // .code-badge (border: 1.5px dashed var(--primary), border-radius: 12px, monospace 22px)
                if (!extractedCode.isNullOrBlank()) {
                    Spacer(modifier = Modifier.height(10.dp))
                    Surface(
                        color = palette.primarySoft,
                        shape = RoundedCornerShape(12.dp),
                        modifier = Modifier
                            .dashedRoundedBorder(
                                width = 1.5.dp,
                                color = palette.primary,
                                cornerRadius = 12.dp
                            )
                            .clip(RoundedCornerShape(12.dp))
                            .clickable { onCopyCode(extractedCode) }
                            .testTag("copy_verification_code_badge")
                    ) {
                        Row(
                            modifier = Modifier.padding(horizontal = 16.dp, vertical = 9.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(10.dp)
                        ) {
                            Text(
                                text = extractedCode,
                                color = palette.primary,
                                fontSize = 21.sp,
                                fontWeight = FontWeight.ExtraBold,
                                fontFamily = FontFamily.Monospace,
                                letterSpacing = 4.sp
                            )
                            Icon(
                                imageVector = Icons.Default.ContentCopy,
                                contentDescription = "Скопировать код",
                                tint = palette.primary,
                                modifier = Modifier.size(16.dp)
                            )
                        }
                    }
                }

                Spacer(modifier = Modifier.height(6.dp))

                Text(
                    text = systemMessage.time,
                    color = palette.textSecondary,
                    fontSize = 10.5.sp,
                    modifier = Modifier.align(Alignment.End)
                )
            }
        }
    }
}
