package com.example.ui.viewmodel

import android.content.Context
import android.util.Log
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.call.CallAudioRouteManager
import com.example.call.CallEndReason
import com.example.call.CallPhase
import com.example.call.CallStateReducer
import com.example.call.CallUiModel
import com.example.call.IceCandidatePayload
import com.example.call.WebRtcCallEngine
import com.example.call.WebRtcEngineCallbacks
import com.example.data.model.AdminAccessDeniedException
import com.example.data.model.CallSession
import com.example.data.model.ChatMessage
import com.example.data.model.DirectChat
import com.example.data.model.GiftItem
import com.example.data.model.IncomingMessageNotification
import com.example.data.model.UserProfile
import com.example.data.repository.MessengerRepository
import com.example.util.PhonogrammMediaHelper
import com.example.util.PhonogrammNotificationHelper
import com.google.firebase.firestore.FirebaseFirestoreException
import java.util.Collections
import java.util.concurrent.ConcurrentHashMap
import java.util.concurrent.atomic.AtomicBoolean
import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharedFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asSharedFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.catch
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.flatMapLatest
import kotlinx.coroutines.flow.flowOf
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

enum class PhonogrammTab {
    CHATS, CONTACTS, SETTINGS, PROFILE
}

enum class ChatFolderFilter {
    ALL, PERSONAL, SYSTEM
}

sealed interface UiState<out T> {
    data object Loading : UiState<Nothing>
    data class Success<T>(val data: T) : UiState<T>
    data class Error(val message: String) : UiState<Nothing>
}

sealed interface ProfileState {
    data object Loading : ProfileState
    data object NeedsRegistration : ProfileState
    data class Ready(val profile: UserProfile) : ProfileState
    data class Error(val message: String) : ProfileState
}

sealed interface UserSearchState {
    data object Idle : UserSearchState
    data object Searching : UserSearchState
    data class Found(val user: UserProfile, val isSelf: Boolean) : UserSearchState
    data class NotFound(val query: String) : UserSearchState
    data class InvalidQuery(val reason: String) : UserSearchState
    data class Error(val message: String) : UserSearchState
}

private data class ChatSnapshotBaseline(
    val updatedAtMillis: Long,
    val lastMessageText: String,
    val lastSenderId: String
)

@OptIn(ExperimentalCoroutinesApi::class)
class MessengerViewModel(
    private val repository: MessengerRepository,
    val currentUserId: String,
    private val appContext: Context? = null
) : ViewModel() {

    private val _profileRetryTrigger = MutableStateFlow(0)

    private val _isAppInForeground = MutableStateFlow(true)
    val isAppInForeground: StateFlow<Boolean> = _isAppInForeground.asStateFlow()

    private val _localInAppNotification = MutableStateFlow<IncomingMessageNotification?>(null)
    val inAppNotification: StateFlow<IncomingMessageNotification?> = combine(
        PhonogrammNotificationHelper.inAppNotification,
        _localInAppNotification
    ) { engineNotif, localNotif ->
        engineNotif ?: localNotif
    }.stateIn(
        scope = viewModelScope,
        started = SharingStarted.Eagerly,
        initialValue = null
    )

    private val _systemNotificationEvents = MutableSharedFlow<IncomingMessageNotification>(extraBufferCapacity = 32)
    val systemNotificationEvents: SharedFlow<IncomingMessageNotification> = _systemNotificationEvents.asSharedFlow()

    private val _callUiModel = MutableStateFlow(CallUiModel())
    val callUiModel: StateFlow<CallUiModel> = _callUiModel.asStateFlow()

    private val _activeCallSession = MutableStateFlow<CallSession?>(null)
    val activeCallSession: StateFlow<CallSession?> = _activeCallSession.asStateFlow()

    private val _isCallMinimized = MutableStateFlow(false)
    val isCallMinimized: StateFlow<Boolean> = _isCallMinimized.asStateFlow()

    val webRtcEngine: WebRtcCallEngine? = appContext?.applicationContext?.let { WebRtcCallEngine(it) }
    private val callAudioRouteManager: CallAudioRouteManager? = appContext?.applicationContext?.let { CallAudioRouteManager(it) }

    private var activeCallListenerJob: Job? = null
    private var noAnswerTimeoutJob: Job? = null
    private var callTimerJob: Job? = null
    private var reconnectFallbackJob: Job? = null
    private val isStartingCallGuard = AtomicBoolean(false)
    private val isAcceptingCallGuard = AtomicBoolean(false)
    private val handledTerminalSessionIds = Collections.newSetFromMap(ConcurrentHashMap<String, Boolean>())
    private var lastAppliedOfferSdpForSession: Pair<String, String>? = null
    private var lastAppliedAnswerSdpForSession: Pair<String, String>? = null
    private val _latestUserCalls = MutableStateFlow<List<CallSession>>(emptyList())

    private var presenceHeartbeatJob: Job? = null
    private val peerListenerJobs = mutableMapOf<String, Job>()

    private val _isDeletingAccount = MutableStateFlow(false)
    val isDeletingAccount: StateFlow<Boolean> = _isDeletingAccount.asStateFlow()

    private var hasInitializedChatsBaseline = false
    private val chatBaselines = mutableMapOf<String, ChatSnapshotBaseline>()

    private var hasInitializedSystemBaseline = false
    private val knownSystemMessageIds = mutableSetOf<String>()

    private var activeChatBaselineId: String? = null
    private val knownActiveChatMessageIds = mutableSetOf<String>()
    private val dispatchedViewModelIds = mutableSetOf<String>()

    init {
        if (appContext != null && currentUserId.isNotBlank()) {
            PhonogrammNotificationHelper.startMonitoring(appContext, currentUserId)
        }
        observeIncomingCallsForCurrentUser()
        startPresenceHeartbeat()
    }

    private fun syncCallState(nextModel: CallUiModel) {
        _callUiModel.value = nextModel
        _activeCallSession.value = if (nextModel.phase == CallPhase.IDLE || nextModel.phase == CallPhase.ENDED) {
            null
        } else {
            nextModel.session
        }
        _isCallMinimized.value = nextModel.isMinimized && nextModel.session != null
    }

    fun minimizeCall() {
        val cur = _callUiModel.value
        if (cur.session != null && cur.phase != CallPhase.IDLE && cur.phase != CallPhase.ENDED) {
            syncCallState(cur.copy(isMinimized = true))
        }
    }

    fun expandCall() {
        val cur = _callUiModel.value
        if (cur.session != null) {
            syncCallState(cur.copy(isMinimized = false))
        }
    }

    fun toggleCallMute() {
        val cur = _callUiModel.value
        val session = cur.session ?: return
        val nextMuted = !cur.isMuted
        syncCallState(cur.copy(isMuted = nextMuted))
        webRtcEngine?.setMicrophoneMuted(nextMuted)
        val isCaller = session.callerId == currentUserId
        viewModelScope.launch {
            repository.updateCallMuteState(
                callId = session.callId,
                isCaller = isCaller,
                muted = nextMuted
            )
        }
    }

    fun toggleCallSpeaker() {
        val cur = _callUiModel.value
        val nextSpeaker = !cur.isSpeakerOn
        syncCallState(cur.copy(isSpeakerOn = nextSpeaker))
        callAudioRouteManager?.setSpeakerphoneEnabled(nextSpeaker)
    }

    fun toggleCallVideo() {
        val cur = _callUiModel.value
        val session = cur.session ?: return
        val nextVideo = !cur.isLocalVideoEnabled
        syncCallState(cur.copy(isLocalVideoEnabled = nextVideo))
        webRtcEngine?.setLocalVideoEnabled(nextVideo, cur.useFrontCamera)
        updateMyCallVideoState(session, nextVideo)
    }

    fun switchCallCamera() {
        val cur = _callUiModel.value
        val nextFront = !cur.useFrontCamera
        syncCallState(cur.copy(useFrontCamera = nextFront))
        webRtcEngine?.switchCamera(nextFront)
    }

    private fun startCallDurationTimer(sessionId: String) {
        if (callTimerJob?.isActive == true) return
        callTimerJob = viewModelScope.launch {
            while (true) {
                delay(1000L)
                val cur = _callUiModel.value
                if (cur.session?.sessionId != sessionId ||
                    (cur.phase != CallPhase.ACTIVE && cur.phase != CallPhase.RECONNECTING && cur.phase != CallPhase.CONNECTING)
                ) {
                    break
                }
                if (cur.phase == CallPhase.ACTIVE || cur.phase == CallPhase.RECONNECTING) {
                    syncCallState(cur.copy(elapsedSeconds = cur.elapsedSeconds + 1))
                }
            }
        }
    }

    private fun startNoAnswerTimeout(session: CallSession) {
        noAnswerTimeoutJob?.cancel()
        noAnswerTimeoutJob = viewModelScope.launch {
            delay(CALL_RING_TIMEOUT_MS)
            val cur = _callUiModel.value
            if (cur.session?.sessionId == session.sessionId && cur.phase == CallPhase.OUTGOING) {
                showToast("Абонент @${session.otherUsername(currentUserId)} не отвечает")
                teardownCallResourcesAndReset(
                    sessionId = session.sessionId,
                    reason = CallEndReason.NO_ANSWER_TIMEOUT
                )
                repository.updateCallStatus(session.callId, CallSession.STATUS_MISSED)
            }
        }
    }

    private fun createEngineCallbacks(session: CallSession): WebRtcEngineCallbacks {
        val isCaller = session.callerId == currentUserId
        return object : WebRtcEngineCallbacks {
            override fun onLocalSdpGenerated(type: String, sdp: String) {
                viewModelScope.launch {
                    val cur = _callUiModel.value
                    if (cur.session?.sessionId != session.sessionId) return@launch
                    if (type.equals("offer", ignoreCase = true) && isCaller) {
                        lastAppliedOfferSdpForSession = session.sessionId to sdp
                        repository.publishWebRtcOffer(session.callId, sdp)
                    } else if (type.equals("answer", ignoreCase = true) && !isCaller) {
                        lastAppliedAnswerSdpForSession = session.sessionId to sdp
                        repository.publishWebRtcAnswer(
                            callId = session.callId,
                            answerSdp = sdp,
                            calleeVideoEnabled = cur.isLocalVideoEnabled
                        )
                    }
                }
            }

            override fun onLocalIceCandidateFound(candidate: IceCandidatePayload) {
                viewModelScope.launch {
                    val cur = _callUiModel.value
                    if (cur.session?.sessionId != session.sessionId) return@launch
                    repository.publishWebRtcIceCandidate(
                        callId = session.callId,
                        isCaller = isCaller,
                        candidateJson = candidate.toJsonString()
                    )
                }
            }

            override fun onIceConnected() {
                viewModelScope.launch {
                    val cur = _callUiModel.value
                    if (cur.session?.sessionId != session.sessionId) return@launch
                    reconnectFallbackJob?.cancel()
                    reconnectFallbackJob = null
                    syncCallState(CallStateReducer.transitionToActive(cur))
                    startCallDurationTimer(session.sessionId)
                }
            }

            override fun onIceReconnecting() {
                viewModelScope.launch {
                    val cur = _callUiModel.value
                    if (cur.session?.sessionId != session.sessionId) return@launch
                    syncCallState(CallStateReducer.transitionToReconnecting(cur))
                    webRtcEngine?.triggerIceRestartIfCaller(session.sessionId, isCaller)
                    reconnectFallbackJob?.cancel()
                    reconnectFallbackJob = launch {
                        delay(15_000L)
                        val latest = _callUiModel.value
                        if (latest.session?.sessionId == session.sessionId &&
                            latest.phase == CallPhase.RECONNECTING
                        ) {
                            showToast("Связь прервана из-за потери сети")
                            declineOrHangupCall(latest.session)
                        }
                    }
                }
            }

            override fun onIceFailed(reason: String) {
                viewModelScope.launch {
                    val cur = _callUiModel.value
                    if (cur.session?.sessionId != session.sessionId) return@launch
                    if (isCaller && cur.phase != CallPhase.RECONNECTING) {
                        syncCallState(CallStateReducer.transitionToReconnecting(cur))
                        webRtcEngine?.triggerIceRestartIfCaller(session.sessionId, true)
                    }
                }
            }

            override fun onRemoteVideoTrackStateChanged(hasTrack: Boolean) {
                viewModelScope.launch {
                    val cur = _callUiModel.value
                    if (cur.session?.sessionId != session.sessionId) return@launch
                    if (hasTrack && cur.session.peerVideoEnabled(currentUserId)) {
                        syncCallState(cur.copy(isRemoteVideoEnabled = true))
                    }
                }
            }
        }
    }

    private fun teardownCallResourcesAndReset(
        sessionId: String?,
        reason: CallEndReason
    ) {
        if (!sessionId.isNullOrBlank()) {
            handledTerminalSessionIds.add(sessionId)
        }
        isStartingCallGuard.set(false)
        isAcceptingCallGuard.set(false)
        noAnswerTimeoutJob?.cancel()
        noAnswerTimeoutJob = null
        callTimerJob?.cancel()
        callTimerJob = null
        reconnectFallbackJob?.cancel()
        reconnectFallbackJob = null
        activeCallListenerJob?.cancel()
        activeCallListenerJob = null
        lastAppliedOfferSdpForSession = null
        lastAppliedAnswerSdpForSession = null

        webRtcEngine?.releaseSession()
        callAudioRouteManager?.releaseCallAudioRoute()
        PhonogrammNotificationHelper.clearIncomingCallSession(appContext)

        syncCallState(CallStateReducer.transitionToIdle())
    }

    private fun handleRemoteCallTerminated(updated: CallSession) {
        val wasShowing = _callUiModel.value.session?.sessionId == updated.sessionId ||
            _activeCallSession.value?.callId == updated.callId
        val otherNick = updated.otherUsername(currentUserId)
        val reason = when (updated.status) {
            CallSession.STATUS_BUSY -> CallEndReason.BUSY
            CallSession.STATUS_DECLINED -> CallEndReason.DECLINED_REMOTE
            CallSession.STATUS_MISSED -> CallEndReason.CANCELLED_REMOTE
            else -> CallEndReason.HANGUP_REMOTE
        }

        teardownCallResourcesAndReset(
            sessionId = updated.sessionId,
            reason = reason
        )

        if (wasShowing) {
            when (updated.status) {
                CallSession.STATUS_BUSY -> showToast("Абонент @$otherNick сейчас занят в другом звонке")
                CallSession.STATUS_DECLINED -> showToast("Звонок отклонён @$otherNick")
                CallSession.STATUS_MISSED -> showToast("Звонок с @$otherNick отменён или без ответа")
                else -> showToast("Звонок завершён")
            }
        }
    }

    private fun observeIncomingCallsForCurrentUser() {
        if (currentUserId.isBlank()) return
        viewModelScope.launch {
            repository.observeUserCalls(currentUserId).collect { sessions ->
                _latestUserCalls.value = sessions
                val nowMs = System.currentTimeMillis()
                val current = _callUiModel.value.session

                // 1. If we currently have an active call, check if the remote peer ended/declined/accepted it
                if (current != null) {
                    val matched = sessions.firstOrNull { it.callId == current.callId }
                    if (matched != null) {
                        if (matched.status in listOf(
                                CallSession.STATUS_DECLINED,
                                CallSession.STATUS_MISSED,
                                CallSession.STATUS_BUSY,
                                CallSession.STATUS_ENDED
                            )
                        ) {
                            handleRemoteCallTerminated(matched)
                            return@collect
                        } else if (!handledTerminalSessionIds.contains(matched.sessionId)) {
                            handleSignalingUpdate(matched)
                        }
                    }
                }

                // 2. Check for any incoming ringing call targeting currentUserId
                val incomingRinging = sessions.firstOrNull { call ->
                    val ageMs = if (call.updatedAtMillis > 0L) nowMs - call.updatedAtMillis else 0L
                    call.calleeId == currentUserId &&
                        call.status == CallSession.STATUS_RINGING &&
                        ageMs <= 90_000L &&
                        !handledTerminalSessionIds.contains(call.sessionId)
                }

                if (incomingRinging != null) {
                    val activeNow = _callUiModel.value
                    if (activeNow.phase == CallPhase.IDLE || activeNow.phase == CallPhase.ENDED) {
                        syncCallState(CallStateReducer.transitionToIncoming(incomingRinging))
                        watchCallSessionById(incomingRinging.callId)
                    } else if (activeNow.session != null && activeNow.session.callId != incomingRinging.callId) {
                        // User is already in another call -> report BUSY automatically without interrupting active call
                        handledTerminalSessionIds.add(incomingRinging.sessionId)
                        launch {
                            repository.updateCallStatus(incomingRinging.callId, CallSession.STATUS_BUSY)
                        }
                    }
                }
            }
        }
        viewModelScope.launch {
            PhonogrammNotificationHelper.incomingCallSession.collect { notifCall ->
                if (notifCall != null &&
                    notifCall.calleeId == currentUserId &&
                    notifCall.status == CallSession.STATUS_RINGING &&
                    !handledTerminalSessionIds.contains(notifCall.sessionId)
                ) {
                    val activeNow = _callUiModel.value
                    if (activeNow.phase == CallPhase.IDLE || activeNow.phase == CallPhase.ENDED) {
                        syncCallState(CallStateReducer.transitionToIncoming(notifCall))
                        watchCallSessionById(notifCall.callId)
                    }
                }
            }
        }
    }

    private fun handleSignalingUpdate(updated: CallSession) {
        if (handledTerminalSessionIds.contains(updated.sessionId)) return
        val cur = _callUiModel.value
        val isCaller = updated.callerId == currentUserId
        val remoteVideo = updated.peerVideoEnabled(currentUserId)
        val remoteMuted = updated.peerMuted(currentUserId)

        // Feed remote ICE candidates into WebRtcCallEngine (buffered until remote SDP is set)
        val peerCandidates = updated.peerCandidates(currentUserId)
        if (peerCandidates.isNotEmpty()) {
            webRtcEngine?.onRemoteIceCandidatesReceived(updated.sessionId, peerCandidates)
        }

        if (isCaller) {
            if (updated.status == CallSession.STATUS_ACCEPTED) {
                noAnswerTimeoutJob?.cancel()
                noAnswerTimeoutJob = null

                val hasAnswerSdp = updated.answerSdp.isNotBlank()
                if (hasAnswerSdp &&
                    lastAppliedAnswerSdpForSession != (updated.sessionId to updated.answerSdp)
                ) {
                    lastAppliedAnswerSdpForSession = updated.sessionId to updated.answerSdp
                    webRtcEngine?.applyRemoteAnswer(updated.sessionId, updated.answerSdp)
                }

                val nextPhase = when (cur.phase) {
                    CallPhase.OUTGOING -> if (hasAnswerSdp) CallPhase.ACTIVE else CallPhase.CONNECTING
                    CallPhase.CONNECTING -> if (hasAnswerSdp) CallPhase.ACTIVE else CallPhase.CONNECTING
                    else -> cur.phase
                }
                syncCallState(
                    cur.copy(
                        phase = nextPhase,
                        session = updated,
                        isIncoming = false,
                        isPeerMuted = remoteMuted,
                        isRemoteVideoEnabled = remoteVideo
                    )
                )
                if (nextPhase == CallPhase.ACTIVE) {
                    startCallDurationTimer(updated.sessionId)
                }
            } else {
                syncCallState(
                    cur.copy(
                        session = updated,
                        isPeerMuted = remoteMuted,
                        isRemoteVideoEnabled = remoteVideo
                    )
                )
            }
        } else {
            // Callee side
            if (updated.offerSdp.isNotBlank() &&
                (cur.phase == CallPhase.CONNECTING || cur.phase == CallPhase.ACTIVE || cur.phase == CallPhase.RECONNECTING) &&
                lastAppliedOfferSdpForSession != (updated.sessionId to updated.offerSdp)
            ) {
                lastAppliedOfferSdpForSession = updated.sessionId to updated.offerSdp
                webRtcEngine?.acceptOfferAndCreateAnswer(updated.sessionId, updated.offerSdp)
            }

            val nextPhase = if (updated.status == CallSession.STATUS_ACCEPTED && cur.phase == CallPhase.CONNECTING) {
                CallPhase.ACTIVE
            } else {
                cur.phase
            }
            syncCallState(
                cur.copy(
                    phase = nextPhase,
                    session = updated,
                    isPeerMuted = remoteMuted,
                    isRemoteVideoEnabled = remoteVideo
                )
            )
            if (nextPhase == CallPhase.ACTIVE) {
                startCallDurationTimer(updated.sessionId)
            }
        }
    }

    private fun watchCallSessionById(callId: String) {
        activeCallListenerJob?.cancel()
        activeCallListenerJob = viewModelScope.launch {
            repository.observeCallSession(callId).collect { updated ->
                if (updated == null) {
                    if (_callUiModel.value.session?.callId == callId) {
                        teardownCallResourcesAndReset(
                            sessionId = _callUiModel.value.session?.sessionId,
                            reason = CallEndReason.HANGUP_REMOTE
                        )
                    }
                    return@collect
                }

                when (updated.status) {
                    CallSession.STATUS_RINGING,
                    CallSession.STATUS_ACCEPTED -> {
                        if (!handledTerminalSessionIds.contains(updated.sessionId)) {
                            handleSignalingUpdate(updated)
                        }
                    }
                    CallSession.STATUS_DECLINED,
                    CallSession.STATUS_MISSED,
                    CallSession.STATUS_BUSY,
                    CallSession.STATUS_ENDED -> {
                        handleRemoteCallTerminated(updated)
                    }
                }
            }
        }
    }

    fun startCallByNickname(rawNickname: String, isVideo: Boolean) {
        val currentProfile = (profileState.value as? ProfileState.Ready)?.profile ?: return
        val existingModel = _callUiModel.value
        if (existingModel.session == null ||
            existingModel.session.status in listOf(
                CallSession.STATUS_DECLINED,
                CallSession.STATUS_MISSED,
                CallSession.STATUS_BUSY,
                CallSession.STATUS_ENDED
            )
        ) {
            if (existingModel.phase != CallPhase.IDLE) {
                syncCallState(CallStateReducer.transitionToIdle())
            }
        }
        if (!CallStateReducer.canStartNewCall(_callUiModel.value.phase)) {
            expandCall()
            return
        }
        if (!isStartingCallGuard.compareAndSet(false, true)) {
            return
        }

        val activeChatSnapshot = _activeChat.value
        val fallbackChatUsername = activeChatSnapshot?.otherParticipantUsername(currentUserId).orEmpty()
        val cleaned = rawNickname.trim().removePrefix("@").ifBlank {
            fallbackChatUsername.trim().removePrefix("@")
        }
        if (cleaned.equals("phonogramm", ignoreCase = true) ||
            cleaned.equals("олег", ignoreCase = true) ||
            cleaned.equals("oleg", ignoreCase = true) ||
            cleaned == "__system__"
        ) {
            isStartingCallGuard.set(false)
            showToast("Звонки доступны только реальным пользователям Oleg")
            return
        }
        if (cleaned.isNotBlank() && cleaned.equals(currentProfile.username, ignoreCase = true)) {
            isStartingCallGuard.set(false)
            showToast("Нельзя позвонить самому себе")
            return
        }

        viewModelScope.launch {
            try {
                val activePeerUid = activeChatSnapshot?.otherParticipantId(currentUserId).orEmpty()
                val cachedTarget = _peerProfiles.value[cleaned.lowercase()]
                    ?: _peerProfiles.value.values.firstOrNull {
                        (cleaned.isNotBlank() && it.username.equals(cleaned, ignoreCase = true)) ||
                            (cleaned.isNotBlank() && it.uid == cleaned) ||
                            (activePeerUid.isNotBlank() && it.uid == activePeerUid)
                    }
                val byNickname = if (cachedTarget == null && cleaned.isNotBlank()) {
                    repository.findUserByNickname(cleaned).getOrNull()
                } else {
                    null
                }
                val byActiveChatUid = if (cachedTarget == null && byNickname == null && activePeerUid.isNotBlank()) {
                    repository.getUserProfile(activePeerUid).getOrNull()
                        ?: UserProfile(
                            id = activePeerUid,
                            uid = activePeerUid,
                            username = cleaned.ifBlank { "User" },
                            usernameLower = cleaned.ifBlank { "user" }.lowercase()
                        )
                } else {
                    null
                }
                val targetUser = cachedTarget ?: byNickname ?: byActiveChatUid
                if (targetUser == null || targetUser.uid.isBlank()) {
                    showToast("Пользователь @$cleaned не найден")
                    return@launch
                }
                if (targetUser.uid == currentUserId) {
                    showToast("Нельзя позвонить самому себе")
                    return@launch
                }

                val callResult = repository.startOutgoingCall(
                    caller = currentProfile,
                    callee = targetUser,
                    isVideo = isVideo
                )
                callResult.fold(
                    onSuccess = { session ->
                        lastAppliedOfferSdpForSession = null
                        lastAppliedAnswerSdpForSession = null
                        syncCallState(CallStateReducer.transitionToOutgoing(session, isVideo))
                        callAudioRouteManager?.acquireCallAudioRoute(enableSpeakerphone = true)
                        webRtcEngine?.startSession(
                            sessionId = session.sessionId,
                            isCaller = true,
                            initialVideoEnabled = isVideo,
                            initialMuted = false,
                            callbacks = createEngineCallbacks(session)
                        )
                        startNoAnswerTimeout(session)
                        watchCallSessionById(session.callId)

                        launch {
                            val chatRes = repository.getOrCreateDirectChat(currentProfile, targetUser)
                            chatRes.getOrNull()?.let { chat ->
                                val callMsgText = if (isVideo) {
                                    "📹 Видеозвонок от @${currentProfile.username}"
                                } else {
                                    "📞 Аудиозвонок от @${currentProfile.username}"
                                }
                                repository.sendMessage(
                                    chat = chat,
                                    senderProfile = currentProfile,
                                    rawText = callMsgText
                                )
                            }
                        }
                    },
                    onFailure = { err ->
                        showToast(err.message ?: "Не удалось начать звонок")
                    }
                )
            } finally {
                isStartingCallGuard.set(false)
            }
        }
    }

    fun acceptIncomingCall(callSession: CallSession, enableVideoOnAccept: Boolean = callSession.isVideo) {
        if (handledTerminalSessionIds.contains(callSession.sessionId)) return
        if (!isAcceptingCallGuard.compareAndSet(false, true)) return

        PhonogrammNotificationHelper.clearIncomingCallSession(appContext)
        val fromUi = _callUiModel.value.session?.takeIf { it.sessionId == callSession.sessionId }
        val fromObserved = _latestUserCalls.value.firstOrNull {
            it.callId == callSession.callId && it.sessionId == callSession.sessionId
        }
        val latestSession = when {
            fromObserved != null && fromObserved.offerSdp.isNotBlank() -> fromObserved
            fromUi != null && fromUi.offerSdp.isNotBlank() -> fromUi
            else -> fromObserved ?: fromUi ?: callSession
        }
        val accepted = latestSession.copy(
            status = CallSession.STATUS_ACCEPTED,
            calleeVideoEnabled = enableVideoOnAccept
        )

        val connectingModel = CallStateReducer.transitionToConnecting(
            current = _callUiModel.value,
            session = accepted,
            localVideoEnabled = enableVideoOnAccept,
            remoteVideoEnabled = accepted.callerVideoEnabled
        )
        syncCallState(CallStateReducer.transitionToActive(connectingModel))
        startCallDurationTimer(accepted.sessionId)

        callAudioRouteManager?.acquireCallAudioRoute(enableSpeakerphone = _callUiModel.value.isSpeakerOn)
        webRtcEngine?.startSession(
            sessionId = accepted.sessionId,
            isCaller = false,
            initialVideoEnabled = enableVideoOnAccept,
            initialMuted = _callUiModel.value.isMuted,
            callbacks = createEngineCallbacks(accepted)
        )

        val hasImmediateOffer = accepted.offerSdp.isNotBlank()
        if (hasImmediateOffer) {
            lastAppliedOfferSdpForSession = accepted.sessionId to accepted.offerSdp
            webRtcEngine?.acceptOfferAndCreateAnswer(accepted.sessionId, accepted.offerSdp)
        }
        if (accepted.callerCandidates.isNotEmpty()) {
            webRtcEngine?.onRemoteIceCandidatesReceived(accepted.sessionId, accepted.callerCandidates)
        }

        watchCallSessionById(accepted.callId)
        viewModelScope.launch {
            try {
                // If offerSdp was not yet present on the document, publish ACCEPTED immediately;
                // otherwise acceptOfferAndCreateAnswer -> publishWebRtcAnswer atomically writes ACCEPTED + answerSdp.
                if (!hasImmediateOffer) {
                    repository.updateCallStatus(
                        callId = accepted.callId,
                        newStatus = CallSession.STATUS_ACCEPTED,
                        calleeVideoOnAccept = enableVideoOnAccept
                    )
                }
            } finally {
                isAcceptingCallGuard.set(false)
            }
        }
    }

    fun updateMyCallVideoState(callSession: CallSession, videoEnabled: Boolean) {
        val active = _callUiModel.value.session ?: return
        if (active.callId != callSession.callId || handledTerminalSessionIds.contains(callSession.sessionId)) return
        val cur = _callUiModel.value
        if (cur.isLocalVideoEnabled != videoEnabled) {
            syncCallState(cur.copy(isLocalVideoEnabled = videoEnabled))
        }
        webRtcEngine?.setLocalVideoEnabled(videoEnabled, cur.useFrontCamera)
        val isCaller = callSession.callerId == currentUserId
        viewModelScope.launch {
            repository.updateCallVideoState(
                callId = callSession.callId,
                isCaller = isCaller,
                videoEnabled = videoEnabled
            )
        }
    }

    fun declineOrHangupCall(callSession: CallSession? = _callUiModel.value.session) {
        val current = callSession ?: _callUiModel.value.session ?: _activeCallSession.value ?: return
        val reason = when {
            current.status == CallSession.STATUS_RINGING && current.calleeId == currentUserId ->
                CallEndReason.DECLINED_LOCAL
            current.status == CallSession.STATUS_RINGING && current.callerId == currentUserId ->
                CallEndReason.CANCELLED_LOCAL
            else ->
                CallEndReason.HANGUP_LOCAL
        }
        val nextStatus = when {
            current.status == CallSession.STATUS_RINGING && current.calleeId == currentUserId ->
                CallSession.STATUS_DECLINED
            current.status == CallSession.STATUS_RINGING && current.callerId == currentUserId ->
                CallSession.STATUS_MISSED
            else ->
                CallSession.STATUS_ENDED
        }

        teardownCallResourcesAndReset(
            sessionId = current.sessionId,
            reason = reason
        )

        viewModelScope.launch {
            repository.updateCallStatus(current.callId, nextStatus)
        }
    }

    fun deleteMyAccount(onAccountDeleted: () -> Unit) {
        if (_isDeletingAccount.value) return
        _isDeletingAccount.value = true
        val currentProfile = (profileState.value as? ProfileState.Ready)?.profile

        viewModelScope.launch {
            PhonogrammNotificationHelper.stopMonitoring()
            closeActiveChat()
            val result = repository.deleteCurrentAccount(currentProfile)
            _isDeletingAccount.value = false
            result.fold(
                onSuccess = {
                    onAccountDeleted()
                },
                onFailure = { err ->
                    showToast("Ошибка при удалении аккаунта: ${err.message ?: "попробуйте снова"}")
                }
            )
        }
    }

    private fun startPresenceHeartbeat() {
        if (currentUserId.isBlank()) return
        presenceHeartbeatJob?.cancel()
        presenceHeartbeatJob = viewModelScope.launch {
            while (_isAppInForeground.value) {
                repository.updatePresence(isOnline = true, explicitUserId = currentUserId)
                kotlinx.coroutines.delay(PRESENCE_HEARTBEAT_INTERVAL_MS)
            }
        }
    }

    fun setAppInForeground(inForeground: Boolean) {
        val wasInForeground = _isAppInForeground.value
        _isAppInForeground.value = inForeground
        appContext?.let { ctx ->
            PhonogrammNotificationHelper.setActivityInForeground(ctx, inForeground)
        }
        if (inForeground) {
            startPresenceHeartbeat()
            if (!wasInForeground) {
                viewModelScope.launch {
                    val chat = _activeChat.value
                    val currentMessages = (messagesState.value as? UiState.Success)?.data
                    if (chat != null && !currentMessages.isNullOrEmpty()) {
                        repository.markMessagesAsRead(chat.id, currentUserId, currentMessages)
                    }
                }
            }
        } else {
            presenceHeartbeatJob?.cancel()
            presenceHeartbeatJob = null
            viewModelScope.launch {
                repository.updatePresence(isOnline = false, explicitUserId = currentUserId)
            }
        }
    }

    suspend fun markOfflineBeforeSignOut() {
        _isAppInForeground.value = false
        presenceHeartbeatJob?.cancel()
        presenceHeartbeatJob = null
        peerListenerJobs.values.forEach { it.cancel() }
        peerListenerJobs.clear()
        repository.updatePresence(isOnline = false, explicitUserId = currentUserId)
    }

    override fun onCleared() {
        presenceHeartbeatJob?.cancel()
        peerListenerJobs.values.forEach { it.cancel() }
        peerListenerJobs.clear()
        teardownCallResourcesAndReset(
            sessionId = _callUiModel.value.session?.sessionId,
            reason = CallEndReason.HANGUP_LOCAL
        )
        super.onCleared()
    }

    fun dismissInAppNotification() {
        _localInAppNotification.value = null
        PhonogrammNotificationHelper.dismissInAppNotification()
    }

    private fun dispatchIncomingNotification(notification: IncomingMessageNotification) {
        val ctx = appContext
        if (ctx != null) {
            PhonogrammNotificationHelper.dispatchIncomingMessage(ctx, notification)
            return
        }
        val uniqueId = notification.id.ifBlank {
            "${notification.chatId}_${notification.senderUsername}_${System.nanoTime()}"
        }
        if (!dispatchedViewModelIds.add(uniqueId)) {
            return
        }
        if (_isAppInForeground.value) {
            _localInAppNotification.value = notification
        } else {
            _systemNotificationEvents.tryEmit(notification)
        }
    }

    val profileState: StateFlow<ProfileState> = _profileRetryTrigger
        .flatMapLatest {
            repository.observeUserProfile(currentUserId)
                .map<UserProfile?, ProfileState> { profile ->
                    if (profile != null && profile.username.isNotBlank()) {
                        checkIncomingSystemMessages(profile)
                        ProfileState.Ready(profile)
                    } else {
                        ProfileState.NeedsRegistration
                    }
                }
                .catch { error ->
                    val firestoreEx = (error as? FirebaseFirestoreException)
                        ?: (error.cause as? FirebaseFirestoreException)
                    Log.e(
                        TAG,
                        "Error observing user profile for uid=$currentUserId, code=${firestoreEx?.code}",
                        error
                    )
                    if (firestoreEx?.code == FirebaseFirestoreException.Code.NOT_FOUND) {
                        emit(ProfileState.NeedsRegistration)
                    } else {
                        emit(ProfileState.Error(formatFirestoreProfileError(error, firestoreEx)))
                    }
                }
        }
        .stateIn(
            scope = viewModelScope,
            started = SharingStarted.Eagerly,
            initialValue = ProfileState.Loading
        )

    private fun checkIncomingSystemMessages(profile: UserProfile) {
        val sysList = profile.parsedSystemMessages
        if (!hasInitializedSystemBaseline) {
            hasInitializedSystemBaseline = true
            sysList.forEach { msg ->
                knownSystemMessageIds.add(msg.id.ifBlank { "${msg.timestamp}_${msg.text.hashCode()}" })
            }
            return
        }
        for (msg in sysList) {
            val key = msg.id.ifBlank { "${msg.timestamp}_${msg.text.hashCode()}" }
            if (knownSystemMessageIds.add(key)) {
                dispatchIncomingNotification(
                    IncomingMessageNotification(
                        id = key,
                        chatId = "__system__",
                        senderUsername = "Oleg",
                        senderDisplayName = "Oleg",
                        messageText = msg.text,
                        isSystemBot = true
                    )
                )
            }
        }
    }

    val isVerifiedAdmin: StateFlow<Boolean> = combine(
        profileState,
        repository.observeAdminStatus(currentUserId)
    ) { state, serverAdminVerified ->
        val profile = (state as? ProfileState.Ready)?.profile
        profile != null &&
            profile.usernameLower == MessengerRepository.ADMIN_USERNAME_LOWER &&
            serverAdminVerified
    }.stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(STOP_TIMEOUT_MILLIS),
        initialValue = false
    )

    fun retryLoadProfile() {
        _profileRetryTrigger.value += 1
    }

    private fun formatFirestoreProfileError(
        error: Throwable,
        firestoreEx: FirebaseFirestoreException?
    ): String {
        return when (firestoreEx?.code) {
            FirebaseFirestoreException.Code.UNAVAILABLE,
            FirebaseFirestoreException.Code.DEADLINE_EXCEEDED ->
                "Нет соединения с сервером Cloud Firestore. Проверьте подключение к интернету и нажмите «Повторить»."
            FirebaseFirestoreException.Code.PERMISSION_DENIED,
            FirebaseFirestoreException.Code.UNAUTHENTICATED ->
                "Ошибка доступа к профилю (${firestoreEx.code}). Попробуйте нажать «Повторить подключение» или перезайти в аккаунт."
            else ->
                error.localizedMessage ?: "Не удалось загрузить профиль пользователя. Попробуйте ещё раз."
        }
    }

    val chatsState: StateFlow<UiState<List<DirectChat>>> = profileState
        .flatMapLatest { state ->
            if (state is ProfileState.Ready) {
                repository.observeUserChats(currentUserId)
                    .map<List<DirectChat>, UiState<List<DirectChat>>> { chats ->
                        refreshPeerProfiles(chats, state.profile.contacts)
                        detectIncomingMessagesFromChats(chats)
                        UiState.Success(chats)
                    }
                    .catch { error ->
                        Log.w(TAG, "Error observing user chats", error)
                        emit(UiState.Error(error.localizedMessage ?: "Не удалось загрузить список чатов"))
                    }
            } else {
                flowOf(UiState.Loading)
            }
        }
        .stateIn(
            scope = viewModelScope,
            started = SharingStarted.Eagerly,
            initialValue = UiState.Loading
        )

    private fun detectIncomingMessagesFromChats(chats: List<DirectChat>) {
        if (appContext != null) {
            return
        }
        if (!hasInitializedChatsBaseline) {
            hasInitializedChatsBaseline = true
            for (chat in chats) {
                chatBaselines[chat.id] = ChatSnapshotBaseline(
                    updatedAtMillis = chat.updatedAtMillis,
                    lastMessageText = chat.lastMessageText,
                    lastSenderId = chat.lastSenderId
                )
            }
            return
        }

        for (chat in chats) {
            val prev = chatBaselines[chat.id]
            val currentBaseline = ChatSnapshotBaseline(
                updatedAtMillis = chat.updatedAtMillis,
                lastMessageText = chat.lastMessageText,
                lastSenderId = chat.lastSenderId
            )
            chatBaselines[chat.id] = currentBaseline

            val isFromOtherUser = chat.lastSenderId.isNotBlank() && chat.lastSenderId != currentUserId
            val hasMessageText = chat.lastMessageText.isNotBlank()
            val isChanged = prev == null ||
                chat.updatedAtMillis > prev.updatedAtMillis ||
                chat.lastMessageText != prev.lastMessageText ||
                chat.lastSenderId != prev.lastSenderId

            if (isFromOtherUser && hasMessageText && isChanged) {
                val peerNick = chat.otherParticipantUsername(currentUserId).ifBlank { "пользователя" }
                val cachedPeer = _peerProfiles.value[peerNick.lowercase()]
                dispatchIncomingNotification(
                    IncomingMessageNotification(
                        id = "${chat.id}_${chat.updatedAtMillis}_${chat.lastMessageText.hashCode()}_${System.nanoTime()}",
                        chatId = chat.id,
                        senderUsername = peerNick,
                        senderDisplayName = cachedPeer?.effectiveDisplayName ?: peerNick,
                        senderAvatarUrl = cachedPeer?.avatarUrl ?: "",
                        messageText = chat.lastMessageText,
                        isSystemBot = false
                    )
                )
            }
        }
    }

    private val _peerProfiles = MutableStateFlow<Map<String, UserProfile>>(emptyMap())
    val peerProfiles: StateFlow<Map<String, UserProfile>> = _peerProfiles.asStateFlow()

    private val _isRegistering = MutableStateFlow(false)
    val isRegistering: StateFlow<Boolean> = _isRegistering.asStateFlow()

    private val _registrationError = MutableStateFlow<String?>(null)
    val registrationError: StateFlow<String?> = _registrationError.asStateFlow()

    private val _searchState = MutableStateFlow<UserSearchState>(UserSearchState.Idle)
    val searchState: StateFlow<UserSearchState> = _searchState.asStateFlow()

    private val _activeChat = MutableStateFlow<DirectChat?>(null)
    val activeChat: StateFlow<DirectChat?> = _activeChat.asStateFlow()

    private val _isSystemBotChatOpen = MutableStateFlow(false)
    val isSystemBotChatOpen: StateFlow<Boolean> = _isSystemBotChatOpen.asStateFlow()

    val messagesState: StateFlow<UiState<List<ChatMessage>>> = _activeChat
        .flatMapLatest { chat ->
            if (chat == null) {
                activeChatBaselineId = null
                knownActiveChatMessageIds.clear()
                flowOf(UiState.Success(emptyList()))
            } else {
                repository.observeMessages(chat.id, currentUserId)
                    .map<List<ChatMessage>, UiState<List<ChatMessage>>> { list ->
                        detectIncomingMessagesInActiveChat(chat, list)
                        if (_isAppInForeground.value) {
                            viewModelScope.launch {
                                repository.markMessagesAsRead(chat.id, currentUserId, list)
                            }
                        }
                        UiState.Success(list)
                    }
                    .catch { error ->
                        Log.w(TAG, "Error observing messages for chat ${chat.id}", error)
                        emit(UiState.Error(error.localizedMessage ?: "Не удалось загрузить сообщения"))
                    }
            }
        }
        .stateIn(
            scope = viewModelScope,
            started = SharingStarted.Eagerly,
            initialValue = UiState.Loading
        )

    private fun detectIncomingMessagesInActiveChat(chat: DirectChat, messages: List<ChatMessage>) {
        if (activeChatBaselineId != chat.id) {
            activeChatBaselineId = chat.id
            knownActiveChatMessageIds.clear()
            messages.forEach { knownActiveChatMessageIds.add(it.id) }
            return
        }
        for (msg in messages) {
            if (msg.id.isNotBlank() && knownActiveChatMessageIds.add(msg.id)) {
                if (msg.senderId.isNotBlank() && msg.senderId != currentUserId && msg.text.isNotBlank()) {
                    val peerNick = msg.senderUsername.ifBlank {
                        chat.otherParticipantUsername(currentUserId).ifBlank { "пользователя" }
                    }
                    val cachedPeer = _peerProfiles.value[peerNick.lowercase()]
                    dispatchIncomingNotification(
                        IncomingMessageNotification(
                            id = msg.id,
                            chatId = chat.id,
                            senderUsername = peerNick,
                            senderDisplayName = cachedPeer?.effectiveDisplayName ?: peerNick,
                            senderAvatarUrl = cachedPeer?.avatarUrl ?: "",
                            messageText = msg.text,
                            isSystemBot = false
                        )
                    )
                }
            }
        }
    }

    private val _replyingTo = MutableStateFlow<ChatMessage?>(null)
    val replyingTo: StateFlow<ChatMessage?> = _replyingTo.asStateFlow()

    private val _isCreatingChat = MutableStateFlow(false)
    val isCreatingChat: StateFlow<Boolean> = _isCreatingChat.asStateFlow()

    private val _chatCreationError = MutableStateFlow<String?>(null)
    val chatCreationError: StateFlow<String?> = _chatCreationError.asStateFlow()

    private val _isSendingMessage = MutableStateFlow(false)
    val isSendingMessage: StateFlow<Boolean> = _isSendingMessage.asStateFlow()

    private val _sendMessageError = MutableStateFlow<String?>(null)
    val sendMessageError: StateFlow<String?> = _sendMessageError.asStateFlow()

    private val _toastMessage = MutableStateFlow<String?>(null)
    val toastMessage: StateFlow<String?> = _toastMessage.asStateFlow()

    private val _inspectedPeerProfile = MutableStateFlow<UserProfile?>(null)
    val inspectedPeerProfile: StateFlow<UserProfile?> = _inspectedPeerProfile.asStateFlow()

    private val _selectedGiftDetail = MutableStateFlow<Pair<GiftItem, Boolean>?>(null)
    val selectedGiftDetail: StateFlow<Pair<GiftItem, Boolean>?> = _selectedGiftDetail.asStateFlow()

    private val _lastGeneratedCode = MutableStateFlow<String?>(null)
    val lastGeneratedCode: StateFlow<String?> = _lastGeneratedCode.asStateFlow()

    fun showToast(message: String) {
        _toastMessage.value = message
    }

    fun clearToast() {
        _toastMessage.value = null
    }

    private fun applyUpdatedPeerProfile(prof: UserProfile) {
        val key = prof.usernameLower.ifBlank { prof.username.lowercase() }.ifBlank { prof.uid }
        if (key.isBlank()) return
        val updated = _peerProfiles.value.toMutableMap()
        updated[key] = prof
        _peerProfiles.value = updated
        PhonogrammNotificationHelper.updatePeerMetadata(
            username = prof.username,
            displayName = prof.effectiveDisplayName,
            avatarUrl = prof.avatarUrl
        )
        val currentInspected = _inspectedPeerProfile.value
        if (currentInspected != null &&
            (currentInspected.uid == prof.uid || currentInspected.usernameLower == prof.usernameLower)
        ) {
            _inspectedPeerProfile.value = prof
        }
        val currentSearch = _searchState.value
        if (currentSearch is UserSearchState.Found && currentSearch.user.uid == prof.uid) {
            _searchState.value = UserSearchState.Found(
                user = prof,
                isSelf = prof.uid == currentUserId
            )
        }
    }

    private fun subscribeToPeerProfile(peerUid: String) {
        if (peerUid.isBlank() || peerUid == currentUserId) return
        if (peerListenerJobs[peerUid]?.isActive == true) return
        peerListenerJobs[peerUid] = viewModelScope.launch {
            repository.observePeerProfile(peerUid).collect { prof ->
                if (prof != null) {
                    applyUpdatedPeerProfile(prof)
                }
            }
        }
    }

    private fun refreshPeerProfiles(chats: List<DirectChat>, contacts: List<String>) {
        viewModelScope.launch {
            for (chat in chats) {
                val otherUid = chat.otherParticipantId(currentUserId)
                if (otherUid.isNotBlank()) {
                    subscribeToPeerProfile(otherUid)
                }
            }
            for (contactNick in contacts) {
                val clean = contactNick.trim().lowercase()
                if (clean.isNotBlank()) {
                    val existing = _peerProfiles.value[clean]
                    if (existing != null && existing.uid.isNotBlank()) {
                        subscribeToPeerProfile(existing.uid)
                    } else {
                        repository.findUserByNickname(clean).getOrNull()?.let { prof ->
                            applyUpdatedPeerProfile(prof)
                            subscribeToPeerProfile(prof.uid)
                        }
                    }
                }
            }
        }
    }

    fun clearRegistrationError() {
        _registrationError.value = null
    }

    fun registerNickname(rawNickname: String, rawBirthday: String = "") {
        if (_isRegistering.value) return
        val validation = repository.validateNickname(rawNickname)
        if (validation.isFailure) {
            _registrationError.value = validation.exceptionOrNull()?.message
            return
        }

        _isRegistering.value = true
        _registrationError.value = null

        viewModelScope.launch {
            val result = repository.registerNickname(rawNickname, rawBirthday)
            _isRegistering.value = false
            result.fold(
                onSuccess = { profile ->
                    showToast("Добро пожаловать в Oleg, @${profile.username}! ✨")
                },
                onFailure = { err ->
                    _registrationError.value = err.message ?: "Ошибка при регистрации никнейма"
                }
            )
        }
    }

    fun updateProfileInfo(displayName: String, birthday: String, bio: String, onDone: () -> Unit = {}) {
        viewModelScope.launch {
            val res = repository.updateProfileInfo(displayName, birthday, bio)
            res.fold(
                onSuccess = {
                    showToast("Данные профиля сохранены! ✅")
                    onDone()
                },
                onFailure = { err ->
                    showToast("Ошибка сохранения: ${err.message}")
                }
            )
        }
    }

    fun updateAvatarStyle(avatarStyleOrUri: String) {
        val current = (profileState.value as? ProfileState.Ready)?.profile ?: return
        viewModelScope.launch {
            val res = repository.updateProfileInfo(
                displayName = current.displayName,
                birthday = current.birthday,
                bio = current.bio,
                avatarUrl = avatarStyleOrUri
            )
            res.fold(
                onSuccess = {
                    showToast("Фото профиля обновлено! ✅")
                },
                onFailure = { err ->
                    showToast("Ошибка обновления аватара: ${err.message ?: "попробуйте снова"}")
                }
            )
        }
    }

    fun submitVerificationRequest(reason: String) {
        val current = (profileState.value as? ProfileState.Ready)?.profile ?: return
        val cleanReason = reason.trim().take(500)
        if (cleanReason.isEmpty()) return
        viewModelScope.launch {
            val adminProfile = repository.findUserByNickname("ShabanDurov").getOrNull()
            if (adminProfile != null && adminProfile.uid != current.uid) {
                val chatRes = repository.getOrCreateDirectChat(current, adminProfile)
                chatRes.getOrNull()?.let { chat ->
                    repository.sendMessage(
                        chat = chat,
                        senderProfile = current,
                        rawText = "✔ Заявка на галочку верификации от @${current.username}:\n$cleanReason"
                    )
                }
            }
            showToast("Заявка на галочку верификации отправлена создателю ✔")
        }
    }

    fun searchUserByNickname(rawQuery: String) {
        val trimmed = rawQuery.trim().removePrefix("@")
        if (trimmed.isEmpty()) {
            _searchState.value = UserSearchState.Idle
            return
        }
        val validation = repository.validateNickname(trimmed)
        if (validation.isFailure) {
            _searchState.value = UserSearchState.InvalidQuery(
                validation.exceptionOrNull()?.message ?: "Некорректный формат никнейма"
            )
            return
        }

        _searchState.value = UserSearchState.Searching
        viewModelScope.launch {
            val result = repository.findUserByNickname(trimmed)
            result.fold(
                onSuccess = { foundProfile ->
                    if (foundProfile == null) {
                        _searchState.value = UserSearchState.NotFound(trimmed)
                    } else {
                        applyUpdatedPeerProfile(foundProfile)
                        subscribeToPeerProfile(foundProfile.uid)
                        _searchState.value = UserSearchState.Found(
                            user = foundProfile,
                            isSelf = foundProfile.uid == currentUserId
                        )
                    }
                },
                onFailure = { error ->
                    _searchState.value = UserSearchState.Error(
                        error.localizedMessage ?: "Не удалось выполнить поиск"
                    )
                }
            )
        }
    }

    fun clearSearch() {
        _searchState.value = UserSearchState.Idle
    }

    fun openSystemBotChat() {
        _activeChat.value = null
        _replyingTo.value = null
        _sendMessageError.value = null
        _isSystemBotChatOpen.value = true
    }

    fun openChat(chat: DirectChat) {
        _isSystemBotChatOpen.value = false
        _sendMessageError.value = null
        _replyingTo.value = null
        _activeChat.value = chat

        val otherUid = chat.otherParticipantId(currentUserId)
        subscribeToPeerProfile(otherUid)
        viewModelScope.launch {
            repository.getUserProfile(otherUid).getOrNull()?.let { prof ->
                applyUpdatedPeerProfile(prof)
            }
        }
    }

    fun closeActiveChat() {
        _activeChat.value = null
        _isSystemBotChatOpen.value = false
        _replyingTo.value = null
        _sendMessageError.value = null
    }

    fun setReplyToMessage(message: ChatMessage) {
        _replyingTo.value = message
    }

    fun clearReplyToMessage() {
        _replyingTo.value = null
    }

    fun openPeerProfileModal(usernameOrUid: String) {
        viewModelScope.launch {
            val clean = usernameOrUid.trim().removePrefix("@")
            val activePeerUid = _activeChat.value?.otherParticipantId(currentUserId).orEmpty()
            val cached = _peerProfiles.value[clean.lowercase()]
                ?: _peerProfiles.value.values.firstOrNull {
                    (clean.isNotBlank() && it.username.equals(clean, ignoreCase = true)) ||
                        (clean.isNotBlank() && it.uid == clean) ||
                        (activePeerUid.isNotBlank() && it.uid == activePeerUid)
                }
            if (cached != null) {
                _inspectedPeerProfile.value = cached
                subscribeToPeerProfile(cached.uid)
            }
            val freshByNick = if (clean.isNotBlank()) {
                repository.findUserByNickname(clean).getOrNull()
            } else {
                null
            }
            val fresh = freshByNick ?: if (activePeerUid.isNotBlank()) {
                repository.getUserProfile(activePeerUid).getOrNull()
            } else {
                null
            }
            if (fresh != null) {
                applyUpdatedPeerProfile(fresh)
                subscribeToPeerProfile(fresh.uid)
                _inspectedPeerProfile.value = fresh
            }
        }
    }

    fun closePeerProfileModal() {
        _inspectedPeerProfile.value = null
    }

    fun openGiftDetailSheet(gift: GiftItem, isMyProfile: Boolean) {
        _selectedGiftDetail.value = gift to isMyProfile
    }

    fun closeGiftDetailSheet() {
        _selectedGiftDetail.value = null
    }

    fun toggleGiftVisibility(gift: GiftItem) {
        val currentProfile = (profileState.value as? ProfileState.Ready)?.profile ?: return
        viewModelScope.launch {
            val result = repository.toggleGiftVisibility(gift.id, currentProfile)
            if (result.isSuccess) {
                val nextHidden = !gift.hidden
                _selectedGiftDetail.value = gift.copy(hidden = nextHidden) to true
                showToast(
                    if (nextHidden) "Подарок скрыт из профиля"
                    else "Подарок снова отображается в профиле"
                )
            }
        }
    }

    fun startOrOpenChatWithUser(targetUser: UserProfile, onSuccess: () -> Unit = {}) {
        val currentProfile = (profileState.value as? ProfileState.Ready)?.profile ?: return
        if (_isCreatingChat.value) return

        _isCreatingChat.value = true
        _chatCreationError.value = null

        viewModelScope.launch {
            val result = repository.getOrCreateDirectChat(currentProfile, targetUser)
            _isCreatingChat.value = false
            result.fold(
                onSuccess = { chat ->
                    applyUpdatedPeerProfile(targetUser)
                    subscribeToPeerProfile(targetUser.uid)
                    _isSystemBotChatOpen.value = false
                    _activeChat.value = chat
                    onSuccess()
                },
                onFailure = { err ->
                    _chatCreationError.value = err.message ?: "Не удалось открыть личный чат"
                }
            )
        }
    }

    fun startOrOpenChatByNickname(rawNickname: String, onSuccess: () -> Unit = {}) {
        val currentProfile = (profileState.value as? ProfileState.Ready)?.profile ?: return
        if (_isCreatingChat.value) return

        val cleaned = rawNickname.trim().removePrefix("@")
        if (cleaned.equals("phonogramm", ignoreCase = true) ||
            cleaned.equals("олег", ignoreCase = true) ||
            cleaned.equals("oleg", ignoreCase = true)
        ) {
            openSystemBotChat()
            onSuccess()
            return
        }
        val validation = repository.validateNickname(cleaned)
        if (validation.isFailure) {
            _chatCreationError.value = validation.exceptionOrNull()?.message
            showToast(validation.exceptionOrNull()?.message ?: "Введите корректный @никнейм")
            return
        }
        if (cleaned.equals(currentProfile.username, ignoreCase = true)) {
            _chatCreationError.value = "Нельзя создать личный чат с самим собой"
            showToast("Нельзя создать личный чат с самим собой")
            return
        }

        _isCreatingChat.value = true
        _chatCreationError.value = null

        viewModelScope.launch {
            val lookupResult = repository.findUserByNickname(cleaned)
            lookupResult.fold(
                onSuccess = { targetUser ->
                    if (targetUser == null) {
                        _isCreatingChat.value = false
                        val msg = "Пользователь @$cleaned не найден"
                        _chatCreationError.value = msg
                        showToast(msg)
                    } else if (targetUser.uid == currentUserId) {
                        _isCreatingChat.value = false
                        val msg = "Нельзя создать личный чат с самим собой"
                        _chatCreationError.value = msg
                        showToast(msg)
                    } else {
                        val chatResult = repository.getOrCreateDirectChat(currentProfile, targetUser)
                        _isCreatingChat.value = false
                        chatResult.fold(
                            onSuccess = { chat ->
                                applyUpdatedPeerProfile(targetUser)
                                subscribeToPeerProfile(targetUser.uid)
                                _isSystemBotChatOpen.value = false
                                _activeChat.value = chat
                                onSuccess()
                            },
                            onFailure = { err ->
                                _chatCreationError.value = err.message ?: "Не удалось создать чат"
                            }
                        )
                    }
                },
                onFailure = { err ->
                    _isCreatingChat.value = false
                    _chatCreationError.value = err.localizedMessage ?: "Ошибка поиска пользователя"
                }
            )
        }
    }

    fun clearChatCreationError() {
        _chatCreationError.value = null
    }

    fun sendMessage(
        rawText: String,
        onSent: () -> Unit = {},
        explicitVoiceAudioBase64: String? = null,
        explicitImageBase64: String? = null
    ) {
        val chat = _activeChat.value ?: return
        val currentProfile = (profileState.value as? ProfileState.Ready)?.profile ?: return
        val trimmed = rawText.trim()
        if (trimmed.isEmpty()) return

        val replyMsg = _replyingTo.value
        val voiceB64 = explicitVoiceAudioBase64 ?: PhonogrammMediaHelper.consumeRecordedVoiceBase64(trimmed)
        val imageB64 = explicitImageBase64 ?: PhonogrammMediaHelper.consumePendingChatPhoto(trimmed)
        _isSendingMessage.value = true
        _sendMessageError.value = null
        _replyingTo.value = null
        onSent()

        viewModelScope.launch {
            try {
                val result = repository.sendMessage(
                    chat = chat,
                    senderProfile = currentProfile,
                    rawText = trimmed,
                    replyToSender = replyMsg?.senderUsername,
                    replyToText = replyMsg?.text,
                    voiceAudioBase64 = voiceB64,
                    imageBase64 = imageB64
                )
                result.onFailure { err ->
                    _sendMessageError.value = err.message ?: "Не удалось отправить сообщение. Проверьте подключение к сети."
                }
            } finally {
                _isSendingMessage.value = false
            }
        }
    }

    fun deleteMessageForMe(message: ChatMessage) {
        val chat = _activeChat.value ?: return
        viewModelScope.launch {
            val res = repository.deleteMessageForMe(chat.id, message, currentUserId)
            if (res.isSuccess) {
                showToast("Удалено у вас 🗑️")
            }
        }
    }

    fun deleteMessageForAll(message: ChatMessage) {
        val chat = _activeChat.value ?: return
        viewModelScope.launch {
            val res = repository.deleteMessageForAll(chat.id, message.id)
            if (res.isSuccess) {
                showToast("Удалено для обоих 💥")
            }
        }
    }

    fun clearActiveChatForMe() {
        val chat = _activeChat.value ?: return
        val msgs = (messagesState.value as? UiState.Success)?.data ?: emptyList()
        viewModelScope.launch {
            val res = repository.clearChatForMe(chat.id, currentUserId, msgs)
            if (res.isSuccess) {
                showToast("История очищена у вас ✅")
            }
        }
    }

    fun clearActiveChatForBoth() {
        val chat = _activeChat.value ?: return
        val msgs = (messagesState.value as? UiState.Success)?.data ?: emptyList()
        viewModelScope.launch {
            val res = repository.clearChatForBoth(chat.id, msgs)
            if (res.isSuccess) {
                showToast("Диалог очищен для всех! 💥")
            }
        }
    }

    fun deleteActiveContact() {
        val chat = _activeChat.value ?: return
        val otherNick = chat.otherParticipantUsername(currentUserId)
        val msgs = (messagesState.value as? UiState.Success)?.data ?: emptyList()
        viewModelScope.launch {
            repository.clearChatForMe(chat.id, currentUserId, msgs)
            repository.removeContact(otherNick.lowercase())
            closeActiveChat()
            showToast("Контакт @$otherNick удалён из контактов 🗑️")
        }
    }

    fun requestOpenAdminPanel(): Boolean {
        if (!isVerifiedAdmin.value) {
            showToast(AdminAccessDeniedException().message ?: "Отказано в доступе к панели администратора")
            return false
        }
        return true
    }

    fun adminSendGift(targetNickname: String, emoji: String, rarity: String, note: String) {
        if (!requestOpenAdminPanel()) return
        val currentProfile = (profileState.value as? ProfileState.Ready)?.profile ?: return
        viewModelScope.launch {
            val res = repository.sendGiftToUser(
                targetNickname = targetNickname,
                senderUsername = currentProfile.username,
                emoji = emoji,
                rarity = rarity,
                comment = note
            )
            res.fold(
                onSuccess = {
                    showToast("Подарок $emoji успешно вручен @${targetNickname.trim().removePrefix("@")}! 🚀")
                },
                onFailure = { err ->
                    showToast(err.message ?: "Ошибка отправки подарка")
                }
            )
        }
    }

    fun adminSetVerified(targetNickname: String, verified: Boolean) {
        if (!requestOpenAdminPanel()) return
        val currentProfile = (profileState.value as? ProfileState.Ready)?.profile ?: return
        viewModelScope.launch {
            val res = repository.setVerificationBadge(
                targetNickname = targetNickname,
                verified = verified,
                actorUsername = currentProfile.username
            )
            res.fold(
                onSuccess = {
                    val clean = targetNickname.trim().removePrefix("@")
                    showToast(if (verified) "Галочка выдана @$clean ✔" else "Галочка снята у @$clean")
                },
                onFailure = { err ->
                    showToast(err.message ?: "Ошибка изменения статуса верификации")
                }
            )
        }
    }

    fun adminGenerateCode(targetNickname: String) {
        if (!requestOpenAdminPanel()) return
        val currentProfile = (profileState.value as? ProfileState.Ready)?.profile ?: return
        viewModelScope.launch {
            val res = repository.generateSecurityCodeForUser(
                targetNickname = targetNickname,
                actorUsername = currentProfile.username
            )
            res.fold(
                onSuccess = { code ->
                    _lastGeneratedCode.value = code
                    showToast("Код $code сгенерирован и отправлен в системный чат 🔐")
                },
                onFailure = { err ->
                    showToast(err.message ?: "Ошибка генерации кода")
                }
            )
        }
    }

    fun clearSendMessageError() {
        _sendMessageError.value = null
    }

    companion object {
        private const val TAG = "MessengerVM"
        private const val STOP_TIMEOUT_MILLIS = 5000L
        private const val PRESENCE_HEARTBEAT_INTERVAL_MS = 20_000L
        private const val CALL_RING_TIMEOUT_MS = 45_000L
    }
}
