package com.example.ui.components

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInVertically
import androidx.compose.animation.slideOutVertically
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Call
import androidx.compose.material.icons.filled.CallEnd
import androidx.compose.material.icons.filled.CameraAlt
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Videocam
import androidx.compose.material.icons.filled.VisibilityOff
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.FilterQuality
import androidx.compose.ui.graphics.PathEffect
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.TextUnit
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.foundation.Image
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import com.example.R
import com.example.data.model.GiftItem
import com.example.data.model.IncomingMessageNotification
import com.example.ui.theme.LocalDeviceOptimizationMode
import com.example.ui.theme.LocalPhonogrammPalette
import com.example.ui.theme.PlusJakartaSansFontFamily
import com.example.ui.theme.getAvatarBrush
import com.example.util.PhonogrammMediaHelper
import java.util.Locale
import kotlinx.coroutines.delay

/**
 * Periodically ticks current epoch time in milliseconds so UI presence indicators
 * ("в сети" vs "был(а) X мин. назад") automatically update when a peer's heartbeat expires.
 */
@Composable
fun rememberPresenceClockMillis(intervalMs: Long = 15_000L): Long {
    var nowMillis by remember { mutableLongStateOf(System.currentTimeMillis()) }
    LaunchedEffect(intervalMs) {
        while (true) {
            delay(intervalMs)
            nowMillis = System.currentTimeMillis()
        }
    }
    return nowMillis
}

@Composable
fun PhonogrammAvatar(
    name: String,
    avatarUrl: String,
    modifier: Modifier = Modifier,
    size: Dp = 48.dp,
    cornerRadius: Dp = 16.dp,
    isSystemBot: Boolean = false,
    showOnlineDot: Boolean = false,
    isOnline: Boolean = true
) {
    PhonogrammAvatar(
        username = name,
        modifier = modifier,
        size = size,
        cornerRadius = cornerRadius,
        fontSize = (size.value * 0.38f).sp,
        isBot = isSystemBot,
        customEmojiOrText = avatarUrl,
        showOnlineDot = showOnlineDot && isOnline
    )
}

@Composable
fun PhonogrammAvatar(
    username: String,
    modifier: Modifier = Modifier,
    size: Dp = 48.dp,
    cornerRadius: Dp = 16.dp,
    fontSize: TextUnit = 18.sp,
    isBot: Boolean = false,
    customEmojiOrText: String? = null,
    showOnlineDot: Boolean = false,
    showCameraBadge: Boolean = false,
    onClick: (() -> Unit)? = null
) {
    val context = LocalContext.current
    val palette = LocalPhonogrammPalette.current
    val isOldDevice = LocalDeviceOptimizationMode.current.isOldDeviceMode
    val bgBrush = if (isBot) {
        Brush.linearGradient(listOf(Color(0xFF0C0926), Color(0xFF1E1B4B)))
    } else {
        getAvatarBrush(username)
    }

    val customBitmap = remember(customEmojiOrText) {
        if (!isBot && !customEmojiOrText.isNullOrBlank() && customEmojiOrText.length > 2) {
            PhonogrammMediaHelper.decodeAvatarBitmap(context, customEmojiOrText)
        } else {
            null
        }
    }

    val displaySymbol = when {
        isBot -> "✦"
        !customEmojiOrText.isNullOrBlank() && customEmojiOrText.length <= 2 -> customEmojiOrText
        else -> username.trim().removePrefix("@").firstOrNull()?.uppercaseChar()?.toString() ?: "?"
    }

    Box(
        modifier = modifier.size(size),
        contentAlignment = Alignment.Center
    ) {
        Box(
            modifier = Modifier
                .size(size)
                .then(
                    if (isOldDevice) Modifier else Modifier.shadow(4.dp, RoundedCornerShape(cornerRadius))
                )
                .clip(RoundedCornerShape(cornerRadius))
                .background(bgBrush)
                .border(
                    width = 1.dp,
                    color = Color.White.copy(alpha = if (isOldDevice) 0.28f else 0.18f),
                    shape = RoundedCornerShape(cornerRadius)
                )
                .then(
                    if (onClick != null) Modifier.clickable(onClick = onClick) else Modifier
                ),
            contentAlignment = Alignment.Center
        ) {
            if (isBot) {
                Image(
                    painter = painterResource(id = R.drawable.oleg_logo),
                    contentDescription = "Oleg",
                    contentScale = ContentScale.Crop,
                    modifier = Modifier.fillMaxSize()
                )
            } else if (customBitmap != null) {
                Image(
                    bitmap = customBitmap,
                    contentDescription = username,
                    contentScale = ContentScale.Crop,
                    filterQuality = FilterQuality.High,
                    modifier = Modifier.fillMaxSize()
                )
            } else {
                Text(
                    text = displaySymbol,
                    fontFamily = PlusJakartaSansFontFamily,
                    fontWeight = FontWeight.ExtraBold,
                    fontSize = fontSize,
                    color = Color.White
                )
            }
        }

        if (showOnlineDot) {
            val dotSize = (size.value * 0.27f).coerceIn(11f, 15f).dp
            Box(
                modifier = Modifier
                    .align(Alignment.BottomEnd)
                    .offset(x = 2.dp, y = 2.dp)
                    .size(dotSize)
                    .shadow(4.dp, CircleShape, spotColor = palette.online)
                    .clip(CircleShape)
                    .background(palette.online)
                    .border(2.5.dp, palette.surface, CircleShape)
            )
        }

        if (showCameraBadge) {
            Box(
                modifier = Modifier
                    .align(Alignment.BottomEnd)
                    .offset(x = 3.dp, y = 3.dp)
                    .size(34.dp)
                    .shadow(6.dp, RoundedCornerShape(12.dp))
                    .clip(RoundedCornerShape(12.dp))
                    .background(palette.primary)
                    .border(3.dp, palette.surface, RoundedCornerShape(12.dp)),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = Icons.Default.CameraAlt,
                    contentDescription = "Сменить аватар",
                    tint = Color.White,
                    modifier = Modifier.size(15.dp)
                )
            }
        }
    }
}

@Composable
fun VerifiedBadgeIcon(
    modifier: Modifier = Modifier,
    size: Dp = 16.dp
) {
    val palette = LocalPhonogrammPalette.current
    Box(
        modifier = modifier
            .size(size)
            .shadow(4.dp, CircleShape, spotColor = palette.primary)
            .clip(CircleShape)
            .background(
                Brush.linearGradient(listOf(palette.primary, palette.secondary))
            ),
        contentAlignment = Alignment.Center
    ) {
        Icon(
            imageVector = Icons.Default.Check,
            contentDescription = "Верифицирован",
            tint = Color.White,
            modifier = Modifier.size(size * 0.65f)
        )
    }
}

@Composable
fun RoleBadgePill(
    text: String,
    isCreator: Boolean,
    modifier: Modifier = Modifier
) {
    val bgBrush = if (isCreator) {
        Brush.linearGradient(listOf(Color(0xFFF43F5E), Color(0xFFE11D48)))
    } else {
        Brush.linearGradient(listOf(Color(0xFFF59E0B), Color(0xFFD97706)))
    }
    Box(
        modifier = modifier
            .clip(RoundedCornerShape(6.dp))
            .background(bgBrush)
            .padding(horizontal = 7.dp, vertical = 2.dp),
        contentAlignment = Alignment.Center
    ) {
        Text(
            text = text.uppercase(Locale.ROOT),
            fontSize = 9.5.sp,
            fontWeight = FontWeight.ExtraBold,
            color = Color.White,
            letterSpacing = 0.4.sp
        )
    }
}

@Composable
fun GiftGridCard(
    gift: GiftItem,
    onClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    val palette = LocalPhonogrammPalette.current
    val (glowColor, borderColor) = when (gift.rarity) {
        "legendary" -> Color(0x40F59E0B) to Color(0x73F59E0B)
        "epic" -> Color(0x40A855F7) to Color(0x66A855F7)
        else -> palette.primarySoft to palette.border
    }

    Box(
        modifier = modifier
            .height(118.dp)
            .shadow(4.dp, RoundedCornerShape(16.dp))
            .clip(RoundedCornerShape(16.dp))
            .background(
                Brush.radialGradient(
                    colors = listOf(glowColor, palette.surfaceElevated),
                    radius = 210f
                )
            )
            .border(1.dp, borderColor, RoundedCornerShape(16.dp))
            .clickable(onClick = onClick)
            .padding(horizontal = 8.dp, vertical = 10.dp)
    ) {
        // Sender mini badge top-left (.gift-card-sender-badge)
        val senderInitial = gift.from.trim().removePrefix("@").firstOrNull()?.uppercaseChar()?.toString() ?: "👑"
        Box(
            modifier = Modifier
                .align(Alignment.TopStart)
                .size(22.dp)
                .clip(RoundedCornerShape(8.dp))
                .background(getAvatarBrush(gift.from))
                .border(1.dp, Color.White.copy(alpha = 0.35f), RoundedCornerShape(8.dp)),
            contentAlignment = Alignment.Center
        ) {
            Text(
                text = senderInitial,
                fontSize = 10.sp,
                fontWeight = FontWeight.Bold,
                color = Color.White
            )
        }

        if (gift.hidden) {
            Box(
                modifier = Modifier
                    .align(Alignment.TopEnd)
                    .size(20.dp)
                    .clip(CircleShape)
                    .background(Color.Black.copy(alpha = 0.55f)),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = Icons.Default.VisibilityOff,
                    contentDescription = "Скрыт",
                    tint = Color(0xFFFBBF24),
                    modifier = Modifier.size(12.dp)
                )
            }
        }

        Column(
            modifier = Modifier.align(Alignment.Center),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center
        ) {
            Text(
                text = gift.icon.ifBlank { "🧸" },
                fontSize = 40.sp
            )
            Spacer(modifier = Modifier.height(6.dp))
            Text(
                text = gift.comment.ifBlank { "Подарок" },
                fontSize = 11.sp,
                fontWeight = FontWeight.SemiBold,
                color = palette.textSecondary,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis,
                textAlign = TextAlign.Center
            )
        }
    }
}

/**
 * Spatial dot-matrix + radial glow workspace background matching `#main-chat` in Phonogramm HTML:
 * `background-image: radial-gradient(circle at 80% 12%, var(--primary-soft) 0%, transparent 42%), radial-gradient(rgba(140, 150, 171, 0.08) 1px, transparent 1px); background-size: 100% 100%, 24px 24px;`
 */
@Composable
fun PhonogrammSpatialChatBackground(
    modifier: Modifier = Modifier,
    content: @Composable () -> Unit
) {
    val palette = LocalPhonogrammPalette.current
    val isOldDevice = LocalDeviceOptimizationMode.current.isOldDeviceMode
    Box(
        modifier = modifier
            .fillMaxSize()
            .background(palette.bg)
    ) {
        if (!isOldDevice) {
            Canvas(modifier = Modifier.fillMaxSize()) {
                // Top-right radial glow (80% X, 12% Y)
                val glowCenter = Offset(size.width * 0.80f, size.height * 0.12f)
                val glowRadius = (size.minDimension * 0.65f).coerceAtLeast(300f)
                drawCircle(
                    brush = Brush.radialGradient(
                        colors = listOf(palette.primarySoft, Color.Transparent),
                        center = glowCenter,
                        radius = glowRadius
                    ),
                    radius = glowRadius,
                    center = glowCenter
                )

                // 24dp x 24dp dot grid
                val stepPx = 24.dp.toPx()
                val dotRadius = 1.15.dp.toPx()
                val dotColor = Color(0xFF8C96AB).copy(alpha = if (palette.isLight) 0.14f else 0.09f)
                var x = stepPx / 2f
                while (x < size.width) {
                    var y = stepPx / 2f
                    while (y < size.height) {
                        drawCircle(
                            color = dotColor,
                            radius = dotRadius,
                            center = Offset(x, y)
                        )
                        y += stepPx
                    }
                    x += stepPx
                }
            }
        }
        content()
    }
}

/**
 * Dashed border modifier matching `.code-badge` (`border: 1.5px dashed var(--primary)`).
 */
fun Modifier.dashedRoundedBorder(
    width: Dp = 1.5.dp,
    color: Color,
    cornerRadius: Dp = 12.dp
): Modifier = this.drawBehind {
    val strokeWidthPx = width.toPx()
    val dashPx = 6.dp.toPx()
    val gapPx = 4.dp.toPx()
    drawRoundRect(
        color = color,
        style = Stroke(
            width = strokeWidthPx,
            pathEffect = PathEffect.dashPathEffect(floatArrayOf(dashPx, gapPx), 0f)
        ),
        cornerRadius = CornerRadius(cornerRadius.toPx())
    )
}

/**
 * Animated pulsing call avatar matching `.call-avatar-pulse` (`@keyframes callWave`).
 */
@Composable
fun PulsingCallAvatar(
    username: String,
    avatarUrl: String? = null,
    modifier: Modifier = Modifier
) {
    val palette = LocalPhonogrammPalette.current
    val infiniteTransition = rememberInfiniteTransition(label = "callWave")
    val wave1 by infiniteTransition.animateFloat(
        initialValue = 0f,
        targetValue = 1f,
        animationSpec = infiniteRepeatable(
            animation = tween(2200, easing = FastOutSlowInEasing),
            repeatMode = RepeatMode.Restart
        ),
        label = "wave1"
    )
    val wave2 by infiniteTransition.animateFloat(
        initialValue = 0f,
        targetValue = 1f,
        animationSpec = infiniteRepeatable(
            animation = tween(2200, delayMillis = 550, easing = FastOutSlowInEasing),
            repeatMode = RepeatMode.Restart
        ),
        label = "wave2"
    )

    Box(
        modifier = modifier.size(220.dp),
        contentAlignment = Alignment.Center
    ) {
        val baseSize = 142.dp
        val ring1Size = baseSize + (56.dp * wave1)
        val ring2Size = baseSize + (84.dp * wave2)
        Box(
            modifier = Modifier
                .size(ring2Size)
                .clip(RoundedCornerShape(56.dp))
                .background(palette.primary.copy(alpha = (1f - wave2) * 0.22f))
        )
        Box(
            modifier = Modifier
                .size(ring1Size)
                .clip(RoundedCornerShape(50.dp))
                .background(palette.primary.copy(alpha = (1f - wave1) * 0.38f))
        )
        PhonogrammAvatar(
            username = username,
            customEmojiOrText = avatarUrl,
            size = 142.dp,
            cornerRadius = 44.dp,
            fontSize = 54.sp,
            modifier = Modifier.border(
                width = 3.dp,
                color = Color.White.copy(alpha = 0.25f),
                shape = RoundedCornerShape(44.dp)
            )
        )
    }
}

@Composable
fun PhonogrammToastBanner(
    message: String?,
    onDismiss: () -> Unit,
    modifier: Modifier = Modifier
) {
    val palette = LocalPhonogrammPalette.current
    AnimatedVisibility(
        visible = message != null,
        enter = slideInVertically(initialOffsetY = { -it }) + fadeIn(),
        exit = slideOutVertically(targetOffsetY = { -it }) + fadeOut(),
        modifier = modifier
    ) {
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 20.dp, vertical = 14.dp),
            contentAlignment = Alignment.TopCenter
        ) {
            Row(
                modifier = Modifier
                    .widthIn(max = 380.dp)
                    .shadow(16.dp, RoundedCornerShape(15.dp))
                    .clip(RoundedCornerShape(15.dp))
                    .background(palette.surfaceFloating)
                    .border(1.dp, palette.borderStrong, RoundedCornerShape(15.dp))
                    .clickable(onClick = onDismiss)
                    .padding(horizontal = 18.dp, vertical = 12.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.Center
            ) {
                Text(
                    text = message ?: "",
                    style = MaterialTheme.typography.bodyMedium,
                    fontSize = 13.5.sp,
                    fontWeight = FontWeight.SemiBold,
                    color = palette.text,
                    textAlign = TextAlign.Center
                )
            }
        }
    }
}

/**
 * Interactive In-App Notification Banner displayed inside the application when a new message
 * arrives while the user is in the app (`"Новое сообщение от ***"`).
 */
@Composable
fun PhonogrammInAppNotificationBanner(
    notification: IncomingMessageNotification?,
    onOpenChat: (IncomingMessageNotification) -> Unit,
    onDismiss: () -> Unit,
    modifier: Modifier = Modifier
) {
    val palette = LocalPhonogrammPalette.current
    AnimatedVisibility(
        visible = notification != null,
        enter = slideInVertically(initialOffsetY = { -it }) + fadeIn(),
        exit = slideOutVertically(targetOffsetY = { -it }) + fadeOut(),
        modifier = modifier
    ) {
        val current = notification ?: return@AnimatedVisibility
        val cleanSender = current.senderUsername.trim().removePrefix("@").ifBlank { "пользователя" }
        val senderLabel = if (current.isSystemBot) "Oleg" else "@$cleanSender"

        Box(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 16.dp, vertical = 10.dp),
            contentAlignment = Alignment.TopCenter
        ) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .widthIn(max = 430.dp)
                    .shadow(20.dp, RoundedCornerShape(18.dp), spotColor = palette.primary)
                    .clip(RoundedCornerShape(18.dp))
                    .background(palette.surfaceElevated)
                    .border(1.5.dp, palette.primary.copy(alpha = 0.65f), RoundedCornerShape(18.dp))
                    .clickable { onOpenChat(current) }
                    .padding(horizontal = 14.dp, vertical = 12.dp)
                    .testTag("in_app_message_notification"),
                verticalAlignment = Alignment.CenterVertically
            ) {
                PhonogrammAvatar(
                    username = current.senderDisplayName.ifBlank { cleanSender },
                    customEmojiOrText = current.senderAvatarUrl,
                    size = 44.dp,
                    cornerRadius = 14.dp,
                    fontSize = 16.sp,
                    isBot = current.isSystemBot,
                    showOnlineDot = !current.isSystemBot
                )

                Spacer(modifier = Modifier.width(12.dp))

                Column(modifier = Modifier.weight(1f)) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        Box(
                            modifier = Modifier
                                .size(7.dp)
                                .clip(CircleShape)
                                .background(palette.primary)
                        )
                         Text(
                            text = if (current.isCallInvite) {
                                "📞 Входящий звонок от $senderLabel"
                            } else {
                                "Новое сообщение от $senderLabel"
                            },
                            color = palette.text,
                            fontSize = 13.5.sp,
                            fontWeight = FontWeight.ExtraBold,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis,
                            modifier = Modifier.testTag("in_app_notification_title")
                        )
                    }
                    if (current.messageText.isNotBlank()) {
                        Spacer(modifier = Modifier.height(3.dp))
                        Text(
                            text = current.messageText,
                            color = palette.textSecondary,
                            fontSize = 12.5.sp,
                            fontWeight = FontWeight.Medium,
                            maxLines = 2,
                            overflow = TextOverflow.Ellipsis,
                            modifier = Modifier.testTag("in_app_notification_body")
                        )
                    }
                }

                Spacer(modifier = Modifier.width(8.dp))

                Box(
                    modifier = Modifier
                        .clip(RoundedCornerShape(10.dp))
                        .background(palette.primarySoft)
                        .border(1.dp, palette.primary.copy(alpha = 0.35f), RoundedCornerShape(10.dp))
                        .clickable { onOpenChat(current) }
                        .padding(horizontal = 10.dp, vertical = 6.dp)
                        .testTag("in_app_notification_open_btn"),
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        text = if (current.isCallInvite) "Звонок" else "Открыть",
                        color = palette.primary,
                        fontSize = 11.5.sp,
                        fontWeight = FontWeight.Bold
                    )
                }

                Spacer(modifier = Modifier.width(6.dp))

                Box(
                    modifier = Modifier
                        .size(26.dp)
                        .clip(RoundedCornerShape(8.dp))
                        .background(palette.surfaceSubtle)
                        .clickable(onClick = onDismiss)
                        .testTag("in_app_notification_close_btn"),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = Icons.Default.Close,
                        contentDescription = "Закрыть уведомление",
                        tint = palette.textSecondary,
                        modifier = Modifier.size(14.dp)
                    )
                }
            }
        }
    }
}

/**
 * Persistent top in-app call notification banner shown when the user minimizes an active call
 * to browse chats or send messages. Tapping the banner returns to the full-screen call;
 * tapping the red button on the right hangs up and ends the call for both participants.
 */
@Composable
fun PhonogrammActiveCallTopBanner(
    visible: Boolean,
    partnerUsername: String,
    isVideo: Boolean,
    isConnected: Boolean,
    elapsedTimeText: String,
    onReturnToCall: () -> Unit,
    onHangupCall: () -> Unit,
    modifier: Modifier = Modifier
) {
    val palette = LocalPhonogrammPalette.current
    val isLegacyDevice = LocalDeviceOptimizationMode.current.isOldDeviceMode

    val pulseAlpha = if (isLegacyDevice) {
        1f
    } else {
        val infiniteTransition = rememberInfiniteTransition(label = "activeCallPulse")
        val anim by infiniteTransition.animateFloat(
            initialValue = 0.45f,
            targetValue = 1.0f,
            animationSpec = infiniteRepeatable(
                animation = tween(durationMillis = 850, easing = FastOutSlowInEasing),
                repeatMode = RepeatMode.Reverse
            ),
            label = "activeCallDotAlpha"
        )
        anim
    }

    AnimatedVisibility(
        visible = visible && partnerUsername.isNotBlank(),
        enter = fadeIn(tween(200)) + slideInVertically(tween(240)) { -it },
        exit = fadeOut(tween(160)) + slideOutVertically(tween(200)) { -it },
        modifier = modifier
    ) {
        val cleanPartner = partnerUsername.removePrefix("@")
        Box(
            modifier = Modifier
                .padding(horizontal = 12.dp, vertical = 8.dp)
                .widthIn(max = 520.dp)
                .fillMaxWidth()
                .shadow(
                    elevation = if (isLegacyDevice) 6.dp else 18.dp,
                    shape = RoundedCornerShape(20.dp),
                    spotColor = Color(0x6610B981)
                )
                .clip(RoundedCornerShape(20.dp))
                .background(
                    Brush.horizontalGradient(
                        colors = listOf(
                            Color(0xFF0F172A).copy(alpha = 0.96f),
                            Color(0xFF1E1B4B).copy(alpha = 0.96f)
                        )
                    )
                )
                .border(
                    width = 1.2.dp,
                    brush = Brush.horizontalGradient(
                        colors = listOf(
                            Color(0xFF10B981).copy(alpha = 0.7f),
                            palette.primary.copy(alpha = 0.65f)
                        )
                    ),
                    shape = RoundedCornerShape(20.dp)
                )
                .clickable(onClick = onReturnToCall)
                .padding(horizontal = 14.dp, vertical = 10.dp)
                .testTag("active_call_banner")
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically
            ) {
                // Left green live icon badge
                Box(
                    modifier = Modifier
                        .size(42.dp)
                        .clip(RoundedCornerShape(13.dp))
                        .background(Color(0xFF10B981).copy(alpha = 0.22f))
                        .border(1.dp, Color(0xFF10B981).copy(alpha = 0.55f), RoundedCornerShape(13.dp)),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = if (isVideo) Icons.Default.Videocam else Icons.Default.Call,
                        contentDescription = "Вернуться в звонок",
                        tint = Color(0xFF34D399),
                        modifier = Modifier.size(22.dp)
                    )
                }

                Spacer(modifier = Modifier.width(12.dp))

                // Center title + tap-to-return hint
                Column(modifier = Modifier.weight(1f)) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        Box(
                            modifier = Modifier
                                .size(8.dp)
                                .clip(CircleShape)
                                .background(Color(0xFF10B981).copy(alpha = pulseAlpha))
                        )
                        Text(
                            text = if (isConnected) {
                                "Звонок @$cleanPartner • $elapsedTimeText"
                            } else {
                                "Вызов @$cleanPartner..."
                            },
                            color = Color.White,
                            fontSize = 13.5.sp,
                            fontWeight = FontWeight.ExtraBold,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis,
                            modifier = Modifier.testTag("active_call_banner_title")
                        )
                    }
                    Spacer(modifier = Modifier.height(2.dp))
                    Text(
                        text = "Нажмите, чтобы вернуться в звонок",
                        color = Color(0xFFA5F3FC),
                        fontSize = 11.5.sp,
                        fontWeight = FontWeight.SemiBold,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                }

                Spacer(modifier = Modifier.width(10.dp))

                // Right red Hang-Up button (min 48dp touch target)
                Box(
                    modifier = Modifier
                        .height(48.dp)
                        .widthIn(min = 52.dp)
                        .shadow(8.dp, RoundedCornerShape(14.dp), spotColor = Color(0x80F43F5E))
                        .clip(RoundedCornerShape(14.dp))
                        .background(
                            Brush.linearGradient(
                                colors = listOf(Color(0xFFF43F5E), Color(0xFFE11D48))
                            )
                        )
                        .border(1.dp, Color.White.copy(alpha = 0.25f), RoundedCornerShape(14.dp))
                        .clickable(onClick = onHangupCall)
                        .padding(horizontal = 14.dp)
                        .testTag("active_call_banner_hangup_btn"),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = Icons.Default.CallEnd,
                        contentDescription = "Сбросить вызов",
                        tint = Color.White,
                        modifier = Modifier.size(22.dp)
                    )
                }
            }
        }
    }
}


