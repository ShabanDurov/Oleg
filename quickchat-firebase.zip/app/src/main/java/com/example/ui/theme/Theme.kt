package com.example.ui.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.ui.graphics.Color

@Composable
fun PhonogrammTheme(
    themeKey: PhonogrammThemeKey = PhonogrammThemeKey.DEFAULT,
    messageFontSizeSp: Int = 15,
    optimizationMode: DeviceOptimizationMode = DeviceOptimizationMode.NEW_DEVICES,
    content: @Composable () -> Unit
) {
    val palette = getPhonogrammPalette(themeKey)
    val colorScheme = if (palette.isLight) {
        lightColorScheme(
            primary = palette.primary,
            onPrimary = Color.White,
            primaryContainer = palette.primarySoft,
            onPrimaryContainer = palette.primary,
            secondary = palette.secondary,
            onSecondary = Color.White,
            secondaryContainer = palette.msgOutBg,
            onSecondaryContainer = Color.White,
            tertiary = palette.online,
            background = palette.bg,
            onBackground = palette.text,
            surface = palette.surface,
            onSurface = palette.text,
            surfaceVariant = palette.surfaceElevated,
            onSurfaceVariant = palette.textSecondary,
            outline = palette.borderStrong,
            error = palette.error,
            errorContainer = palette.errorSoft,
            onError = Color.White,
            onErrorContainer = palette.error
        )
    } else {
        darkColorScheme(
            primary = palette.primary,
            onPrimary = Color.White,
            primaryContainer = palette.primarySoft,
            onPrimaryContainer = palette.accent,
            secondary = palette.secondary,
            onSecondary = Color.White,
            secondaryContainer = palette.msgOutBg,
            onSecondaryContainer = Color.White,
            tertiary = palette.online,
            background = palette.bg,
            onBackground = palette.text,
            surface = palette.surface,
            onSurface = palette.text,
            surfaceVariant = palette.surfaceElevated,
            onSurfaceVariant = palette.textSecondary,
            outline = palette.borderStrong,
            error = palette.error,
            errorContainer = palette.errorSoft,
            onError = Color.White,
            onErrorContainer = Color(0xFFFCA5A5)
        )
    }

    CompositionLocalProvider(
        LocalPhonogrammPalette provides palette,
        LocalMessageFontSizeSp provides messageFontSizeSp.coerceIn(13, 20),
        LocalDeviceOptimizationMode provides optimizationMode
    ) {
        MaterialTheme(
            colorScheme = colorScheme,
            typography = Typography,
            content = content
        )
    }
}

@Composable
fun MyApplicationTheme(
    darkTheme: Boolean = true,
    content: @Composable () -> Unit
) {
    PhonogrammTheme(
        themeKey = if (darkTheme) PhonogrammThemeKey.DEFAULT else PhonogrammThemeKey.LIGHT,
        content = content
    )
}
