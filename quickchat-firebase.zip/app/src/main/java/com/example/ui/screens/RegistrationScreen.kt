package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.systemBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.focus.onFocusChanged
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.input.KeyboardCapitalization
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.foundation.Image
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.res.painterResource
import com.example.R
import com.example.ui.theme.LocalDeviceOptimizationMode
import com.example.ui.theme.LocalPhonogrammPalette

private val NICKNAME_REGEX = Regex("^[A-Za-z0-9_]{3,20}$")

private fun validateNicknameLocal(raw: String): String? {
    val trimmed = raw.trim().removePrefix("@")
    if (trimmed.isEmpty()) return "Введите ваш никнейм"
    if (trimmed.length < 3) return "Никнейм должен содержать минимум 3 символа"
    if (trimmed.length > 20) return "Никнейм не должен превышать 20 символов"
    if (!NICKNAME_REGEX.matches(trimmed)) {
        return "Разрешены только латинские буквы, цифры и подчёркивание (_)"
    }
    if (trimmed.equals("oleg", ignoreCase = true) || trimmed.equals("phonogramm", ignoreCase = true)) {
        return "Никнейм @$trimmed зарезервирован системой Oleg"
    }
    return null
}

@Composable
fun RegistrationScreen(
    currentUserId: String,
    isSubmitting: Boolean,
    errorMessage: String?,
    onNicknameClearError: () -> Unit,
    onRegisterNickname: (nickname: String, birthday: String) -> Unit,
    onSignOut: () -> Unit,
    modifier: Modifier = Modifier
) {
    val palette = LocalPhonogrammPalette.current
    val isOldDevice = LocalDeviceOptimizationMode.current.isOldDeviceMode
    var nicknameInput by rememberSaveable(currentUserId) { mutableStateOf("") }
    var birthdayInput by rememberSaveable(currentUserId) { mutableStateOf("") }
    var hasInteracted by rememberSaveable(currentUserId) { mutableStateOf(false) }
    var isNickFocused by remember { mutableStateOf(false) }
    var isBdayFocused by remember { mutableStateOf(false) }

    val localError = remember(nicknameInput, hasInteracted) {
        if (hasInteracted && nicknameInput.isNotEmpty()) {
            validateNicknameLocal(nicknameInput)
        } else {
            null
        }
    }
    val isNicknameValid = remember(nicknameInput) {
        validateNicknameLocal(nicknameInput) == null
    }
    val activeError = errorMessage ?: localError
    val canSubmit = isNicknameValid && !isSubmitting

    // #auth-modal spatial background (dual radial glow from CSS lines 1397-1402)
    Box(
        modifier = modifier
            .fillMaxSize()
            .background(palette.bg)
            .then(
                if (isOldDevice) {
                    Modifier
                } else {
                    Modifier.drawBehind {
                        drawRect(
                            brush = Brush.radialGradient(
                                colors = listOf(
                                    Color(0xFF6366F1).copy(alpha = 0.22f),
                                    Color.Transparent
                                ),
                                center = Offset(size.width * 0.2f, size.height * 0.2f),
                                radius = size.maxDimension * 0.6f
                            )
                        )
                        drawRect(
                            brush = Brush.radialGradient(
                                colors = listOf(
                                    Color(0xFF06B6D4).copy(alpha = 0.16f),
                                    Color.Transparent
                                ),
                                center = Offset(size.width * 0.8f, size.height * 0.8f),
                                radius = size.maxDimension * 0.6f
                            )
                        )
                    }
                }
            )
            .systemBarsPadding()
            .imePadding()
            .padding(horizontal = 20.dp),
        contentAlignment = Alignment.Center
    ) {
        // .auth-card (max-width: 390px, border-radius: 24px, surfaceElevated, borderStrong)
        Surface(
            modifier = Modifier
                .fillMaxWidth()
                .widthIn(max = 390.dp)
                .then(
                    if (isOldDevice) Modifier else Modifier.shadow(28.dp, RoundedCornerShape(24.dp))
                )
                .clip(RoundedCornerShape(24.dp))
                .border(1.dp, palette.borderStrong, RoundedCornerShape(24.dp)),
            color = palette.surfaceElevated,
            shape = RoundedCornerShape(24.dp)
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .verticalScroll(rememberScrollState())
                    .padding(horizontal = 28.dp, vertical = 32.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                // .auth-logo with Oleg cosmic star brand avatar
                Box(
                    modifier = Modifier
                        .size(72.dp)
                        .then(
                            if (isOldDevice) Modifier
                            else Modifier.shadow(16.dp, RoundedCornerShape(22.dp), spotColor = palette.primary)
                        )
                        .clip(RoundedCornerShape(22.dp))
                        .background(Color(0xFF0C0926))
                        .border(1.5.dp, palette.primary.copy(alpha = 0.45f), RoundedCornerShape(22.dp)),
                    contentAlignment = Alignment.Center
                ) {
                    Image(
                        painter = painterResource(id = R.drawable.oleg_logo),
                        contentDescription = "Oleg",
                        contentScale = ContentScale.Crop,
                        modifier = Modifier.fillMaxSize()
                    )
                }

                Spacer(modifier = Modifier.height(18.dp))

                Text(
                    text = "Oleg",
                    color = palette.text,
                    fontSize = 24.sp,
                    fontWeight = FontWeight.ExtraBold
                )

                Spacer(modifier = Modifier.height(6.dp))

                Text(
                    text = "Быстрый и безопасный мессенджер.\nСоздайте свой уникальный @юзернейм.",
                    color = palette.textSecondary,
                    fontSize = 13.5.sp,
                    textAlign = TextAlign.Center,
                    lineHeight = 19.sp
                )

                Spacer(modifier = Modifier.height(20.dp))

                // .auth-input for @username
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(14.dp))
                        .background(if (isNickFocused) palette.surface else palette.bg)
                        .border(
                            width = 1.dp,
                            color = when {
                                activeError != null -> palette.error
                                isNickFocused -> palette.primary
                                else -> palette.border
                            },
                            shape = RoundedCornerShape(14.dp)
                        )
                        .padding(horizontal = 16.dp, vertical = 14.dp),
                    contentAlignment = Alignment.CenterStart
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text(
                            text = "@",
                            color = palette.primary,
                            fontSize = 15.sp,
                            fontWeight = FontWeight.ExtraBold
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        Box(modifier = Modifier.weight(1f)) {
                            if (nicknameInput.isEmpty()) {
                                Text(
                                    text = "Ваш уникальный юзернейм...",
                                    color = palette.textTertiary,
                                    fontSize = 14.5.sp
                                )
                            }
                            BasicTextField(
                                value = nicknameInput,
                                onValueChange = {
                                    hasInteracted = true
                                    if (errorMessage != null) {
                                        onNicknameClearError()
                                    }
                                    nicknameInput = it
                                },
                                enabled = !isSubmitting,
                                singleLine = true,
                                textStyle = TextStyle(
                                    color = palette.text,
                                    fontSize = 14.5.sp,
                                    fontWeight = FontWeight.SemiBold
                                ),
                                cursorBrush = SolidColor(palette.primary),
                                keyboardOptions = KeyboardOptions(
                                    capitalization = KeyboardCapitalization.None,
                                    autoCorrectEnabled = false,
                                    keyboardType = KeyboardType.Ascii,
                                    imeAction = ImeAction.Next
                                ),
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .onFocusChanged { isNickFocused = it.isFocused }
                                    .testTag("nickname_input")
                            )
                        }
                    }
                }

                Spacer(modifier = Modifier.height(6.dp))

                Text(
                    text = "Латинские буквы (A–Z, a–z), цифры (0–9) и _. От 3 до 20 символов.",
                    color = palette.textSecondary,
                    fontSize = 11.5.sp,
                    modifier = Modifier.fillMaxWidth()
                )

                Spacer(modifier = Modifier.height(12.dp))

                // .auth-input for Birthday (matching HTML #auth-bday-input)
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(14.dp))
                        .background(if (isBdayFocused) palette.surface else palette.bg)
                        .border(
                            width = 1.dp,
                            color = if (isBdayFocused) palette.primary else palette.border,
                            shape = RoundedCornerShape(14.dp)
                        )
                        .padding(horizontal = 16.dp, vertical = 14.dp),
                    contentAlignment = Alignment.CenterStart
                ) {
                    if (birthdayInput.isEmpty()) {
                        Text(
                            text = "Дата рождения (напр. 15 мая 2001)...",
                            color = palette.textTertiary,
                            fontSize = 14.5.sp
                        )
                    }
                    BasicTextField(
                        value = birthdayInput,
                        onValueChange = { birthdayInput = it },
                        enabled = !isSubmitting,
                        singleLine = true,
                        textStyle = TextStyle(
                            color = palette.text,
                            fontSize = 14.5.sp
                        ),
                        cursorBrush = SolidColor(palette.primary),
                        keyboardOptions = KeyboardOptions(
                            imeAction = ImeAction.Done
                        ),
                        keyboardActions = KeyboardActions(
                            onDone = {
                                hasInteracted = true
                                if (canSubmit) {
                                    onRegisterNickname(nicknameInput.trim(), birthdayInput.trim())
                                }
                            }
                        ),
                        modifier = Modifier
                            .fillMaxWidth()
                            .onFocusChanged { isBdayFocused = it.isFocused }
                            .testTag("birthday_input")
                    )
                }

                if (!activeError.isNullOrBlank()) {
                    Spacer(modifier = Modifier.height(12.dp))
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(12.dp))
                            .background(palette.errorSoft)
                            .border(1.dp, palette.error.copy(alpha = 0.35f), RoundedCornerShape(12.dp))
                            .padding(horizontal = 14.dp, vertical = 10.dp)
                            .testTag("registration_error_text")
                    ) {
                        Text(
                            text = activeError,
                            color = palette.error,
                            fontSize = 12.5.sp,
                            fontWeight = FontWeight.SemiBold
                        )
                    }
                }

                Spacer(modifier = Modifier.height(18.dp))

                // .auth-btn ("Создать аккаунт")
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(50.dp)
                        .then(
                            if (canSubmit) {
                                Modifier.shadow(12.dp, RoundedCornerShape(14.dp), spotColor = palette.primary)
                            } else {
                                Modifier
                            }
                        )
                        .clip(RoundedCornerShape(14.dp))
                        .background(
                            brush = if (canSubmit) palette.msgOutBrush else SolidColor(palette.surfaceSubtle)
                        )
                        .clickable(enabled = canSubmit) {
                            hasInteracted = true
                            onRegisterNickname(nicknameInput.trim(), birthdayInput.trim())
                        }
                        .testTag("create_account_button"),
                    contentAlignment = Alignment.Center
                ) {
                    if (isSubmitting) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.Center
                        ) {
                            CircularProgressIndicator(
                                modifier = Modifier.size(18.dp),
                                strokeWidth = 2.dp,
                                color = Color.White
                            )
                            Spacer(modifier = Modifier.width(10.dp))
                            Text(
                                text = "Регистрация...",
                                color = Color.White,
                                fontSize = 14.5.sp,
                                fontWeight = FontWeight.Bold
                            )
                        }
                    } else {
                        Text(
                            text = "Создать аккаунт",
                            color = if (canSubmit) Color.White else palette.textTertiary,
                            fontSize = 14.5.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }
                }

                Spacer(modifier = Modifier.height(12.dp))

                Box(
                    modifier = Modifier
                        .clip(RoundedCornerShape(10.dp))
                        .clickable(enabled = !isSubmitting, onClick = onSignOut)
                        .padding(horizontal = 12.dp, vertical = 8.dp)
                        .testTag("registration_sign_out_button"),
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        text = "Сменить Google аккаунт",
                        color = palette.textSecondary,
                        fontSize = 12.5.sp,
                        fontWeight = FontWeight.SemiBold
                    )
                }
            }
        }
    }
}
