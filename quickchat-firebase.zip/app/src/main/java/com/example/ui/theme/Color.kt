package com.example.ui.theme

import androidx.compose.runtime.Immutable
import androidx.compose.runtime.staticCompositionLocalOf
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import kotlin.math.abs

// Legacy aliases used in existing screens
val ObsidianBackground = Color(0xFF090B10)
val DeepSlateSurface = Color(0xFF11151F)
val ElevatedSlateCard = Color(0xFF171C28)
val SubtleBorderSlate = Color(0xFF262E40)

val ElectricCyan = Color(0xFFA5F3FC)
val CyanContainerDark = Color(0xFF1E293B)
val OnCyanDark = Color(0xFFFFFFFF)

val VibrantIndigo = Color(0xFF6366F1)
val IndigoBubble = Color(0xFF4F46E5)
val IncomingBubble = Color(0xFF161B27)

val TextPrimaryLight = Color(0xFFF3F5F9)
val TextSecondaryMuted = Color(0xFF8C96AB)
val ErrorCrimson = Color(0xFFF43F5E)
val ErrorContainerDark = Color(0xFF3B121D)
val OnlineEmerald = Color(0xFF10B981)
val WarningAmber = Color(0xFFF59E0B)
val InfoSky = Color(0xFF0EA5E9)

enum class PhonogrammThemeKey(val id: String, val label: String, val title: String) {
    DEFAULT("default", "Night", "Obsidian Studio (Тёмная)"),
    LIGHT("light", "Daylight ☀️", "Alabaster Daylight (Светлая)"),
    AMOLED("amoled", "AMOLED", "Carbon OLED"),
    OCEAN("ocean", "Ocean", "Nordic Fjord"),
    EMERALD("emerald", "Forest", "Sage Studio"),
    AMETHYST("amethyst", "Cyber", "Velvet Iris");

    companion object {
        fun fromId(id: String?): PhonogrammThemeKey {
            return entries.firstOrNull { it.id == id } ?: DEFAULT
        }
    }
}

@Immutable
data class PhonogrammPalette(
    val key: PhonogrammThemeKey,
    val isLight: Boolean,
    val bg: Color,
    val bgElevated: Color,
    val surface: Color,
    val surfaceElevated: Color,
    val surfaceFloating: Color,
    val surfaceInput: Color,
    val surfaceSubtle: Color,
    val primary: Color,
    val primarySoft: Color,
    val secondary: Color,
    val accent: Color,
    val text: Color,
    val textSecondary: Color,
    val textTertiary: Color,
    val border: Color,
    val borderStrong: Color,
    val msgInBg: Color,
    val msgInText: Color,
    val msgInBorder: Color,
    val msgInMeta: Color,
    val msgOutBg: Color,
    val msgOutGradColors: List<Color>,
    val msgOutText: Color,
    val msgOutMeta: Color,
    val msgOutTickRead: Color,
    val online: Color,
    val offline: Color,
    val error: Color,
    val errorSoft: Color,
    val warning: Color,
    val warningSoft: Color,
    val success: Color,
    val successSoft: Color,
    val info: Color,
    val infoSoft: Color
) {
    val msgOutBrush: Brush
        get() = Brush.linearGradient(
            colors = msgOutGradColors,
            start = Offset(0f, 0f),
            end = Offset(400f, 400f)
        )

    val bgDeep: Color get() = bg
    val bgSurface: Color get() = surface
    val bgHeader: Color get() = surface
    val bgHover: Color get() = surfaceInput
    val accentPrimary: Color get() = primary
    val accentSecondary: Color get() = secondary
    val accentCyan: Color get() = info
    val statusOnline: Color get() = online
    val statusDanger: Color get() = error
    val statusWarning: Color get() = warning
    val glassBorder: Color get() = border
    val glassBorderBright: Color get() = borderStrong
    val textPrimary: Color get() = text
    val textMuted: Color get() = textTertiary
    val bubbleOutStart: Color get() = msgOutGradColors.firstOrNull() ?: msgOutBg
    val bubbleOutEnd: Color get() = msgOutGradColors.lastOrNull() ?: secondary
    val bubbleInBg: Color get() = msgInBg
}

fun getPhonogrammPalette(themeKey: PhonogrammThemeKey): PhonogrammPalette {
    return when (themeKey) {
        PhonogrammThemeKey.DEFAULT -> PhonogrammPalette(
            key = PhonogrammThemeKey.DEFAULT,
            isLight = false,
            bg = Color(0xFF090B10),
            bgElevated = Color(0xFF0D1017),
            surface = Color(0xFF11151F),
            surfaceElevated = Color(0xFF171C28),
            surfaceFloating = Color(0xEB171C28),
            surfaceInput = Color(0xFF151A26),
            surfaceSubtle = Color(0x0DFFFFFF),
            primary = Color(0xFF6366F1),
            primarySoft = Color(0x296366F1),
            secondary = Color(0xFF3B82F6),
            accent = Color(0xFF818CF8),
            text = Color(0xFFF3F5F9),
            textSecondary = Color(0xFF8C96AB),
            textTertiary = Color(0xFF5E687D),
            border = Color(0x14FFFFFF),
            borderStrong = Color(0x24FFFFFF),
            msgInBg = Color(0xFF161B27),
            msgInText = Color(0xFFF3F5F9),
            msgInBorder = Color(0x12FFFFFF),
            msgInMeta = Color(0xD98C96AB),
            msgOutBg = Color(0xFF4F46E5),
            msgOutGradColors = listOf(Color(0xFF4F46E5), Color(0xFF6366F1), Color(0xFF7C3AED)),
            msgOutText = Color.White,
            msgOutMeta = Color(0xC2FFFFFF),
            msgOutTickRead = Color(0xFFA5F3FC),
            online = Color(0xFF10B981),
            offline = Color(0xFF6E7A91),
            error = Color(0xFFF43F5E),
            errorSoft = Color(0x29F43F5E),
            warning = Color(0xFFF59E0B),
            warningSoft = Color(0x29F59E0B),
            success = Color(0xFF10B981),
            successSoft = Color(0x2910B981),
            info = Color(0xFF0EA5E9),
            infoSoft = Color(0x290EA5E9)
        )

        PhonogrammThemeKey.LIGHT -> PhonogrammPalette(
            key = PhonogrammThemeKey.LIGHT,
            isLight = true,
            bg = Color(0xFFF0F3F9),
            bgElevated = Color(0xFFE8ECF4),
            surface = Color(0xFFFFFFFF),
            surfaceElevated = Color(0xFFF8FAFD),
            surfaceFloating = Color(0xE8FFFFFF),
            surfaceInput = Color(0xFFF1F5F9),
            surfaceSubtle = Color(0x0A0F172A),
            primary = Color(0xFF4F46E5),
            primarySoft = Color(0x1F4F46E5),
            secondary = Color(0xFF2563EB),
            accent = Color(0xFF4F46E5),
            text = Color(0xFF0F172A),
            textSecondary = Color(0xFF526077),
            textTertiary = Color(0xFF8492A6),
            border = Color(0x140F172A),
            borderStrong = Color(0x240F172A),
            msgInBg = Color(0xFFFFFFFF),
            msgInText = Color(0xFF0F172A),
            msgInBorder = Color(0x160F172A),
            msgInMeta = Color(0xFF64748B),
            msgOutBg = Color(0xFF4F46E5),
            msgOutGradColors = listOf(Color(0xFF4F46E5), Color(0xFF4338CA), Color(0xFF3730A3)),
            msgOutText = Color.White,
            msgOutMeta = Color(0xD1FFFFFF),
            msgOutTickRead = Color(0xFFBAE6FD),
            online = Color(0xFF059669),
            offline = Color(0xFF7C8BA1),
            error = Color(0xFFF43F5E),
            errorSoft = Color(0x24F43F5E),
            warning = Color(0xFFD97706),
            warningSoft = Color(0x24F59E0B),
            success = Color(0xFF059669),
            successSoft = Color(0x2410B981),
            info = Color(0xFF0284C7),
            infoSoft = Color(0x240EA5E9)
        )

        PhonogrammThemeKey.AMOLED -> PhonogrammPalette(
            key = PhonogrammThemeKey.AMOLED,
            isLight = false,
            bg = Color(0xFF000000),
            bgElevated = Color(0xFF060608),
            surface = Color(0xFF0B0B0F),
            surfaceElevated = Color(0xFF13131A),
            surfaceFloating = Color(0xEB0E0E13),
            surfaceInput = Color(0xFF171720),
            surfaceSubtle = Color(0x0DFFFFFF),
            primary = Color(0xFF3B82F6),
            primarySoft = Color(0x2E3B82F6),
            secondary = Color(0xFF2563EB),
            accent = Color(0xFF60A5FA),
            text = Color(0xFFF8FAFC),
            textSecondary = Color(0xFF94A3B8),
            textTertiary = Color(0xFF64748B),
            border = Color(0x16FFFFFF),
            borderStrong = Color(0x26FFFFFF),
            msgInBg = Color(0xFF14141B),
            msgInText = Color(0xFFF8FAFC),
            msgInBorder = Color(0x14FFFFFF),
            msgInMeta = Color(0xFF94A3B8),
            msgOutBg = Color(0xFF2563EB),
            msgOutGradColors = listOf(Color(0xFF1D4ED8), Color(0xFF2563EB), Color(0xFF3B82F6)),
            msgOutText = Color.White,
            msgOutMeta = Color(0xC2FFFFFF),
            msgOutTickRead = Color(0xFFA5F3FC),
            online = Color(0xFF10B981),
            offline = Color(0xFF64748B),
            error = Color(0xFFF43F5E),
            errorSoft = Color(0x29F43F5E),
            warning = Color(0xFFF59E0B),
            warningSoft = Color(0x29F59E0B),
            success = Color(0xFF10B981),
            successSoft = Color(0x2910B981),
            info = Color(0xFF0EA5E9),
            infoSoft = Color(0x290EA5E9)
        )

        PhonogrammThemeKey.OCEAN -> PhonogrammPalette(
            key = PhonogrammThemeKey.OCEAN,
            isLight = false,
            bg = Color(0xFF06111E),
            bgElevated = Color(0xFF081728),
            surface = Color(0xFF0B1D33),
            surfaceElevated = Color(0xFF112844),
            surfaceFloating = Color(0xE00E223A),
            surfaceInput = Color(0xFF143050),
            surfaceSubtle = Color(0x0DFFFFFF),
            primary = Color(0xFF0EA5E9),
            primarySoft = Color(0x290EA5E9),
            secondary = Color(0xFF0284C7),
            accent = Color(0xFF38BDF8),
            text = Color(0xFFF0F9FF),
            textSecondary = Color(0xFF8AB4D0),
            textTertiary = Color(0xFF5882A0),
            border = Color(0x14BAE6FD),
            borderStrong = Color(0x26BAE6FD),
            msgInBg = Color(0xFF112844),
            msgInText = Color(0xFFF0F9FF),
            msgInBorder = Color(0x14BAE6FD),
            msgInMeta = Color(0xFF8AB4D0),
            msgOutBg = Color(0xFF0284C7),
            msgOutGradColors = listOf(Color(0xFF0369A1), Color(0xFF0284C7), Color(0xFF0EA5E9)),
            msgOutText = Color.White,
            msgOutMeta = Color(0xC2FFFFFF),
            msgOutTickRead = Color(0xFFA5F3FC),
            online = Color(0xFF10B981),
            offline = Color(0xFF5882A0),
            error = Color(0xFFF43F5E),
            errorSoft = Color(0x29F43F5E),
            warning = Color(0xFFF59E0B),
            warningSoft = Color(0x29F59E0B),
            success = Color(0xFF10B981),
            successSoft = Color(0x2910B981),
            info = Color(0xFF0EA5E9),
            infoSoft = Color(0x290EA5E9)
        )

        PhonogrammThemeKey.EMERALD -> PhonogrammPalette(
            key = PhonogrammThemeKey.EMERALD,
            isLight = false,
            bg = Color(0xFF07130F),
            bgElevated = Color(0xFF0A1A15),
            surface = Color(0xFF0E221B),
            surfaceElevated = Color(0xFF143026),
            surfaceFloating = Color(0xE0122A21),
            surfaceInput = Color(0xFF18382C),
            surfaceSubtle = Color(0x0DFFFFFF),
            primary = Color(0xFF10B981),
            primarySoft = Color(0x2910B981),
            secondary = Color(0xFF059669),
            accent = Color(0xFF34D399),
            text = Color(0xFFECFDF5),
            textSecondary = Color(0xFF86B5A3),
            textTertiary = Color(0xFF568574),
            border = Color(0x14A7F3D0),
            borderStrong = Color(0x26A7F3D0),
            msgInBg = Color(0xFF143026),
            msgInText = Color(0xFFECFDF5),
            msgInBorder = Color(0x14A7F3D0),
            msgInMeta = Color(0xFF86B5A3),
            msgOutBg = Color(0xFF059669),
            msgOutGradColors = listOf(Color(0xFF047857), Color(0xFF059669), Color(0xFF10B981)),
            msgOutText = Color.White,
            msgOutMeta = Color(0xC2FFFFFF),
            msgOutTickRead = Color(0xFFA7F3D0),
            online = Color(0xFF10B981),
            offline = Color(0xFF568574),
            error = Color(0xFFF43F5E),
            errorSoft = Color(0x29F43F5E),
            warning = Color(0xFFF59E0B),
            warningSoft = Color(0x29F59E0B),
            success = Color(0xFF10B981),
            successSoft = Color(0x2910B981),
            info = Color(0xFF0EA5E9),
            infoSoft = Color(0x290EA5E9)
        )

        PhonogrammThemeKey.AMETHYST -> PhonogrammPalette(
            key = PhonogrammThemeKey.AMETHYST,
            isLight = false,
            bg = Color(0xFF0F0919),
            bgElevated = Color(0xFF140D22),
            surface = Color(0xFF1A112B),
            surfaceElevated = Color(0xFF24183B),
            surfaceFloating = Color(0xE0201534),
            surfaceInput = Color(0xFF2A1C44),
            surfaceSubtle = Color(0x0DFFFFFF),
            primary = Color(0xFF8B5CF6),
            primarySoft = Color(0x2E8B5CF6),
            secondary = Color(0xFF7C3AED),
            accent = Color(0xFFA78BFA),
            text = Color(0xFFF5F3FF),
            textSecondary = Color(0xFFA396C4),
            textTertiary = Color(0xFF706291),
            border = Color(0x14DDD6FE),
            borderStrong = Color(0x26DDD6FE),
            msgInBg = Color(0xFF231739),
            msgInText = Color(0xFFF5F3FF),
            msgInBorder = Color(0x14DDD6FE),
            msgInMeta = Color(0xFFA396C4),
            msgOutBg = Color(0xFF7C3AED),
            msgOutGradColors = listOf(Color(0xFF6D28D9), Color(0xFF7C3AED), Color(0xFF9333EA)),
            msgOutText = Color.White,
            msgOutMeta = Color(0xC2FFFFFF),
            msgOutTickRead = Color(0xFFA5F3FC),
            online = Color(0xFF10B981),
            offline = Color(0xFF706291),
            error = Color(0xFFF43F5E),
            errorSoft = Color(0x29F43F5E),
            warning = Color(0xFFF59E0B),
            warningSoft = Color(0x29F59E0B),
            success = Color(0xFF10B981),
            successSoft = Color(0x2910B981),
            info = Color(0xFF0EA5E9),
            infoSoft = Color(0x290EA5E9)
        )
    }
}

private val AVATAR_GRADIENT_PAIRS = listOf(
    listOf(Color(0xFF3B82F6), Color(0xFF1D4ED8)),
    listOf(Color(0xFFEC4899), Color(0xFFBE185D)),
    listOf(Color(0xFF8B5CF6), Color(0xFF5B21B6)),
    listOf(Color(0xFF10B981), Color(0xFF047857)),
    listOf(Color(0xFFF59E0B), Color(0xFFB45309)),
    listOf(Color(0xFF06B6D4), Color(0xFF0E7490)),
    listOf(Color(0xFFEF4444), Color(0xFFB91C1C))
)

fun getAvatarGradientColors(username: String?): List<Color> {
    if (username.isNullOrBlank()) return AVATAR_GRADIENT_PAIRS[0]
    var hash = 0
    val clean = username.trim().removePrefix("@").lowercase()
    for (ch in clean) {
        hash = ch.code + ((hash shl 5) - hash)
    }
    return AVATAR_GRADIENT_PAIRS[abs(hash) % AVATAR_GRADIENT_PAIRS.size]
}

fun getAvatarBrush(username: String?): Brush {
    return Brush.linearGradient(getAvatarGradientColors(username))
}

val LocalPhonogrammPalette = staticCompositionLocalOf {
    getPhonogrammPalette(PhonogrammThemeKey.DEFAULT)
}

val LocalMessageFontSizeSp = staticCompositionLocalOf { 15 }

enum class DeviceOptimizationMode(
    val id: String,
    val title: String,
    val shortBadge: String,
    val description: String
) {
    NEW_DEVICES(
        id = "new_devices",
        title = "Новые устройства",
        shortBadge = "Новые ⚡",
        description = "Прежний интерфейс со всеми градиентами, свечениями, тенями и анимациями"
    ),
    OLD_DEVICES(
        id = "old_devices",
        title = "Старые устройства",
        shortBadge = "Старые 📱",
        description = "Оптимизированный интерфейс: защита нижней панели от системных кнопок, чёткие шрифты без слипания и облегчённая отрисовка"
    );

    val isOldDeviceMode: Boolean
        get() = this == OLD_DEVICES

    companion object {
        fun fromId(id: String?): DeviceOptimizationMode {
            return entries.firstOrNull { it.id == id } ?: NEW_DEVICES
        }
    }
}

val LocalDeviceOptimizationMode = staticCompositionLocalOf {
    DeviceOptimizationMode.NEW_DEVICES
}

