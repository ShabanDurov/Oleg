package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.safeDrawing
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.layout.windowInsetsPadding
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.GridItemSpan
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Call
import androidx.compose.material.icons.filled.CallEnd
import androidx.compose.material.icons.filled.Cameraswitch
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.ContentCopy
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Mic
import androidx.compose.material.icons.filled.MicOff
import androidx.compose.material.icons.filled.PictureInPictureAlt
import androidx.compose.material.icons.filled.Reply
import androidx.compose.material.icons.filled.Videocam
import androidx.compose.material.icons.filled.VideocamOff
import androidx.compose.material.icons.filled.Visibility
import androidx.compose.material.icons.filled.VisibilityOff
import androidx.compose.material.icons.filled.VolumeUp
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import android.Manifest
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import com.example.data.model.CallSession
import com.example.data.model.ChatMessage
import com.example.data.model.GiftItem
import com.example.data.model.UserProfile
import com.example.ui.components.GiftGridCard
import com.example.ui.components.PhonogrammAvatar
import com.example.ui.components.rememberPresenceClockMillis
import com.example.ui.components.PulsingCallAvatar
import com.example.ui.components.RoleBadgePill
import com.example.ui.components.VerifiedBadgeIcon
import com.example.ui.components.dashedRoundedBorder
import com.example.ui.theme.DeviceOptimizationMode
import com.example.ui.theme.LocalPhonogrammPalette
import com.example.ui.theme.PhonogrammThemeKey
import com.example.ui.theme.getPhonogrammPalette
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.rememberUpdatedState
import com.example.call.CallPhase
import com.example.call.CallUiModel
import com.example.call.WebRtcCallEngine
import com.example.call.WebRtcVideoSurface
import com.example.ui.theme.LocalDeviceOptimizationMode
import com.example.util.PhonogrammCameraPreview
import com.example.util.PhonogrammMediaHelper
import com.example.util.PhonogrammVoicePlayer
import kotlinx.coroutines.delay

private data class CatalogGiftDef(
    val id: String,
    val emoji: String,
    val name: String
)

private val ADMIN_GIFT_CATALOG = listOf(
    CatalogGiftDef("bear", "🧸", "Плюшевый мишка"),
    CatalogGiftDef("heart", "💝", "Золотое сердце"),
    CatalogGiftDef("rocket", "🚀", "Ракета Дурова"),
    CatalogGiftDef("diamond", "💎", "Кристалл Telegram"),
    CatalogGiftDef("crown", "👑", "Корона Императора"),
    CatalogGiftDef("star", "🌟", "Звезда Премиум"),
    CatalogGiftDef("rose", "🌹", "Алая роза"),
    CatalogGiftDef("cake", "🎂", "Праздничный торт"),
    CatalogGiftDef("trophy", "🏆", "Кубок Чемпиона"),
    CatalogGiftDef("ring", "💍", "Кольцо Всевластия")
)

@Composable
private fun PhonogrammModalCard(
    maxWidth: androidx.compose.ui.unit.Dp = 420.dp,
    onDismiss: () -> Unit,
    modifier: Modifier = Modifier,
    content: @Composable () -> Unit
) {
    val palette = LocalPhonogrammPalette.current
    val isOldDevice = LocalDeviceOptimizationMode.current.isOldDeviceMode
    Dialog(
        onDismissRequest = onDismiss,
        properties = DialogProperties(usePlatformDefaultWidth = false)
    ) {
        Box(
            modifier = Modifier
                .fillMaxSize()
                .background(Color(0xB804060E))
                .clickable(onClick = onDismiss)
                .padding(horizontal = 16.dp, vertical = 20.dp),
            contentAlignment = Alignment.Center
        ) {
            Surface(
                modifier = modifier
                    .fillMaxWidth()
                    .widthIn(max = maxWidth)
                    .then(
                        if (isOldDevice) Modifier else Modifier.shadow(28.dp, RoundedCornerShape(24.dp))
                    )
                    .clip(RoundedCornerShape(24.dp))
                    .border(1.dp, palette.borderStrong, RoundedCornerShape(24.dp))
                    .clickable(enabled = false) {},
                color = palette.surfaceElevated,
                shape = RoundedCornerShape(24.dp)
            ) {
                content()
            }
        }
    }
}

@Composable
fun PhonogrammModalInput(
    value: String,
    onValueChange: (String) -> Unit,
    placeholder: String,
    modifier: Modifier = Modifier,
    singleLine: Boolean = true
) {
    val palette = LocalPhonogrammPalette.current
    Box(
        modifier = modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(14.dp))
            .background(palette.bg)
            .border(1.dp, palette.border, RoundedCornerShape(14.dp))
            .padding(horizontal = 16.dp, vertical = 13.dp),
        contentAlignment = Alignment.CenterStart
    ) {
        if (value.isEmpty()) {
            Text(
                text = placeholder,
                color = palette.textTertiary,
                fontSize = 14.sp
            )
        }
        BasicTextField(
            value = value,
            onValueChange = onValueChange,
            singleLine = singleLine,
            textStyle = TextStyle(
                color = palette.text,
                fontSize = 14.5.sp
            ),
            cursorBrush = SolidColor(palette.primary),
            modifier = Modifier.fillMaxWidth()
        )
    }
}

@Composable
private fun ModalCloseIconBtn(
    onClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    val palette = LocalPhonogrammPalette.current
    Box(
        modifier = modifier
            .size(34.dp)
            .clip(RoundedCornerShape(10.dp))
            .background(palette.surfaceSubtle)
            .border(1.dp, palette.border, RoundedCornerShape(10.dp))
            .clickable(onClick = onClick),
        contentAlignment = Alignment.Center
    ) {
        Icon(
            imageVector = Icons.Default.Close,
            contentDescription = "Закрыть",
            tint = palette.textSecondary,
            modifier = Modifier.size(16.dp)
        )
    }
}

/**
 * 1. New Chat Modal (`#new-chat-modal` from HTML lines 1894-1906)
 */
@Composable
fun NewChatDialogModal(
    isCreating: Boolean,
    errorMessage: String?,
    onDismiss: () -> Unit,
    onConfirmNickname: (String) -> Unit
) {
    val palette = LocalPhonogrammPalette.current
    var targetNick by rememberSaveable { mutableStateOf("") }

    PhonogrammModalCard(onDismiss = onDismiss) {
        Column(modifier = Modifier.padding(24.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "Новое сообщение",
                    color = palette.text,
                    fontSize = 20.sp,
                    fontWeight = FontWeight.ExtraBold
                )
                ModalCloseIconBtn(onClick = onDismiss)
            }

            Spacer(modifier = Modifier.height(6.dp))
            Text(
                text = "Введите точный юзернейм собеседника (например: @ShabanDurov).",
                color = palette.textSecondary,
                fontSize = 13.sp,
                lineHeight = 18.sp
            )

            Spacer(modifier = Modifier.height(16.dp))

            PhonogrammModalInput(
                value = targetNick,
                onValueChange = { targetNick = it },
                placeholder = "Например: ShabanDurov",
                modifier = Modifier.testTag("new_chat_username_input")
            )

            if (!errorMessage.isNullOrBlank()) {
                Spacer(modifier = Modifier.height(10.dp))
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(12.dp))
                        .background(palette.errorSoft)
                        .border(1.dp, palette.error.copy(alpha = 0.35f), RoundedCornerShape(12.dp))
                        .padding(horizontal = 12.dp, vertical = 8.dp)
                ) {
                    Text(
                        text = errorMessage,
                        color = palette.error,
                        fontSize = 12.5.sp,
                        fontWeight = FontWeight.SemiBold
                    )
                }
            }

            Spacer(modifier = Modifier.height(18.dp))

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                Button(
                    onClick = {
                        val cleaned = targetNick.trim().removePrefix("@")
                        if (cleaned.isNotEmpty()) {
                            onConfirmNickname(cleaned)
                        }
                    },
                    enabled = !isCreating && targetNick.trim().removePrefix("@").isNotEmpty(),
                    shape = RoundedCornerShape(14.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = palette.primary),
                    modifier = Modifier
                        .weight(1f)
                        .height(46.dp)
                        .testTag("new_chat_submit_btn")
                ) {
                    if (isCreating) {
                        CircularProgressIndicator(
                            modifier = Modifier.size(18.dp),
                            strokeWidth = 2.dp,
                            color = Color.White
                        )
                    } else {
                        Text("Начать диалог", fontWeight = FontWeight.Bold, color = Color.White)
                    }
                }

                OutlinedButton(
                    onClick = onDismiss,
                    shape = RoundedCornerShape(14.dp),
                    modifier = Modifier
                        .weight(1f)
                        .height(46.dp)
                ) {
                    Text("Отмена", color = palette.text, fontWeight = FontWeight.SemiBold)
                }
            }
        }
    }
}

/**
 * 2. Edit Profile Modal (`#edit-profile-modal` from HTML lines 1909-1929)
 */
@Composable
fun EditProfileModal(
    profile: UserProfile,
    onDismiss: () -> Unit,
    onSave: (displayName: String, birthday: String, bio: String) -> Unit,
    onRequestVerification: (reason: String) -> Unit = {}
) {
    val palette = LocalPhonogrammPalette.current
    var displayName by rememberSaveable { mutableStateOf(profile.effectiveDisplayName) }
    var birthday by rememberSaveable { mutableStateOf(profile.birthday) }
    var bio by rememberSaveable { mutableStateOf(profile.bio) }
    var showVerifyReasonBox by rememberSaveable { mutableStateOf(false) }
    var verifyReason by rememberSaveable { mutableStateOf("") }
    var verifySubmitted by rememberSaveable { mutableStateOf(false) }

    PhonogrammModalCard(onDismiss = onDismiss) {
        Column(
            modifier = Modifier
                .padding(24.dp)
                .verticalScroll(rememberScrollState())
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "Редактировать профиль",
                    color = palette.text,
                    fontSize = 19.sp,
                    fontWeight = FontWeight.ExtraBold
                )
                ModalCloseIconBtn(onClick = onDismiss)
            }

            Spacer(modifier = Modifier.height(6.dp))
            Text(
                text = "Настройте публичные данные вашего аккаунта",
                color = palette.textSecondary,
                fontSize = 13.sp
            )

            Spacer(modifier = Modifier.height(16.dp))

            Text("Отображаемое имя", color = palette.textSecondary, fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
            Spacer(modifier = Modifier.height(6.dp))
            PhonogrammModalInput(
                value = displayName,
                onValueChange = { displayName = it },
                placeholder = "Отображаемое имя",
                modifier = Modifier.testTag("edit_profile_name_input")
            )

            Spacer(modifier = Modifier.height(12.dp))

            Text("Дата рождения", color = palette.textSecondary, fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
            Spacer(modifier = Modifier.height(6.dp))
            PhonogrammModalInput(
                value = birthday,
                onValueChange = { birthday = it },
                placeholder = "Например: 15 мая 2001",
                modifier = Modifier.testTag("edit_profile_birthday_input")
            )

            Spacer(modifier = Modifier.height(12.dp))

            Text("О себе (био)", color = palette.textSecondary, fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
            Spacer(modifier = Modifier.height(6.dp))
            PhonogrammModalInput(
                value = bio,
                onValueChange = { bio = it },
                placeholder = "Расскажите немного о себе...",
                modifier = Modifier.testTag("edit_profile_bio_input")
            )

            Spacer(modifier = Modifier.height(16.dp))

            // Verification badge request button from HTML line 1919
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(14.dp))
                    .background(palette.primarySoft)
                    .border(1.dp, palette.primary.copy(alpha = 0.35f), RoundedCornerShape(14.dp))
                    .clickable { showVerifyReasonBox = !showVerifyReasonBox }
                    .padding(vertical = 12.dp, horizontal = 14.dp)
                    .testTag("open_verify_request_btn"),
                contentAlignment = Alignment.Center
            ) {
                Text(
                    text = if (verifySubmitted) {
                        "✔ Заявка на галочку отправлена создателю"
                    } else {
                        "✔ Подать заявку на галочку верификации"
                    },
                    color = palette.primary,
                    fontSize = 13.sp,
                    fontWeight = FontWeight.Bold
                )
            }

            if (showVerifyReasonBox && !verifySubmitted) {
                Spacer(modifier = Modifier.height(10.dp))
                PhonogrammModalInput(
                    value = verifyReason,
                    onValueChange = { verifyReason = it },
                    placeholder = "Причина заявки (ссылки, проект)...",
                    singleLine = false,
                    modifier = Modifier.heightIn(min = 70.dp)
                )
                Spacer(modifier = Modifier.height(8.dp))
                Button(
                    onClick = {
                        val cleanReason = verifyReason.trim()
                        if (cleanReason.isNotBlank()) {
                            verifySubmitted = true
                            showVerifyReasonBox = false
                            onRequestVerification(cleanReason)
                        }
                    },
                    enabled = verifyReason.isNotBlank(),
                    shape = RoundedCornerShape(12.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = palette.primary),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Text("Отправить заявку", color = Color.White, fontWeight = FontWeight.Bold)
                }
            }

            Spacer(modifier = Modifier.height(18.dp))

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                Button(
                    onClick = { onSave(displayName, birthday, bio) },
                    shape = RoundedCornerShape(14.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = palette.primary),
                    modifier = Modifier
                        .weight(1f)
                        .height(46.dp)
                        .testTag("save_profile_btn")
                ) {
                    Text(
                        text = "Сохранить",
                        fontWeight = FontWeight.Bold,
                        color = Color.White
                    )
                }

                OutlinedButton(
                    onClick = onDismiss,
                    shape = RoundedCornerShape(14.dp),
                    modifier = Modifier
                        .weight(1f)
                        .height(46.dp)
                ) {
                    Text("Отмена", color = palette.text, fontWeight = FontWeight.SemiBold)
                }
            }
        }
    }
}

/**
 * 3. Theme Studio Modal (`#theme-modal` from HTML lines 2158-2215)
 */
@Composable
fun ThemeStudioModal(
    currentTheme: PhonogrammThemeKey,
    currentFontSizeSp: Int,
    onSelectTheme: (PhonogrammThemeKey) -> Unit,
    onChangeFontSize: (Int) -> Unit,
    onDismiss: () -> Unit
) {
    val palette = LocalPhonogrammPalette.current

    PhonogrammModalCard(maxWidth = 440.dp, onDismiss = onDismiss) {
        Column(modifier = Modifier.padding(24.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Text(
                        text = "🎨 Оформление",
                        color = palette.text,
                        fontSize = 20.sp,
                        fontWeight = FontWeight.ExtraBold
                    )
                    Spacer(modifier = Modifier.height(2.dp))
                    Text(
                        text = "Выберите тему и размер шрифта сообщений",
                        color = palette.textSecondary,
                        fontSize = 12.5.sp
                    )
                }
                ModalCloseIconBtn(onClick = onDismiss)
            }

            Spacer(modifier = Modifier.height(16.dp))

            LazyVerticalGrid(
                columns = GridCells.Fixed(2),
                horizontalArrangement = Arrangement.spacedBy(10.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .heightIn(max = 290.dp)
            ) {
                items(PhonogrammThemeKey.entries, key = { it.id }) { themeKey ->
                    val themePalette = remember(themeKey) { getPhonogrammPalette(themeKey) }
                    val isSelected = themeKey == currentTheme
                    val shape = RoundedCornerShape(16.dp)
                    Column(
                        modifier = Modifier
                            .clip(shape)
                            .background(palette.bg)
                            .border(
                                width = if (isSelected) 2.dp else 1.dp,
                                color = if (isSelected) palette.primary else palette.border,
                                shape = shape
                            )
                            .clickable { onSelectTheme(themeKey) }
                            .padding(12.dp)
                            .testTag("theme_option_${themeKey.id}")
                    ) {
                        Box(
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(50.dp)
                                .clip(RoundedCornerShape(11.dp))
                                .background(themePalette.bg)
                                .border(1.dp, themePalette.borderStrong, RoundedCornerShape(11.dp))
                                .padding(8.dp)
                        ) {
                            Box(
                                modifier = Modifier
                                    .width(42.dp)
                                    .height(11.dp)
                                    .clip(RoundedCornerShape(4.dp))
                                    .background(themePalette.msgInBg)
                                    .align(Alignment.TopStart)
                            )
                            Box(
                                modifier = Modifier
                                    .width(48.dp)
                                    .height(11.dp)
                                    .clip(RoundedCornerShape(4.dp))
                                    .background(themePalette.msgOutBrush)
                                    .align(Alignment.BottomEnd)
                            )
                        }

                        Spacer(modifier = Modifier.height(8.dp))

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = themeKey.label,
                                color = palette.text,
                                fontSize = 12.5.sp,
                                fontWeight = FontWeight.Bold,
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis,
                                modifier = Modifier.weight(1f)
                            )
                            if (isSelected) {
                                Box(
                                    modifier = Modifier
                                        .size(18.dp)
                                        .clip(CircleShape)
                                        .background(palette.primary),
                                    contentAlignment = Alignment.Center
                                ) {
                                    Icon(
                                        imageVector = Icons.Default.Check,
                                        contentDescription = null,
                                        tint = Color.White,
                                        modifier = Modifier.size(12.dp)
                                    )
                                }
                            }
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(16.dp))

            // Font size slider matching HTML #theme-modal font-size control
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(14.dp))
                    .background(palette.bg)
                    .border(1.dp, palette.border, RoundedCornerShape(14.dp))
                    .padding(horizontal = 14.dp, vertical = 10.dp)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Text(
                        text = "Размер текста сообщений",
                        color = palette.text,
                        fontSize = 13.sp,
                        fontWeight = FontWeight.Bold
                    )
                    Text(
                        text = "${currentFontSizeSp}px",
                        color = palette.primary,
                        fontSize = 13.sp,
                        fontWeight = FontWeight.ExtraBold
                    )
                }
                Slider(
                    value = currentFontSizeSp.toFloat(),
                    onValueChange = { onChangeFontSize(it.toInt()) },
                    valueRange = 13f..20f,
                    steps = 6,
                    colors = SliderDefaults.colors(
                        thumbColor = palette.primary,
                        activeTrackColor = palette.primary
                    )
                )
            }

            Spacer(modifier = Modifier.height(16.dp))

            Button(
                onClick = onDismiss,
                shape = RoundedCornerShape(14.dp),
                colors = ButtonDefaults.buttonColors(containerColor = palette.primary),
                modifier = Modifier
                    .fillMaxWidth()
                    .height(46.dp)
            ) {
                Text("Готово", fontWeight = FontWeight.Bold, color = Color.White)
            }
        }
    }
}

/**
 * 4. User Profile Sheet Modal (`#user-profile-modal` from HTML lines 2218-2303)
 */
@Composable
fun UserProfileSheetModal(
    peerProfile: UserProfile,
    onOpenChat: () -> Unit,
    onStartAudioCall: () -> Unit,
    onStartVideoCall: () -> Unit,
    onInspectGift: (GiftItem) -> Unit,
    onDismiss: () -> Unit
) {
    val palette = LocalPhonogrammPalette.current
    val clipboardManager = LocalClipboardManager.current
    val nowMillis = rememberPresenceClockMillis()
    val isPeerOnline = peerProfile.isEffectivelyOnline(nowMillis)
    val peerStatusText = peerProfile.formatPresenceStatus(nowMillis)
    var activeTab by rememberSaveable { mutableStateOf("gifts") }
    val visibleGifts = remember(peerProfile.gifts) {
        peerProfile.parsedGifts.filter { !it.hidden }
    }

    PhonogrammModalCard(maxWidth = 430.dp, onDismiss = onDismiss) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .verticalScroll(rememberScrollState())
        ) {
            // Hero section with close button and radial top glow
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(
                        Brush.verticalGradient(
                            colors = listOf(palette.primarySoft, palette.surfaceElevated)
                        )
                    )
                    .padding(top = 24.dp, bottom = 20.dp, start = 20.dp, end = 20.dp)
            ) {
                ModalCloseIconBtn(
                    onClick = onDismiss,
                    modifier = Modifier.align(Alignment.TopEnd)
                )

                Column(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    PhonogrammAvatar(
                        username = peerProfile.effectiveDisplayName,
                        customEmojiOrText = peerProfile.avatarUrl,
                        size = 88.dp,
                        cornerRadius = 28.dp,
                        fontSize = 32.sp,
                        showOnlineDot = isPeerOnline
                    )

                    Spacer(modifier = Modifier.height(12.dp))

                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        Text(
                            text = peerProfile.effectiveDisplayName,
                            color = palette.text,
                            fontSize = 20.sp,
                            fontWeight = FontWeight.ExtraBold
                        )
                        if (peerProfile.isVerified || peerProfile.isCreatorRole) {
                            VerifiedBadgeIcon(size = 18.dp)
                        }
                        if (peerProfile.isCreatorRole) {
                            RoleBadgePill(text = "СОЗДАТЕЛЬ", isCreator = true)
                        } else if (peerProfile.hasAdminPanel) {
                            RoleBadgePill(text = "АДМИН", isCreator = false)
                        }
                    }

                    Spacer(modifier = Modifier.height(4.dp))

                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        Box(
                            modifier = Modifier
                                .size(7.dp)
                                .clip(CircleShape)
                                .background(if (isPeerOnline) palette.online else palette.textTertiary)
                        )
                        Text(
                            text = peerStatusText,
                            color = if (isPeerOnline) palette.online else palette.textSecondary,
                            fontSize = 12.5.sp,
                            fontWeight = FontWeight.SemiBold
                        )
                    }

                    Spacer(modifier = Modifier.height(16.dp))

                    // 3 Quick Actions (Написать / Аудио / Видео)
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        SheetQuickActionTile(
                            icon = { Text("💬", fontSize = 18.sp) },
                            label = "Написать",
                            onClick = onOpenChat,
                            modifier = Modifier.weight(1f)
                        )
                        SheetQuickActionTile(
                            icon = {
                                Icon(
                                    imageVector = Icons.Default.Call,
                                    contentDescription = null,
                                    tint = palette.primary,
                                    modifier = Modifier.size(20.dp)
                                )
                            },
                            label = "Аудио",
                            onClick = onStartAudioCall,
                            modifier = Modifier.weight(1f)
                        )
                        SheetQuickActionTile(
                            icon = {
                                Icon(
                                    imageVector = Icons.Default.Videocam,
                                    contentDescription = null,
                                    tint = palette.primary,
                                    modifier = Modifier.size(20.dp)
                                )
                            },
                            label = "Видео",
                            onClick = onStartVideoCall,
                            modifier = Modifier.weight(1f)
                        )
                    }
                }
            }

            HorizontalDivider(color = palette.border)

            // Info details card
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(18.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(14.dp))
                        .background(palette.bg)
                        .border(1.dp, palette.border, RoundedCornerShape(14.dp))
                        .clickable {
                            clipboardManager.setText(AnnotatedString("@${peerProfile.username}"))
                        }
                        .padding(14.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column {
                        Text(
                            text = "@${peerProfile.username}",
                            color = palette.primary,
                            fontSize = 14.5.sp,
                            fontWeight = FontWeight.Bold
                        )
                        Text(
                            text = "ИМЯ ПОЛЬЗОВАТЕЛЯ (НАЖМИТЕ ДЛЯ КОПИРОВАНИЯ)",
                            color = palette.textSecondary,
                            fontSize = 10.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }
                    Icon(
                        imageVector = Icons.Default.ContentCopy,
                        contentDescription = null,
                        tint = palette.textSecondary,
                        modifier = Modifier.size(16.dp)
                    )
                }

                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(14.dp))
                        .background(palette.bg)
                        .border(1.dp, palette.border, RoundedCornerShape(14.dp))
                        .padding(14.dp)
                ) {
                    Text(
                        text = peerProfile.effectiveBio,
                        color = palette.text,
                        fontSize = 14.sp
                    )
                    Spacer(modifier = Modifier.height(2.dp))
                    Text(
                        text = "О СЕБЕ",
                        color = palette.textSecondary,
                        fontSize = 10.sp,
                        fontWeight = FontWeight.Bold
                    )
                }

                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(14.dp))
                        .background(palette.bg)
                        .border(1.dp, palette.border, RoundedCornerShape(14.dp))
                        .padding(14.dp)
                ) {
                    Text(
                        text = peerProfile.effectiveBirthday,
                        color = palette.text,
                        fontSize = 14.sp
                    )
                    Spacer(modifier = Modifier.height(2.dp))
                    Text(
                        text = "ДАТА РОЖДЕНИЯ",
                        color = palette.textSecondary,
                        fontSize = 10.sp,
                        fontWeight = FontWeight.Bold
                    )
                }

                // Tabs: Подарки / Публикации
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    val giftsSelected = activeTab == "gifts"
                    Box(
                        modifier = Modifier
                            .weight(1f)
                            .clip(RoundedCornerShape(12.dp))
                            .background(if (giftsSelected) palette.primarySoft else palette.bg)
                            .border(
                                1.dp,
                                if (giftsSelected) palette.primary else palette.border,
                                RoundedCornerShape(12.dp)
                            )
                            .clickable { activeTab = "gifts" }
                            .padding(vertical = 10.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        Text(
                            text = "🎁 Подарки (${visibleGifts.size})",
                            color = if (giftsSelected) palette.primary else palette.textSecondary,
                            fontSize = 12.5.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }

                    val postsSelected = activeTab == "posts"
                    Box(
                        modifier = Modifier
                            .weight(1f)
                            .clip(RoundedCornerShape(12.dp))
                            .background(if (postsSelected) palette.primarySoft else palette.bg)
                            .border(
                                1.dp,
                                if (postsSelected) palette.primary else palette.border,
                                RoundedCornerShape(12.dp)
                            )
                            .clickable { activeTab = "posts" }
                            .padding(vertical = 10.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        Text(
                            text = "📸 Публикации",
                            color = if (postsSelected) palette.primary else palette.textSecondary,
                            fontSize = 12.5.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }
                }

                if (activeTab == "gifts") {
                    if (visibleGifts.isEmpty()) {
                        Box(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clip(RoundedCornerShape(14.dp))
                                .background(palette.bg)
                                .border(1.dp, palette.border, RoundedCornerShape(14.dp))
                                .padding(20.dp),
                            contentAlignment = Alignment.Center
                        ) {
                            Text(
                                text = "У пользователя пока нет подарков 🎁",
                                color = palette.textSecondary,
                                fontSize = 13.sp
                            )
                        }
                    } else {
                        Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                            visibleGifts.chunked(3).forEach { rowGifts ->
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                                ) {
                                    rowGifts.forEach { gift ->
                                        GiftGridCard(
                                            gift = gift,
                                            onClick = { onInspectGift(gift) },
                                            modifier = Modifier.weight(1f)
                                        )
                                    }
                                    repeat(3 - rowGifts.size) {
                                        Spacer(modifier = Modifier.weight(1f))
                                    }
                                }
                            }
                        }
                    }
                } else {
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(14.dp))
                            .background(palette.bg)
                            .border(1.dp, palette.border, RoundedCornerShape(14.dp))
                            .padding(20.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        Text(
                            text = "Публикаций пока нет 📸",
                            color = palette.textSecondary,
                            fontSize = 13.sp
                        )
                    }
                }
            }
        }
    }
}

@Composable
private fun SheetQuickActionTile(
    icon: @Composable () -> Unit,
    label: String,
    onClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    val palette = LocalPhonogrammPalette.current
    Column(
        modifier = modifier
            .clip(RoundedCornerShape(14.dp))
            .background(palette.bg)
            .border(1.dp, palette.border, RoundedCornerShape(14.dp))
            .clickable(onClick = onClick)
            .padding(vertical = 10.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        icon()
        Spacer(modifier = Modifier.height(4.dp))
        Text(
            text = label,
            color = palette.text,
            fontSize = 12.sp,
            fontWeight = FontWeight.SemiBold
        )
    }
}

/**
 * 5. NFT Gift Detail Sheet Modal (`#gift-detail-modal` from HTML lines 2306-2363)
 */
@Composable
fun GiftDetailSheetModal(
    gift: GiftItem,
    isMyProfile: Boolean,
    onToggleHide: () -> Unit,
    onDismiss: () -> Unit
) {
    val palette = LocalPhonogrammPalette.current
    val isMythic = gift.rarity == "mythic"
    val isLegendary = gift.rarity == "legendary"

    val rarityLabel = when (gift.rarity) {
        "mythic" -> "🔥 МИФИЧЕСКИЙ АРТЕФАКТ"
        "legendary" -> "✨ ЛЕГЕНДАРНЫЙ ПОДАРОК"
        "epic" -> "💜 ЭПИЧЕСКИЙ ПОДАРОК"
        else -> "💎 КОЛЛЕКЦИОННЫЙ ПОДАРОК"
    }
    val rarityColor = when {
        isMythic -> Color(0xFFFB7185)
        isLegendary -> Color(0xFFFBBF24)
        gift.rarity == "epic" -> Color(0xFFA855F7)
        else -> Color(0xFF818CF8)
    }

    PhonogrammModalCard(maxWidth = 390.dp, onDismiss = onDismiss) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(24.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            // Showcase box (.gift-sheet-hero)
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(155.dp)
                    .clip(RoundedCornerShape(22.dp))
                    .background(
                        Brush.radialGradient(
                            colors = listOf(
                                rarityColor.copy(alpha = 0.28f),
                                palette.bg
                            )
                        )
                    )
                    .border(1.dp, rarityColor.copy(alpha = 0.45f), RoundedCornerShape(22.dp)),
                contentAlignment = Alignment.Center
            ) {
                ModalCloseIconBtn(
                    onClick = onDismiss,
                    modifier = Modifier
                        .align(Alignment.TopEnd)
                        .padding(10.dp)
                )
                Text(text = gift.icon.ifBlank { "🧸" }, fontSize = 68.sp)
            }

            Spacer(modifier = Modifier.height(14.dp))

            Surface(
                color = rarityColor.copy(alpha = 0.16f),
                shape = RoundedCornerShape(999.dp)
            ) {
                Text(
                    text = rarityLabel,
                    color = rarityColor,
                    fontSize = 10.5.sp,
                    fontWeight = FontWeight.ExtraBold,
                    modifier = Modifier.padding(horizontal = 12.dp, vertical = 5.dp)
                )
            }

            Spacer(modifier = Modifier.height(8.dp))

            Text(
                text = "Коллекционный подарок",
                color = palette.text,
                fontSize = 20.sp,
                fontWeight = FontWeight.ExtraBold
            )

            if (gift.comment.isNotBlank()) {
                Spacer(modifier = Modifier.height(6.dp))
                Text(
                    text = "«${gift.comment}»",
                    color = palette.textSecondary,
                    fontSize = 13.5.sp,
                    textAlign = TextAlign.Center
                )
            }

            Spacer(modifier = Modifier.height(18.dp))

            // Metadata table (.gift-sheet-table)
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(16.dp))
                    .background(palette.bg)
                    .border(1.dp, palette.border, RoundedCornerShape(16.dp))
                    .padding(14.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                GiftMetaRow(label = "Отправитель", value = "@${gift.from.ifBlank { "ShabanDurov" }}")
                HorizontalDivider(color = palette.border)
                GiftMetaRow(label = "Дата получения", value = gift.dateStr.ifBlank { "Сегодня" })
                HorizontalDivider(color = palette.border)
                GiftMetaRow(label = "Серийный номер", value = "#${(gift.id.hashCode().and(0x7FFFFFFF) % 9000) + 1000}")
                HorizontalDivider(color = palette.border)
                GiftMetaRow(
                    label = "Статус в профиле",
                    value = if (gift.hidden) "Скрыт из профиля" else "Виден всем"
                )
            }

            Spacer(modifier = Modifier.height(18.dp))

            if (isMyProfile) {
                OutlinedButton(
                    onClick = onToggleHide,
                    shape = RoundedCornerShape(14.dp),
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(44.dp)
                ) {
                    Icon(
                        imageVector = if (gift.hidden) Icons.Default.Visibility else Icons.Default.VisibilityOff,
                        contentDescription = null,
                        tint = palette.text,
                        modifier = Modifier.size(18.dp)
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = if (gift.hidden) "Показать в профиле" else "Скрыть из профиля",
                        color = palette.text,
                        fontWeight = FontWeight.Bold
                    )
                }
                Spacer(modifier = Modifier.height(8.dp))
            }

            Button(
                onClick = onDismiss,
                shape = RoundedCornerShape(14.dp),
                colors = ButtonDefaults.buttonColors(containerColor = palette.primary),
                modifier = Modifier
                    .fillMaxWidth()
                    .height(46.dp)
            ) {
                Text("Закрыть", fontWeight = FontWeight.Bold, color = Color.White)
            }
        }
    }
}

@Composable
private fun GiftMetaRow(label: String, value: String) {
    val palette = LocalPhonogrammPalette.current
    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(text = label, color = palette.textSecondary, fontSize = 12.5.sp)
        Text(text = value, color = palette.text, fontSize = 13.sp, fontWeight = FontWeight.Bold)
    }
}

/**
 * 6. Creator Admin Studio Modal (`#admin-modal` from HTML lines 1966-2156)
 * Full 6-box stats bar + 9-tile Admin Studio Pro grid + interactive sub-screens.
 */
@Composable
fun AdminStudioModal(
    currentUserProfile: UserProfile,
    knownPeersCount: Int,
    onlinePeersCount: Int = 0,
    lastGeneratedCode: String?,
    onSendGift: (targetNickname: String, emoji: String, rarity: String, note: String) -> Unit,
    onSetVerified: (targetNickname: String, verified: Boolean) -> Unit,
    onGenerateCode: (targetNickname: String) -> Unit,
    onDismiss: () -> Unit
) {
    val palette = LocalPhonogrammPalette.current
    var activeSubScreen by rememberSaveable { mutableStateOf("menu") }
    var targetUsername by rememberSaveable { mutableStateOf("") }
    var selectedGiftEmoji by rememberSaveable { mutableStateOf("🧸") }
    var selectedRarity by rememberSaveable { mutableStateOf("rare") }
    var giftComment by rememberSaveable { mutableStateOf("") }
    var broadcastText by rememberSaveable { mutableStateOf("") }

    PhonogrammModalCard(maxWidth = 520.dp, onDismiss = onDismiss) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .heightIn(max = 660.dp)
                .padding(22.dp)
        ) {
            // Admin Studio Header (HTML lines 1969-1981)
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    Box(
                        modifier = Modifier
                            .size(44.dp)
                            .shadow(10.dp, RoundedCornerShape(14.dp), spotColor = Color(0x59F43F5E))
                            .clip(RoundedCornerShape(14.dp))
                            .background(
                                Brush.linearGradient(
                                    colors = listOf(Color(0xFFF43F5E), Color(0xFFE11D48))
                                )
                            ),
                        contentAlignment = Alignment.Center
                    ) {
                        Text(text = "⚡", fontSize = 22.sp, color = Color.White)
                    }
                    Column {
                        Text(
                            text = "Панель создателя ⚡",
                            color = palette.text,
                            fontSize = 18.sp,
                            fontWeight = FontWeight.ExtraBold
                        )
                        Text(
                            text = "Центр управления Oleg (@${currentUserProfile.username})",
                            color = palette.textSecondary,
                            fontSize = 12.sp
                        )
                    }
                }
                ModalCloseIconBtn(onClick = onDismiss)
            }

            Spacer(modifier = Modifier.height(14.dp))

            // 6-box Admin Stats Bar (HTML lines 1984-2009: 3x2 grid)
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    AdminStatCard("👥 Контактов", (knownPeersCount + 1).toString(), palette.primary, Modifier.weight(1f))
                    AdminStatCard("🟢 Онлайн", (onlinePeersCount + 1).toString(), palette.online, Modifier.weight(1f))
                    AdminStatCard("✔ Статус", "Создатель", Color(0xFF38BDF8), Modifier.weight(1f))
                }
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    AdminStatCard("🛠 Админов", "1", Color(0xFFA855F7), Modifier.weight(1f))
                    AdminStatCard("🎁 Подарков", currentUserProfile.parsedGifts.size.toString(), Color(0xFFF59E0B), Modifier.weight(1f))
                    AdminStatCard("🔐 Защита", "Cloud", palette.online, Modifier.weight(1f))
                }
            }

            Spacer(modifier = Modifier.height(14.dp))

            if (activeSubScreen != "menu") {
                Box(
                    modifier = Modifier
                        .clip(RoundedCornerShape(10.dp))
                        .background(palette.surfaceSubtle)
                        .border(1.dp, palette.border, RoundedCornerShape(10.dp))
                        .clickable { activeSubScreen = "menu" }
                        .padding(horizontal = 12.dp, vertical = 7.dp)
                ) {
                    Text(
                        text = "← Назад в меню панели",
                        color = palette.primary,
                        fontSize = 12.5.sp,
                        fontWeight = FontWeight.Bold
                    )
                }
                Spacer(modifier = Modifier.height(10.dp))
            }

            when (activeSubScreen) {
                "menu" -> {
                    // 9-tile Admin Menu Grid (HTML lines 2012-2050)
                    LazyVerticalGrid(
                        columns = GridCells.Fixed(2),
                        horizontalArrangement = Arrangement.spacedBy(10.dp),
                        verticalArrangement = Arrangement.spacedBy(10.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        // Tile 1: Full-width span-2 primary tile
                        item(span = { GridItemSpan(2) }) {
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .clip(RoundedCornerShape(16.dp))
                                    .background(palette.primarySoft)
                                    .border(1.dp, palette.primary.copy(alpha = 0.35f), RoundedCornerShape(16.dp))
                                    .clickable { activeSubScreen = "verify" }
                                    .padding(14.dp)
                                    .testTag("admin_tile_users"),
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(12.dp)
                            ) {
                                Text(text = "👥", fontSize = 24.sp)
                                Column(modifier = Modifier.weight(1f)) {
                                    Text(
                                        text = "Управление пользователями (Галочка, Роли, Подарки)",
                                        color = palette.primary,
                                        fontSize = 13.5.sp,
                                        fontWeight = FontWeight.ExtraBold
                                    )
                                    Text(
                                        text = "Выдача галочки верификации, NFT подарков и кодов подтверждения",
                                        color = palette.textSecondary,
                                        fontSize = 11.5.sp
                                    )
                                }
                            }
                        }

                        val tiles = listOf(
                            Triple("gift", "🎁", "Выдать подарок"),
                            Triple("verify", "✔", "Галочка верификации"),
                            Triple("codes", "🔐", "Коды подтверждения"),
                            Triple("broadcast", "📢", "Системное сообщение"),
                            Triple("admin", "🛠", "Права создателя"),
                            Triple("security", "🛡", "Безопасность Firestore")
                        )

                        items(tiles, key = { it.first }) { (key, emoji, title) ->
                            Column(
                                modifier = Modifier
                                    .clip(RoundedCornerShape(16.dp))
                                    .background(palette.bg)
                                    .border(1.dp, palette.border, RoundedCornerShape(16.dp))
                                    .clickable { activeSubScreen = key }
                                    .padding(14.dp)
                                    .testTag("admin_tile_$key")
                            ) {
                                Text(text = emoji, fontSize = 24.sp)
                                Spacer(modifier = Modifier.height(8.dp))
                                Text(
                                    text = title,
                                    color = palette.text,
                                    fontSize = 13.sp,
                                    fontWeight = FontWeight.Bold
                                )
                            }
                        }
                    }
                }

                "gift" -> {
                    Column(
                        modifier = Modifier.verticalScroll(rememberScrollState()),
                        verticalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        PhonogrammModalInput(
                            value = targetUsername,
                            onValueChange = { targetUsername = it },
                            placeholder = "Юзернейм получателя (например: ShabanDurov)",
                            modifier = Modifier.testTag("admin_gift_target_input")
                        )

                        Text(
                            text = "Выберите подарок (10 NFT предметов):",
                            color = palette.textSecondary,
                            fontSize = 12.sp,
                            fontWeight = FontWeight.SemiBold
                        )

                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .horizontalScroll(rememberScrollState()),
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            ADMIN_GIFT_CATALOG.forEach { item ->
                                val selected = item.emoji == selectedGiftEmoji
                                Column(
                                    modifier = Modifier
                                        .width(86.dp)
                                        .clip(RoundedCornerShape(14.dp))
                                        .background(if (selected) palette.primarySoft else palette.bg)
                                        .border(
                                            1.5.dp,
                                            if (selected) palette.primary else palette.border,
                                            RoundedCornerShape(14.dp)
                                        )
                                        .clickable { selectedGiftEmoji = item.emoji }
                                        .padding(10.dp),
                                    horizontalAlignment = Alignment.CenterHorizontally
                                ) {
                                    Text(text = item.emoji, fontSize = 28.sp)
                                    Spacer(modifier = Modifier.height(4.dp))
                                    Text(
                                        text = item.name,
                                        color = palette.text,
                                        fontSize = 10.5.sp,
                                        fontWeight = FontWeight.Bold,
                                        maxLines = 1,
                                        overflow = TextOverflow.Ellipsis
                                    )
                                }
                            }
                        }

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            listOf(
                                "rare" to "💎 Редкий",
                                "epic" to "💜 Эпический",
                                "legendary" to "✨ Легендарный"
                            ).forEach { (rKey, rLabel) ->
                                val isSel = selectedRarity == rKey
                                Box(
                                    modifier = Modifier
                                        .weight(1f)
                                        .clip(RoundedCornerShape(10.dp))
                                        .background(if (isSel) palette.primarySoft else palette.bg)
                                        .border(
                                            1.dp,
                                            if (isSel) palette.primary else palette.border,
                                            RoundedCornerShape(10.dp)
                                        )
                                        .clickable { selectedRarity = rKey }
                                        .padding(vertical = 8.dp),
                                    contentAlignment = Alignment.Center
                                ) {
                                    Text(
                                        text = rLabel,
                                        color = if (isSel) palette.primary else palette.textSecondary,
                                        fontSize = 11.sp,
                                        fontWeight = FontWeight.Bold
                                    )
                                }
                            }
                        }

                        PhonogrammModalInput(
                            value = giftComment,
                            onValueChange = { giftComment = it },
                            placeholder = "Комментарий к подарку (необязательно)"
                        )

                        Button(
                            onClick = {
                                if (targetUsername.trim().isNotEmpty()) {
                                    onSendGift(targetUsername.trim(), selectedGiftEmoji, selectedRarity, giftComment)
                                    giftComment = ""
                                }
                            },
                            enabled = targetUsername.trim().isNotEmpty(),
                            shape = RoundedCornerShape(14.dp),
                            colors = ButtonDefaults.buttonColors(containerColor = palette.primary),
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(46.dp)
                                .testTag("admin_send_gift_btn")
                        ) {
                            Text("🎁 Отправить подарок", fontWeight = FontWeight.Bold, color = Color.White)
                        }
                    }
                }

                "verify" -> {
                    Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                        PhonogrammModalInput(
                            value = targetUsername,
                            onValueChange = { targetUsername = it },
                            placeholder = "Юзернейм аккаунта",
                            modifier = Modifier.testTag("admin_verify_target_input")
                        )
                        Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                            Button(
                                onClick = {
                                    if (targetUsername.isNotBlank()) onSetVerified(targetUsername.trim(), true)
                                },
                                shape = RoundedCornerShape(14.dp),
                                colors = ButtonDefaults.buttonColors(containerColor = palette.primary),
                                modifier = Modifier
                                    .weight(1f)
                                    .height(46.dp)
                                    .testTag("admin_grant_verify_btn")
                            ) {
                                Text("✔ Выдать галочку", fontWeight = FontWeight.Bold, color = Color.White)
                            }
                            OutlinedButton(
                                onClick = {
                                    if (targetUsername.isNotBlank()) onSetVerified(targetUsername.trim(), false)
                                },
                                shape = RoundedCornerShape(14.dp),
                                modifier = Modifier
                                    .weight(1f)
                                    .height(46.dp)
                            ) {
                                Text("Снять галочку", color = palette.text)
                            }
                        }
                    }
                }

                "codes" -> {
                    Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                        PhonogrammModalInput(
                            value = targetUsername,
                            onValueChange = { targetUsername = it },
                            placeholder = "Юзернейм получателя кода",
                            modifier = Modifier.testTag("admin_code_target_input")
                        )
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .dashedRoundedBorder(1.5.dp, palette.primary, 14.dp)
                                .clip(RoundedCornerShape(14.dp))
                                .background(palette.primarySoft)
                                .padding(horizontal = 16.dp, vertical = 12.dp),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = lastGeneratedCode ?: "------",
                                color = palette.primary,
                                fontSize = 24.sp,
                                fontWeight = FontWeight.ExtraBold,
                                fontFamily = FontFamily.Monospace,
                                letterSpacing = 4.sp
                            )
                            Text(
                                text = "Системный 6-значный код",
                                color = palette.textSecondary,
                                fontSize = 11.5.sp,
                                fontWeight = FontWeight.SemiBold
                            )
                        }
                        Button(
                            onClick = {
                                if (targetUsername.isNotBlank()) {
                                    onGenerateCode(targetUsername.trim())
                                }
                            },
                            enabled = targetUsername.isNotBlank(),
                            shape = RoundedCornerShape(14.dp),
                            colors = ButtonDefaults.buttonColors(containerColor = palette.primary),
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(46.dp)
                                .testTag("admin_generate_code_btn")
                        ) {
                            Text("🔐 Сгенерировать и отправить код", fontWeight = FontWeight.Bold, color = Color.White)
                        }
                    }
                }

                "broadcast" -> {
                    Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                        PhonogrammModalInput(
                            value = targetUsername,
                            onValueChange = { targetUsername = it },
                            placeholder = "Юзернейм получателя"
                        )
                        PhonogrammModalInput(
                            value = broadcastText,
                            onValueChange = { broadcastText = it },
                            placeholder = "Текст системного уведомления...",
                            singleLine = false,
                            modifier = Modifier.heightIn(min = 80.dp)
                        )
                        Button(
                            onClick = {
                                if (targetUsername.isNotBlank() && broadcastText.isNotBlank()) {
                                    onSendGift(targetUsername.trim(), "📣", "rare", broadcastText.trim())
                                    broadcastText = ""
                                }
                            },
                            enabled = targetUsername.isNotBlank() && broadcastText.isNotBlank(),
                            shape = RoundedCornerShape(14.dp),
                            colors = ButtonDefaults.buttonColors(containerColor = palette.primary),
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(46.dp)
                        ) {
                            Text("📢 Отправить оповещение", fontWeight = FontWeight.Bold, color = Color.White)
                        }
                    }
                }

                else -> {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(16.dp))
                            .background(palette.bg)
                            .border(1.dp, palette.border, RoundedCornerShape(16.dp))
                            .padding(16.dp),
                        verticalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Text(
                            text = "🛡 Серверная защита панели создателя",
                            color = palette.primary,
                            fontSize = 15.sp,
                            fontWeight = FontWeight.ExtraBold
                        )
                        Text(
                            text = "Доступ к панели управления защищён правилами безопасности Cloud Firestore и привязан исключительно к подтверждённому UID создателя @ShabanDurov.",
                            color = palette.textSecondary,
                            fontSize = 12.5.sp,
                            lineHeight = 18.sp
                        )
                    }
                }
            }
        }
    }
}

@Composable
private fun AdminStatCard(
    label: String,
    value: String,
    valueColor: Color,
    modifier: Modifier = Modifier
) {
    val palette = LocalPhonogrammPalette.current
    Column(
        modifier = modifier
            .clip(RoundedCornerShape(12.dp))
            .background(palette.bg)
            .border(1.dp, palette.border, RoundedCornerShape(12.dp))
            .padding(vertical = 8.dp, horizontal = 8.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Text(
            text = value,
            color = valueColor,
            fontSize = 15.sp,
            fontWeight = FontWeight.ExtraBold,
            maxLines = 1,
            overflow = TextOverflow.Ellipsis
        )
        Text(
            text = label,
            color = palette.textSecondary,
            fontSize = 10.sp,
            fontWeight = FontWeight.SemiBold,
            maxLines = 1,
            overflow = TextOverflow.Ellipsis
        )
    }
}

/**
 * 7. Full-Screen WebRTC Audio/Video Call Studio Overlay (`#call-modal`)
 * Driven by `CallUiModel` state machine and `WebRtcCallEngine` (Opus wideband audio + hardware Camera2 WebRTC video).
 */
@Composable
fun CallStudioOverlay(
    partnerUsername: String,
    callUiModel: CallUiModel,
    webRtcEngine: WebRtcCallEngine? = null,
    onMinimizeToMessenger: () -> Unit = {},
    onAcceptCall: (Boolean) -> Unit = {},
    onToggleMute: () -> Unit = {},
    onToggleSpeaker: () -> Unit = {},
    onToggleVideo: () -> Unit = {},
    onSwitchCamera: () -> Unit = {},
    onHangup: () -> Unit
) {
    val context = LocalContext.current
    val session = callUiModel.session
    val initialVideo = session?.isVideo == true
    val isIncoming = callUiModel.isIncoming
    val phase = callUiModel.phase
    val isConnected = phase == CallPhase.ACTIVE ||
        phase == CallPhase.RECONNECTING ||
        session?.status == CallSession.STATUS_ACCEPTED

    val isMuted = callUiModel.isMuted
    val isSpeakerOn = callUiModel.isSpeakerOn
    val isVideoEnabled = callUiModel.isLocalVideoEnabled
    val peerVideoEnabled = callUiModel.isRemoteVideoEnabled
    val useFrontCamera = callUiModel.useFrontCamera
    val isMinimized = callUiModel.isMinimized
    var isPipCompact by remember { mutableStateOf(false) }

    val latestOnToggleVideo by rememberUpdatedState(onToggleVideo)
    val latestOnAcceptCall by rememberUpdatedState(onAcceptCall)

    val cameraPermissionLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.RequestPermission()
    ) { granted ->
        if (granted && !isVideoEnabled) {
            latestOnToggleVideo()
        }
    }

    val acceptCallPermissionsLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.RequestMultiplePermissions()
    ) { perms ->
        val camOk = perms[Manifest.permission.CAMERA] == true ||
            PhonogrammMediaHelper.hasCameraPermission(context)
        val enableVideo = initialVideo && camOk
        latestOnAcceptCall(enableVideo)
    }

    val micPermissionLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.RequestPermission()
    ) { granted ->
        if (granted && isMuted) {
            onToggleMute()
        }
    }

    DisposableEffect(session?.sessionId) {
        PhonogrammVoicePlayer.stopPlayback()
        onDispose { }
    }

    // When minimized into the messenger, keep WebRTC session & audio routing alive in ViewModel without blocking UI
    if (isMinimized) {
        return
    }

    val formattedTime = callUiModel.formattedElapsedTime
    val showRemoteFullScreenVideo = isConnected && peerVideoEnabled

    Dialog(
        onDismissRequest = {
            onHangup()
        },
        properties = DialogProperties(usePlatformDefaultWidth = false)
    ) {
        Box(
            modifier = Modifier
                .fillMaxSize()
                .background(
                    Brush.radialGradient(
                        colors = listOf(Color(0xFF1E1B4B), Color(0xFF070A12))
                    )
                )
                .testTag("call_studio_overlay")
        ) {
            // 1. FULL-SCREEN REMOTE PEER CAMERA when the other participant turns on their camera
            if (showRemoteFullScreenVideo) {
                if (webRtcEngine != null) {
                    WebRtcVideoSurface(
                        engine = webRtcEngine,
                        isLocalPreview = false,
                        mirror = false,
                        modifier = Modifier
                            .fillMaxSize()
                            .testTag("call_remote_fullscreen_video")
                    )
                } else {
                    Box(
                        modifier = Modifier
                            .fillMaxSize()
                            .background(
                                Brush.verticalGradient(
                                    colors = listOf(Color(0xFF0F172A), Color(0xFF020617))
                                )
                            )
                            .testTag("call_remote_fullscreen_video"),
                        contentAlignment = Alignment.Center
                    ) {
                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                            PulsingCallAvatar(username = partnerUsername)
                            Spacer(modifier = Modifier.height(14.dp))
                            Text(
                                text = "Подключение видеопотока @$partnerUsername...",
                                color = Color.White.copy(alpha = 0.85f),
                                fontSize = 14.sp,
                                fontWeight = FontWeight.SemiBold
                            )
                        }
                    }
                }
            }

            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .windowInsetsPadding(WindowInsets.safeDrawing)
                    .statusBarsPadding()
                    .navigationBarsPadding()
                    .padding(horizontal = 16.dp, vertical = 14.dp)
            ) {
                // Top Bar: Left Back/Minimize arrow to return to Messenger + E2EE Badge
                Column(
                    modifier = Modifier
                        .align(Alignment.TopStart)
                        .fillMaxWidth(),
                    horizontalAlignment = Alignment.Start
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        // Top-left arrow button to minimize call into Messenger without hanging up
                        Row(
                            modifier = Modifier
                                .height(48.dp)
                                .shadow(10.dp, RoundedCornerShape(16.dp))
                                .clip(RoundedCornerShape(16.dp))
                                .background(Color.Black.copy(alpha = 0.52f))
                                .border(1.dp, Color.White.copy(alpha = 0.24f), RoundedCornerShape(16.dp))
                                .clickable { onMinimizeToMessenger() }
                                .padding(horizontal = 14.dp)
                                .testTag("call_minimize_back_btn"),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            Icon(
                                imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                                contentDescription = "Вернуться в мессенджер без сброса звонка",
                                tint = Color.White,
                                modifier = Modifier.size(20.dp)
                            )
                            Text(
                                text = "В чаты",
                                color = Color.White,
                                fontSize = 13.5.sp,
                                fontWeight = FontWeight.Bold
                            )
                        }

                        Surface(
                            color = Color.Black.copy(alpha = 0.42f),
                            shape = RoundedCornerShape(999.dp),
                            modifier = Modifier
                                .border(1.dp, Color.White.copy(alpha = 0.16f), RoundedCornerShape(999.dp))
                        ) {
                            Text(
                                text = "🔒 WebRTC DTLS-SRTP • Opus HD",
                                color = Color.White.copy(alpha = 0.92f),
                                fontSize = 11.sp,
                                fontWeight = FontWeight.SemiBold,
                                modifier = Modifier.padding(horizontal = 12.dp, vertical = 6.dp)
                            )
                        }
                    }

                    if (showRemoteFullScreenVideo) {
                        Spacer(modifier = Modifier.height(10.dp))
                        Surface(
                            color = Color.Black.copy(alpha = 0.48f),
                            shape = RoundedCornerShape(16.dp),
                            modifier = Modifier
                                .border(1.dp, Color.White.copy(alpha = 0.18f), RoundedCornerShape(16.dp))
                        ) {
                            Column(modifier = Modifier.padding(horizontal = 14.dp, vertical = 8.dp)) {
                                Text(
                                    text = "@$partnerUsername",
                                    color = Color.White,
                                    fontSize = 16.sp,
                                    fontWeight = FontWeight.ExtraBold
                                )
                                Text(
                                    text = "HD Видеозвонок • $formattedTime",
                                    color = Color(0xFFA5F3FC),
                                    fontSize = 12.5.sp,
                                    fontWeight = FontWeight.SemiBold,
                                    fontFamily = FontFamily.Monospace
                                )
                            }
                        }
                    }
                }

                // 2. SMALL MINI-WINDOW FOR MY OWN CAMERA (Top-Right corner, 3:4 proportional aspect ratio)
                if (isVideoEnabled && (!isIncoming || isConnected)) {
                    Box(
                        modifier = Modifier
                            .align(Alignment.TopEnd)
                            .padding(top = 58.dp)
                            .width(if (isPipCompact) 90.dp else 108.dp)
                            .height(if (isPipCompact) 120.dp else 144.dp)
                            .shadow(18.dp, RoundedCornerShape(18.dp))
                            .clip(RoundedCornerShape(18.dp))
                            .border(1.5.dp, Color.White.copy(alpha = 0.36f), RoundedCornerShape(18.dp))
                            .testTag("call_local_camera_preview")
                    ) {
                        if (webRtcEngine != null) {
                            WebRtcVideoSurface(
                                engine = webRtcEngine,
                                isLocalPreview = true,
                                mirror = useFrontCamera,
                                modifier = Modifier.fillMaxSize()
                            )
                        } else {
                            PhonogrammCameraPreview(
                                useFrontCamera = useFrontCamera,
                                modifier = Modifier.fillMaxSize()
                            )
                        }
                    }
                }

                // 3. Center pulsing avatar & peer details when remote peer's camera is NOT full-screen
                if (!showRemoteFullScreenVideo) {
                    Column(
                        modifier = Modifier
                            .align(Alignment.Center)
                            .padding(bottom = 44.dp),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        PulsingCallAvatar(
                            username = partnerUsername
                        )

                        Spacer(modifier = Modifier.height(16.dp))

                        Text(
                            text = "@$partnerUsername",
                            color = Color.White,
                            fontSize = 24.sp,
                            fontWeight = FontWeight.ExtraBold
                        )

                        Spacer(modifier = Modifier.height(6.dp))

                        Text(
                            text = when {
                                phase == CallPhase.RECONNECTING ->
                                    "Восстановление соединения... • $formattedTime"
                                phase == CallPhase.CONNECTING ->
                                    "Установка защищённого соединения..."
                                isConnected ->
                                    "${if (isVideoEnabled || peerVideoEnabled) "HD Видеозвонок" else "HD Аудиозвонок"} • $formattedTime"
                                isIncoming ->
                                    "📲 Входящий ${if (initialVideo) "видеозвонок" else "аудиозвонок"}..."
                                else ->
                                    "Вызов @$partnerUsername... Ожидание ответа 🔔"
                            },
                            color = Color(0xFFA5F3FC),
                            fontSize = 14.sp,
                            fontWeight = FontWeight.SemiBold,
                            fontFamily = FontFamily.Monospace,
                            textAlign = TextAlign.Center
                        )

                        Spacer(modifier = Modifier.height(8.dp))

                        Text(
                            text = when {
                                !isConnected && isIncoming -> "Нажмите «Принять», чтобы начать разговор"
                                !isConnected -> "Собеседнику отправлено уведомление о звонке"
                                callUiModel.isPeerMuted && isMuted -> "🔇 Оба микрофона выключены"
                                callUiModel.isPeerMuted -> "🔇 Собеседник выключил микрофон"
                                isMuted -> "🔇 Микрофон выключен"
                                isSpeakerOn -> "🔊 WebRTC Opus 48 кГц • Громкая связь"
                                else -> "🎤 WebRTC Opus 48 кГц • Динамик телефона"
                            },
                            color = Color.White.copy(alpha = 0.76f),
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Medium,
                            textAlign = TextAlign.Center
                        )
                    }
                }

                if (isIncoming && !isConnected) {
                    // Incoming call Accept / Decline controls elevated safely above system navigation bar
                    Row(
                        modifier = Modifier
                            .align(Alignment.BottomCenter)
                            .padding(bottom = 32.dp)
                            .fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceEvenly,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                            Box(
                                modifier = Modifier
                                    .size(68.dp)
                                    .shadow(16.dp, CircleShape, spotColor = Color(0x80F43F5E))
                                    .clip(CircleShape)
                                    .background(
                                        Brush.linearGradient(
                                            colors = listOf(Color(0xFFF43F5E), Color(0xFFE11D48))
                                        )
                                    )
                                    .clickable {
                                        onHangup()
                                    }
                                    .testTag("call_decline_btn"),
                                contentAlignment = Alignment.Center
                            ) {
                                Icon(
                                    imageVector = Icons.Default.CallEnd,
                                    contentDescription = "Отклонить звонок",
                                    tint = Color.White,
                                    modifier = Modifier.size(28.dp)
                                )
                            }
                            Spacer(modifier = Modifier.height(8.dp))
                            Text(
                                text = "Отклонить",
                                color = Color.White.copy(alpha = 0.9f),
                                fontSize = 13.sp,
                                fontWeight = FontWeight.Bold
                            )
                        }

                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                            Box(
                                modifier = Modifier
                                    .size(68.dp)
                                    .shadow(16.dp, CircleShape, spotColor = Color(0x8010B981))
                                    .clip(CircleShape)
                                    .background(
                                        Brush.linearGradient(
                                            colors = listOf(Color(0xFF10B981), Color(0xFF059669))
                                        )
                                    )
                                    .clickable {
                                        val needMic = !PhonogrammMediaHelper.hasRecordAudioPermission(context)
                                        val needCam = initialVideo && !PhonogrammMediaHelper.hasCameraPermission(context)
                                        if (needMic || needCam) {
                                            val perms = buildList {
                                                if (needMic) add(Manifest.permission.RECORD_AUDIO)
                                                if (needCam) add(Manifest.permission.CAMERA)
                                            }.toTypedArray()
                                            acceptCallPermissionsLauncher.launch(perms)
                                        } else {
                                            val enableVid = initialVideo && PhonogrammMediaHelper.hasCameraPermission(context)
                                            onAcceptCall(enableVid)
                                        }
                                    }
                                    .testTag("call_accept_btn"),
                                contentAlignment = Alignment.Center
                            ) {
                                Icon(
                                    imageVector = if (initialVideo) Icons.Default.Videocam else Icons.Default.Call,
                                    contentDescription = "Принять звонок",
                                    tint = Color.White,
                                    modifier = Modifier.size(28.dp)
                                )
                            }
                            Spacer(modifier = Modifier.height(8.dp))
                            Text(
                                text = "Принять",
                                color = Color.White.copy(alpha = 0.9f),
                                fontSize = 13.sp,
                                fontWeight = FontWeight.Bold
                            )
                        }
                    }
                } else {
                    // Compact floating bottom control dock elevated well above system navigation buttons
                    Column(
                        modifier = Modifier
                            .align(Alignment.BottomCenter)
                            .padding(bottom = 26.dp)
                            .widthIn(max = 328.dp)
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(24.dp))
                            .background(Color.Black.copy(alpha = 0.62f))
                            .border(1.dp, Color.White.copy(alpha = 0.18f), RoundedCornerShape(24.dp))
                            .padding(horizontal = 12.dp, vertical = 10.dp),
                        horizontalAlignment = Alignment.CenterHorizontally,
                        verticalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceEvenly,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            CallControlCircleBtn(
                                icon = if (isMuted) Icons.Default.MicOff else Icons.Default.Mic,
                                contentDescription = if (isMuted) "Включить микрофон" else "Выключить микрофон",
                                isActive = !isMuted,
                                isActiveOn = false,
                                testTag = "call_mute_btn",
                                onClick = {
                                    if (!PhonogrammMediaHelper.hasRecordAudioPermission(context)) {
                                        micPermissionLauncher.launch(Manifest.permission.RECORD_AUDIO)
                                    } else {
                                        onToggleMute()
                                    }
                                }
                            )
                            CallControlCircleBtn(
                                icon = Icons.Default.VolumeUp,
                                contentDescription = "Громкая связь",
                                isActive = isSpeakerOn,
                                isActiveOn = isSpeakerOn,
                                testTag = "call_speaker_btn",
                                onClick = {
                                    onToggleSpeaker()
                                }
                            )
                            CallControlCircleBtn(
                                icon = if (isVideoEnabled) Icons.Default.Videocam else Icons.Default.VideocamOff,
                                contentDescription = if (isVideoEnabled) "Выключить камеру" else "Включить камеру",
                                isActive = isVideoEnabled,
                                isActiveOn = isVideoEnabled,
                                testTag = "call_video_btn",
                                onClick = {
                                    if (isVideoEnabled) {
                                        onToggleVideo()
                                    } else if (PhonogrammMediaHelper.hasCameraPermission(context)) {
                                        onToggleVideo()
                                    } else {
                                        cameraPermissionLauncher.launch(Manifest.permission.CAMERA)
                                    }
                                }
                            )
                            CallControlCircleBtn(
                                icon = Icons.Default.Cameraswitch,
                                contentDescription = "Переключить камеру",
                                isActive = true,
                                isActiveOn = !useFrontCamera,
                                testTag = "call_switch_cam_btn",
                                onClick = {
                                    onSwitchCamera()
                                    if (!isVideoEnabled) {
                                        if (PhonogrammMediaHelper.hasCameraPermission(context)) {
                                            onToggleVideo()
                                        } else {
                                            cameraPermissionLauncher.launch(Manifest.permission.CAMERA)
                                        }
                                    }
                                }
                            )
                            CallControlCircleBtn(
                                icon = Icons.Default.PictureInPictureAlt,
                                contentDescription = "Свернуть звонок в мессенджер",
                                isActive = true,
                                isActiveOn = isPipCompact,
                                testTag = "call_pip_minimize_btn",
                                onClick = {
                                    onMinimizeToMessenger()
                                }
                            )
                        }

                        // Compact, ergonomic Red Hang-Up Pill Button (never overlaps phone navigation bar)
                        Row(
                            modifier = Modifier
                                .height(42.dp)
                                .widthIn(min = 156.dp, max = 196.dp)
                                .shadow(10.dp, RoundedCornerShape(999.dp), spotColor = Color(0x80F43F5E))
                                .clip(RoundedCornerShape(999.dp))
                                .background(
                                    Brush.linearGradient(
                                        colors = listOf(Color(0xFFF43F5E), Color(0xFFE11D48))
                                    )
                                )
                                .border(1.dp, Color.White.copy(alpha = 0.24f), RoundedCornerShape(999.dp))
                                .clickable {
                                    onHangup()
                                }
                                .padding(horizontal = 20.dp)
                                .testTag("call_hangup_btn"),
                            horizontalArrangement = Arrangement.Center,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Icon(
                                imageVector = Icons.Default.CallEnd,
                                contentDescription = "Сбросить вызов",
                                tint = Color.White,
                                modifier = Modifier.size(18.dp)
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(
                                text = "Завершить",
                                color = Color.White,
                                fontSize = 13.5.sp,
                                fontWeight = FontWeight.ExtraBold
                            )
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun CallControlCircleBtn(
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    contentDescription: String,
    isActive: Boolean,
    isActiveOn: Boolean,
    testTag: String,
    onClick: () -> Unit
) {
    val bg = when {
        isActiveOn -> Color(0xFF6366F1)
        isActive -> Color.White.copy(alpha = 0.14f)
        else -> Color(0x38F43F5E)
    }
    val borderCol = when {
        isActiveOn -> Color(0xFF818CF8)
        isActive -> Color.White.copy(alpha = 0.22f)
        else -> Color(0x66F43F5E)
    }
    Box(
        modifier = Modifier
            .size(48.dp)
            .clip(RoundedCornerShape(16.dp))
            .background(bg)
            .border(1.dp, borderCol, RoundedCornerShape(16.dp))
            .clickable(onClick = onClick)
            .testTag(testTag),
        contentAlignment = Alignment.Center
    ) {
        Icon(
            imageVector = icon,
            contentDescription = contentDescription,
            tint = Color.White,
            modifier = Modifier.size(21.dp)
        )
    }
}

/**
 * 8. Message Context Action Modal (`#msg-action-modal` from HTML lines 2366-2382)
 */
@Composable
fun MessageActionModal(
    message: ChatMessage,
    onReply: () -> Unit,
    onCopy: () -> Unit,
    onDeleteForMe: () -> Unit,
    onDeleteForAll: () -> Unit,
    onDismiss: () -> Unit
) {
    val palette = LocalPhonogrammPalette.current

    PhonogrammModalCard(maxWidth = 350.dp, onDismiss = onDismiss) {
        Column(modifier = Modifier.padding(18.dp)) {
            Text(
                text = message.text,
                color = palette.textSecondary,
                fontSize = 12.5.sp,
                maxLines = 2,
                overflow = TextOverflow.Ellipsis,
                modifier = Modifier.padding(horizontal = 8.dp, vertical = 6.dp)
            )
            HorizontalDivider(color = palette.border, modifier = Modifier.padding(vertical = 8.dp))

            MessageActionRow(
                icon = Icons.Default.Reply,
                label = "↩ Ответить",
                color = palette.text,
                onClick = onReply
            )
            MessageActionRow(
                icon = Icons.Default.ContentCopy,
                label = "📋 Скопировать текст",
                color = palette.text,
                onClick = onCopy
            )
            MessageActionRow(
                icon = Icons.Default.Delete,
                label = "🗑️ Удалить у меня",
                color = palette.text,
                onClick = onDeleteForMe
            )
            MessageActionRow(
                icon = Icons.Default.Delete,
                label = "💥 Удалить у всех",
                color = palette.error,
                onClick = onDeleteForAll
            )
        }
    }
}

@Composable
private fun MessageActionRow(
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    label: String,
    color: Color,
    onClick: () -> Unit
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(12.dp))
            .clickable(onClick = onClick)
            .padding(horizontal = 12.dp, vertical = 12.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        Icon(imageVector = icon, contentDescription = null, tint = color, modifier = Modifier.size(19.dp))
        Text(text = label, color = color, fontSize = 14.sp, fontWeight = FontWeight.SemiBold)
    }
}

/**
 * 9. Clear Chat Modal (`#clear-chat-modal` from HTML lines 2385-2398)
 */
@Composable
fun ClearChatModal(
    onClearForMe: () -> Unit,
    onClearForBoth: () -> Unit,
    onDeleteContact: () -> Unit,
    onDismiss: () -> Unit
) {
    val palette = LocalPhonogrammPalette.current
    PhonogrammModalCard(maxWidth = 380.dp, onDismiss = onDismiss) {
        Column(modifier = Modifier.padding(24.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "🧹 Управление чатом",
                    color = palette.text,
                    fontSize = 18.sp,
                    fontWeight = FontWeight.ExtraBold
                )
                ModalCloseIconBtn(onClick = onDismiss)
            }
            Spacer(modifier = Modifier.height(8.dp))
            Text(
                text = "Выберите действие для истории сообщений или контакта:",
                color = palette.textSecondary,
                fontSize = 13.sp,
                lineHeight = 18.sp
            )
            Spacer(modifier = Modifier.height(16.dp))

            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedButton(
                    onClick = onClearForMe,
                    shape = RoundedCornerShape(14.dp),
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(44.dp)
                ) {
                    Text("🧹 Очистить историю только у меня", color = palette.text, fontWeight = FontWeight.SemiBold)
                }
                Button(
                    onClick = onClearForBoth,
                    shape = RoundedCornerShape(14.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = palette.error),
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(44.dp)
                ) {
                    Text("💥 Очистить историю у обоих", fontWeight = FontWeight.Bold, color = Color.White)
                }
                OutlinedButton(
                    onClick = onDeleteContact,
                    shape = RoundedCornerShape(14.dp),
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(44.dp)
                ) {
                    Text("🗑️ Удалить контакт и чат", color = palette.error, fontWeight = FontWeight.Bold)
                }
            }
        }
    }
}

/**
 * 10. Confirm Logout Modal (`#confirm-modal` from HTML lines 1947-1963)
 */
@Composable
fun ConfirmLogoutModal(
    onConfirm: () -> Unit,
    onDismiss: () -> Unit
) {
    val palette = LocalPhonogrammPalette.current
    PhonogrammModalCard(maxWidth = 370.dp, onDismiss = onDismiss) {
        Column(modifier = Modifier.padding(24.dp)) {
            Text(
                text = "Выход из аккаунта",
                color = palette.text,
                fontSize = 18.sp,
                fontWeight = FontWeight.ExtraBold
            )
            Spacer(modifier = Modifier.height(8.dp))
            Text(
                text = "Вы действительно хотите выйти из своего аккаунта Oleg?",
                color = palette.textSecondary,
                fontSize = 13.5.sp,
                lineHeight = 19.sp
            )
            Spacer(modifier = Modifier.height(18.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                Button(
                    onClick = onConfirm,
                    shape = RoundedCornerShape(14.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = palette.error),
                    modifier = Modifier
                        .weight(1f)
                        .height(44.dp)
                        .testTag("confirm_logout_btn")
                ) {
                    Text("Выйти", fontWeight = FontWeight.Bold, color = Color.White)
                }
                OutlinedButton(
                    onClick = onDismiss,
                    shape = RoundedCornerShape(14.dp),
                    modifier = Modifier
                        .weight(1f)
                        .height(44.dp)
                ) {
                    Text("Отмена", color = palette.text)
                }
            }
        }
    }
}

/**
 * 11. Confirm Permanent Account Deletion Modal
 */
@Composable
fun ConfirmDeleteAccountModal(
    username: String,
    isDeleting: Boolean,
    onConfirmDelete: () -> Unit,
    onDismiss: () -> Unit
) {
    val palette = LocalPhonogrammPalette.current
    PhonogrammModalCard(
        maxWidth = 390.dp,
        onDismiss = { if (!isDeleting) onDismiss() }
    ) {
        Column(modifier = Modifier.padding(24.dp)) {
            Text(
                text = "🗑️ Удаление аккаунта",
                color = palette.error,
                fontSize = 18.sp,
                fontWeight = FontWeight.ExtraBold
            )
            Spacer(modifier = Modifier.height(8.dp))
            Text(
                text = "Вы действительно хотите навсегда удалить аккаунт @$username? Все ваши чаты, сообщения, подарки и никнейм будут безвозвратно удалены из базы данных.",
                color = palette.textSecondary,
                fontSize = 13.5.sp,
                lineHeight = 19.sp
            )
            Spacer(modifier = Modifier.height(18.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                Button(
                    onClick = onConfirmDelete,
                    enabled = !isDeleting,
                    shape = RoundedCornerShape(14.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = palette.error),
                    modifier = Modifier
                        .weight(1f)
                        .height(44.dp)
                        .testTag("confirm_delete_account_btn")
                ) {
                    if (isDeleting) {
                        CircularProgressIndicator(
                            color = Color.White,
                            strokeWidth = 2.dp,
                            modifier = Modifier.size(18.dp)
                        )
                    } else {
                        Text("Удалить навсегда", fontWeight = FontWeight.Bold, color = Color.White, fontSize = 13.sp)
                    }
                }
                OutlinedButton(
                    onClick = onDismiss,
                    enabled = !isDeleting,
                    shape = RoundedCornerShape(14.dp),
                    modifier = Modifier
                        .weight(1f)
                        .height(44.dp)
                ) {
                    Text("Отмена", color = palette.text)
                }
            }
        }
    }
}

/**
 * 12. Device Optimization Modal (Новые устройства vs Старые устройства)
 */
@Composable
fun OptimizationStudioModal(
    currentMode: DeviceOptimizationMode,
    onSelectMode: (DeviceOptimizationMode) -> Unit,
    onDismiss: () -> Unit
) {
    val palette = LocalPhonogrammPalette.current

    PhonogrammModalCard(maxWidth = 420.dp, onDismiss = onDismiss) {
        Column(modifier = Modifier.padding(24.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = "⚡ Оптимизация",
                        color = palette.text,
                        fontSize = 20.sp,
                        fontWeight = FontWeight.ExtraBold
                    )
                    Spacer(modifier = Modifier.height(2.dp))
                    Text(
                        text = "Выберите режим работы интерфейса под ваше устройство",
                        color = palette.textSecondary,
                        fontSize = 12.5.sp
                    )
                }
                ModalCloseIconBtn(onClick = onDismiss)
            }

            Spacer(modifier = Modifier.height(16.dp))

            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                DeviceOptimizationMode.entries.forEach { mode ->
                    val isSelected = mode == currentMode
                    val shape = RoundedCornerShape(16.dp)
                    val emojiIcon = if (mode == DeviceOptimizationMode.NEW_DEVICES) "✨" else "📱"

                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(shape)
                            .background(if (isSelected) palette.primarySoft else palette.bg)
                            .border(
                                width = if (isSelected) 2.dp else 1.dp,
                                color = if (isSelected) palette.primary else palette.border,
                                shape = shape
                            )
                            .clickable { onSelectMode(mode) }
                            .padding(14.dp)
                            .testTag("optimization_option_${mode.id}"),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        Box(
                            modifier = Modifier
                                .size(44.dp)
                                .clip(RoundedCornerShape(13.dp))
                                .background(
                                    if (isSelected) palette.primary else palette.surfaceElevated
                                )
                                .border(
                                    width = 1.dp,
                                    color = if (isSelected) Color.Transparent else palette.border,
                                    shape = RoundedCornerShape(13.dp)
                                ),
                            contentAlignment = Alignment.Center
                        ) {
                            Text(text = emojiIcon, fontSize = 20.sp)
                        }

                        Column(modifier = Modifier.weight(1f)) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text(
                                    text = mode.title,
                                    color = palette.text,
                                    fontSize = 15.sp,
                                    fontWeight = FontWeight.ExtraBold
                                )
                                if (isSelected) {
                                    Box(
                                        modifier = Modifier
                                            .clip(CircleShape)
                                            .background(palette.primary)
                                            .padding(horizontal = 8.dp, vertical = 2.dp)
                                    ) {
                                        Text(
                                            text = "Выбрано",
                                            color = Color.White,
                                            fontSize = 10.5.sp,
                                            fontWeight = FontWeight.Bold
                                        )
                                    }
                                }
                            }
                            Spacer(modifier = Modifier.height(4.dp))
                            Text(
                                text = mode.description,
                                color = palette.textSecondary,
                                fontSize = 12.sp,
                                lineHeight = 16.5.sp
                            )
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(18.dp))

            Button(
                onClick = onDismiss,
                shape = RoundedCornerShape(14.dp),
                colors = ButtonDefaults.buttonColors(containerColor = palette.primary),
                modifier = Modifier
                    .fillMaxWidth()
                    .height(46.dp)
                    .testTag("optimization_done_btn")
            ) {
                Text(
                    text = "Готово",
                    fontWeight = FontWeight.Bold,
                    color = Color.White
                )
            }
        }
    }
}

