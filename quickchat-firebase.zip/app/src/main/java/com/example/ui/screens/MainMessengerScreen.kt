package com.example.ui.screens

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.safeDrawing
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.Chat
import androidx.compose.material.icons.automirrored.filled.Logout
import androidx.compose.material.icons.automirrored.filled.Send
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.AttachFile
import androidx.compose.material.icons.filled.Bolt
import androidx.compose.material.icons.filled.CameraAlt
import androidx.compose.material.icons.filled.CardGiftcard
import androidx.compose.material.icons.filled.Clear
import androidx.compose.material.icons.filled.ContentCopy
import androidx.compose.material.icons.filled.DarkMode
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.Videocam
import androidx.compose.material.icons.filled.Language
import androidx.compose.material.icons.filled.LightMode
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.Mic
import androidx.compose.material.icons.filled.Notifications
import androidx.compose.material.icons.filled.Palette
import androidx.compose.material.icons.filled.People
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.PersonAddAlt1
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.Speed
import androidx.compose.material.icons.filled.SupportAgent
import androidx.compose.material.icons.filled.WifiOff
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.focus.onFocusChanged
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.FilterQuality
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.input.KeyboardCapitalization
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.R
import com.example.data.model.DirectChat
import com.example.data.model.GiftItem
import com.example.data.model.UserProfile
import com.example.ui.components.GiftGridCard
import com.example.ui.components.PhonogrammAvatar
import com.example.ui.components.PhonogrammSpatialChatBackground
import com.example.ui.components.RoleBadgePill
import com.example.ui.components.VerifiedBadgeIcon
import com.example.ui.components.rememberPresenceClockMillis
import com.example.ui.theme.DeviceOptimizationMode
import com.example.ui.theme.JetBrainsMonoFontFamily
import com.example.ui.theme.LocalDeviceOptimizationMode
import com.example.ui.theme.LocalPhonogrammPalette
import com.example.ui.theme.PhonogrammThemeKey
import com.example.ui.theme.PlusJakartaSansFontFamily
import com.example.ui.theme.getAvatarBrush
import com.example.ui.viewmodel.ChatFolderFilter
import com.example.ui.viewmodel.PhonogrammTab
import com.example.ui.viewmodel.UiState
import com.example.ui.viewmodel.UserSearchState
import com.example.util.PhonogrammMediaHelper
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@Composable
fun MainMessengerScreen(
    currentUserProfile: UserProfile,
    isVerifiedAdmin: Boolean = false,
    currentTab: PhonogrammTab,
    folderFilter: ChatFolderFilter,
    chatsState: UiState<List<DirectChat>>,
    contactsList: List<UserProfile>,
    searchState: UserSearchState,
    isOnline: Boolean,
    currentThemeKey: PhonogrammThemeKey,
    currentOptimizationMode: DeviceOptimizationMode = LocalDeviceOptimizationMode.current,
    onSelectTab: (PhonogrammTab) -> Unit,
    onSelectFolderFilter: (ChatFolderFilter) -> Unit,
    onToggleQuickTheme: () -> Unit,
    onOpenNewChatModal: () -> Unit,
    onOpenEditProfileModal: () -> Unit,
    onOpenThemeStudioModal: () -> Unit,
    onOpenOptimizationModal: () -> Unit = {},
    onOpenAdminStudioModal: () -> Unit,
    onOpenGiftDetail: (GiftItem, Boolean) -> Unit,
    onOpenUserProfileModal: (String) -> Unit,
    onOpenSystemBotChat: () -> Unit,
    onOpenDirectChat: (DirectChat) -> Unit,
    onStartChatByNickname: (String, () -> Unit) -> Unit,
    onSearchNickname: (String) -> Unit,
    onClearSearch: () -> Unit,
    onAvatarPicked: (String) -> Unit,
    onShowToast: (String) -> Unit,
    onRequestLogout: () -> Unit,
    onRequestDeleteAccount: () -> Unit = onRequestLogout
) {
    val palette = LocalPhonogrammPalette.current
    val isOldDeviceMode = currentOptimizationMode.isOldDeviceMode
    var searchQuery by remember { mutableStateOf("") }
    var contactFilter by remember { mutableStateOf("") }

    if (currentTab != PhonogrammTab.CHATS) {
        BackHandler {
            onSelectTab(PhonogrammTab.CHATS)
        }
    }

    val chatsBadgeCount = remember(currentUserProfile.parsedSystemMessages) {
        currentUserProfile.parsedSystemMessages.size.coerceAtMost(99)
    }

    BoxWithConstraints(modifier = Modifier.fillMaxSize()) {
        val isDesktopLayout = maxWidth >= 720.dp

        if (isDesktopLayout) {
            // @media (min-width: 769px): Desktop Left Navigation Rail + Sidebar Master List + Main Chat Workspace
            Surface(
                modifier = Modifier.fillMaxSize(),
                color = palette.bg
            ) {
                Row(modifier = Modifier.fillMaxSize()) {
                    PhonogrammDesktopNavRail(
                        currentTab = currentTab,
                        currentUserProfile = currentUserProfile,
                        chatsBadgeCount = chatsBadgeCount,
                        onSelectTab = onSelectTab
                    )

                    Box(
                        modifier = Modifier
                            .width(380.dp)
                            .fillMaxHeight()
                            .background(palette.surface)
                    ) {
                        Column(modifier = Modifier.fillMaxSize()) {
                            SidebarActiveTabContent(
                                currentTab = currentTab,
                                currentUserProfile = currentUserProfile,
                                isVerifiedAdmin = isVerifiedAdmin,
                                folderFilter = folderFilter,
                                chatsState = chatsState,
                                contactsList = contactsList,
                                searchState = searchState,
                                searchQuery = searchQuery,
                                contactFilter = contactFilter,
                                isOnline = isOnline,
                                currentThemeKey = currentThemeKey,
                                currentOptimizationMode = currentOptimizationMode,
                                onSearchQueryChange = { q ->
                                    searchQuery = q
                                    val clean = q.trim().removePrefix("@")
                                    if (clean.length >= 3) onSearchNickname(clean) else onClearSearch()
                                },
                                onContactFilterChange = { contactFilter = it },
                                onSelectTab = onSelectTab,
                                onSelectFolderFilter = onSelectFolderFilter,
                                onToggleQuickTheme = onToggleQuickTheme,
                                onOpenNewChatModal = onOpenNewChatModal,
                                onOpenEditProfileModal = onOpenEditProfileModal,
                                onOpenThemeStudioModal = onOpenThemeStudioModal,
                                onOpenOptimizationModal = onOpenOptimizationModal,
                                onOpenAdminStudioModal = onOpenAdminStudioModal,
                                onOpenGiftDetail = onOpenGiftDetail,
                                onOpenUserProfileModal = onOpenUserProfileModal,
                                onOpenSystemBotChat = onOpenSystemBotChat,
                                onOpenDirectChat = onOpenDirectChat,
                                onStartChatByNickname = { nick ->
                                    onStartChatByNickname(nick) {
                                        searchQuery = ""
                                        onClearSearch()
                                    }
                                },
                                onAvatarPicked = onAvatarPicked,
                                onShowToast = onShowToast,
                                onRequestLogout = onRequestLogout,
                                onRequestDeleteAccount = onRequestDeleteAccount
                            )
                        }
                        Box(
                            modifier = Modifier
                                .align(Alignment.CenterEnd)
                                .width(1.dp)
                                .fillMaxHeight()
                                .background(palette.border)
                        )
                    }

                    // Right #main-chat empty state workspace matching HTML
                    DesktopEmptyChatWorkspace(
                        modifier = Modifier
                            .weight(1f)
                            .fillMaxHeight(),
                        onOpenNewChatModal = onOpenNewChatModal
                    )
                }
            }
        } else {
            // Mobile layout (#sidebar full width + floating #bottom-nav-bar dock + .fab-new-chat)
            Scaffold(
                modifier = Modifier.fillMaxSize(),
                containerColor = palette.surface,
                contentWindowInsets = WindowInsets.safeDrawing,
                bottomBar = {
                    PhonogrammBottomNavBar(
                        currentTab = currentTab,
                        currentUserProfile = currentUserProfile,
                        chatsBadgeCount = chatsBadgeCount,
                        onSelectTab = onSelectTab
                    )
                }
            ) { innerPadding ->
                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(innerPadding)
                        .background(palette.surface)
                ) {
                    Column(modifier = Modifier.fillMaxSize()) {
                        SidebarActiveTabContent(
                            currentTab = currentTab,
                            currentUserProfile = currentUserProfile,
                            isVerifiedAdmin = isVerifiedAdmin,
                            folderFilter = folderFilter,
                            chatsState = chatsState,
                            contactsList = contactsList,
                            searchState = searchState,
                            searchQuery = searchQuery,
                            contactFilter = contactFilter,
                            isOnline = isOnline,
                            currentThemeKey = currentThemeKey,
                            currentOptimizationMode = currentOptimizationMode,
                            onSearchQueryChange = { q ->
                                searchQuery = q
                                val clean = q.trim().removePrefix("@")
                                if (clean.length >= 3) onSearchNickname(clean) else onClearSearch()
                            },
                            onContactFilterChange = { contactFilter = it },
                            onSelectTab = onSelectTab,
                            onSelectFolderFilter = onSelectFolderFilter,
                            onToggleQuickTheme = onToggleQuickTheme,
                            onOpenNewChatModal = onOpenNewChatModal,
                            onOpenEditProfileModal = onOpenEditProfileModal,
                            onOpenThemeStudioModal = onOpenThemeStudioModal,
                            onOpenOptimizationModal = onOpenOptimizationModal,
                            onOpenAdminStudioModal = onOpenAdminStudioModal,
                            onOpenGiftDetail = onOpenGiftDetail,
                            onOpenUserProfileModal = onOpenUserProfileModal,
                            onOpenSystemBotChat = onOpenSystemBotChat,
                            onOpenDirectChat = onOpenDirectChat,
                            onStartChatByNickname = { nick ->
                                onStartChatByNickname(nick) {
                                    searchQuery = ""
                                    onClearSearch()
                                }
                            },
                            onAvatarPicked = onAvatarPicked,
                            onShowToast = onShowToast,
                            onRequestLogout = onRequestLogout,
                            onRequestDeleteAccount = onRequestDeleteAccount
                        )
                    }

                    // .fab-new-chat
                    if (currentTab == PhonogrammTab.CHATS) {
                        Box(
                            modifier = Modifier
                                .align(Alignment.BottomEnd)
                                .padding(end = 18.dp, bottom = 20.dp)
                                .size(54.dp)
                                .then(
                                    if (isOldDeviceMode) Modifier
                                    else Modifier.shadow(18.dp, RoundedCornerShape(18.dp), spotColor = palette.primary)
                                )
                                .clip(RoundedCornerShape(18.dp))
                                .background(palette.msgOutBrush)
                                .border(1.dp, Color.White.copy(alpha = 0.22f), RoundedCornerShape(18.dp))
                                .clickable(onClick = onOpenNewChatModal)
                                .testTag("new_chat_fab"),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(
                                imageVector = Icons.Default.Add,
                                contentDescription = "Новый диалог",
                                tint = Color.White,
                                modifier = Modifier.size(24.dp)
                            )
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun SidebarActiveTabContent(
    currentTab: PhonogrammTab,
    currentUserProfile: UserProfile,
    isVerifiedAdmin: Boolean,
    folderFilter: ChatFolderFilter,
    chatsState: UiState<List<DirectChat>>,
    contactsList: List<UserProfile>,
    searchState: UserSearchState,
    searchQuery: String,
    contactFilter: String,
    isOnline: Boolean,
    currentThemeKey: PhonogrammThemeKey,
    currentOptimizationMode: DeviceOptimizationMode,
    onSearchQueryChange: (String) -> Unit,
    onContactFilterChange: (String) -> Unit,
    onSelectTab: (PhonogrammTab) -> Unit,
    onSelectFolderFilter: (ChatFolderFilter) -> Unit,
    onToggleQuickTheme: () -> Unit,
    onOpenNewChatModal: () -> Unit,
    onOpenEditProfileModal: () -> Unit,
    onOpenThemeStudioModal: () -> Unit,
    onOpenOptimizationModal: () -> Unit,
    onOpenAdminStudioModal: () -> Unit,
    onOpenGiftDetail: (GiftItem, Boolean) -> Unit,
    onOpenUserProfileModal: (String) -> Unit,
    onOpenSystemBotChat: () -> Unit,
    onOpenDirectChat: (DirectChat) -> Unit,
    onStartChatByNickname: (String) -> Unit,
    onAvatarPicked: (String) -> Unit,
    onShowToast: (String) -> Unit,
    onRequestLogout: () -> Unit,
    onRequestDeleteAccount: () -> Unit
) {
    val palette = LocalPhonogrammPalette.current

    AnimatedVisibility(visible = !isOnline) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .background(palette.warningSoft)
                .padding(horizontal = 16.dp, vertical = 8.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Icon(
                imageVector = Icons.Default.WifiOff,
                contentDescription = null,
                tint = palette.warning,
                modifier = Modifier.size(16.dp)
            )
            Spacer(modifier = Modifier.width(8.dp))
            Text(
                text = "Офлайн-режим: синхронизация через Cloud Firestore восстановится автоматически",
                color = palette.text,
                fontSize = 12.sp
            )
        }
    }

    when (currentTab) {
        PhonogrammTab.CHATS -> {
            ChatsTabView(
                currentUserProfile = currentUserProfile,
                folderFilter = folderFilter,
                chatsState = chatsState,
                contactsList = contactsList,
                searchState = searchState,
                searchQuery = searchQuery,
                currentThemeKey = currentThemeKey,
                onSearchQueryChange = onSearchQueryChange,
                onSelectFolderFilter = onSelectFolderFilter,
                onToggleQuickTheme = onToggleQuickTheme,
                onOpenNewChatModal = onOpenNewChatModal,
                onOpenSystemBotChat = onOpenSystemBotChat,
                onOpenDirectChat = onOpenDirectChat,
                onOpenUserProfileModal = onOpenUserProfileModal,
                onStartChatByNickname = onStartChatByNickname
            )
        }

        PhonogrammTab.CONTACTS -> {
            ContactsTabView(
                contactsList = contactsList,
                contactFilter = contactFilter,
                onContactFilterChange = onContactFilterChange,
                onOpenNewChatModal = onOpenNewChatModal,
                onStartChatWithContact = { user ->
                    onStartChatByNickname(user.username)
                },
                onOpenContactProfile = { user ->
                    onOpenUserProfileModal(user.username)
                }
            )
        }

        PhonogrammTab.SETTINGS -> {
            SettingsTabView(
                currentUserProfile = currentUserProfile,
                isVerifiedAdmin = isVerifiedAdmin,
                currentOptimizationMode = currentOptimizationMode,
                onSelectProfileTab = { onSelectTab(PhonogrammTab.PROFILE) },
                onOpenEditProfileModal = onOpenEditProfileModal,
                onOpenThemeStudioModal = onOpenThemeStudioModal,
                onOpenOptimizationModal = onOpenOptimizationModal,
                onOpenAdminStudioModal = onOpenAdminStudioModal,
                onContactCreator = {
                    onStartChatByNickname("ShabanDurov")
                },
                onShowToast = onShowToast,
                onRequestLogout = onRequestLogout,
                onRequestDeleteAccount = onRequestDeleteAccount
            )
        }

        PhonogrammTab.PROFILE -> {
            ProfileTabView(
                currentUserProfile = currentUserProfile,
                isVerifiedAdmin = isVerifiedAdmin,
                isOnline = isOnline,
                onOpenEditProfileModal = onOpenEditProfileModal,
                onOpenSettingsTab = { onSelectTab(PhonogrammTab.SETTINGS) },
                onOpenGiftDetail = { gift -> onOpenGiftDetail(gift, true) },
                onAvatarPicked = onAvatarPicked,
                onShowToast = onShowToast
            )
        }
    }
}

@Composable
private fun DesktopEmptyChatWorkspace(
    modifier: Modifier = Modifier,
    onOpenNewChatModal: () -> Unit
) {
    val palette = LocalPhonogrammPalette.current
    PhonogrammSpatialChatBackground(modifier = modifier) {
        Column(modifier = Modifier.fillMaxSize()) {
            // Top .chat-header placeholder
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(64.dp)
                    .background(palette.surfaceFloating)
                    .padding(horizontal = 18.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                PhonogrammAvatar(
                    username = "?",
                    size = 42.dp,
                    cornerRadius = 14.dp,
                    fontSize = 16.sp
                )
                Spacer(modifier = Modifier.width(12.dp))
                Column {
                    Text(
                        text = "Выберите контакт",
                        fontFamily = PlusJakartaSansFontFamily,
                        fontWeight = FontWeight.Bold,
                        fontSize = 15.5.sp,
                        color = palette.text
                    )
                    Text(
                        text = "не в сети",
                        fontSize = 12.sp,
                        color = palette.offline
                    )
                }
            }
            HorizontalDivider(color = palette.border)

            // Center .chat-empty-hint card
            Box(
                modifier = Modifier
                    .weight(1f)
                    .fillMaxWidth()
                    .padding(24.dp),
                contentAlignment = Alignment.Center
            ) {
                Column(
                    modifier = Modifier
                        .widthIn(max = 340.dp)
                        .shadow(16.dp, RoundedCornerShape(22.dp))
                        .clip(RoundedCornerShape(22.dp))
                        .background(palette.surfaceFloating)
                        .border(1.dp, palette.border, RoundedCornerShape(22.dp))
                        .clickable(onClick = onOpenNewChatModal)
                        .padding(horizontal = 26.dp, vertical = 28.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Box(
                        modifier = Modifier
                            .size(64.dp)
                            .clip(RoundedCornerShape(20.dp))
                            .background(palette.primarySoft)
                            .border(1.dp, palette.primary.copy(alpha = 0.25f), RoundedCornerShape(20.dp)),
                        contentAlignment = Alignment.Center
                    ) {
                        Text(text = "💬", fontSize = 30.sp)
                    }
                    Spacer(modifier = Modifier.height(14.dp))
                    Text(
                        text = "Выберите беседу в боковой панели или начните новый диалог, чтобы отправить сообщение.",
                        fontSize = 13.5.sp,
                        color = palette.textSecondary,
                        textAlign = TextAlign.Center,
                        lineHeight = 20.sp
                    )
                }
            }

            // Bottom floating composer preview
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 28.dp, vertical = 14.dp)
                    .shadow(8.dp, RoundedCornerShape(18.dp))
                    .clip(RoundedCornerShape(18.dp))
                    .background(palette.surfaceFloating)
                    .border(1.dp, palette.borderStrong, RoundedCornerShape(18.dp))
                    .padding(horizontal = 14.dp, vertical = 9.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                PhonogrammComposerIconBtn(icon = Icons.Default.AttachFile, onClick = {})
                PhonogrammComposerIconBtn(icon = Icons.Default.Videocam, onClick = {})
                Box(
                    modifier = Modifier
                        .weight(1f)
                        .height(42.dp)
                        .clip(RoundedCornerShape(14.dp))
                        .background(palette.surfaceInput)
                        .border(1.dp, palette.border, RoundedCornerShape(14.dp))
                        .padding(horizontal = 16.dp),
                    contentAlignment = Alignment.CenterStart
                ) {
                    Text(
                        text = "Написать сообщение...",
                        fontSize = 14.sp,
                        color = palette.textTertiary
                    )
                }
                PhonogrammComposerIconBtn(icon = Icons.Default.Mic, onClick = {})
                Box(
                    modifier = Modifier
                        .size(42.dp)
                        .clip(RoundedCornerShape(13.dp))
                        .background(palette.msgOutBrush.let { palette.surfaceSubtle }),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = Icons.AutoMirrored.Filled.Send,
                        contentDescription = null,
                        tint = palette.textTertiary,
                        modifier = Modifier.size(18.dp)
                    )
                }
            }
        }
    }
}

@Composable
private fun PhonogrammComposerIconBtn(
    icon: ImageVector,
    onClick: () -> Unit
) {
    val palette = LocalPhonogrammPalette.current
    Box(
        modifier = Modifier
            .size(40.dp)
            .clip(RoundedCornerShape(12.dp))
            .background(palette.surfaceSubtle)
            .clickable(onClick = onClick),
        contentAlignment = Alignment.Center
    ) {
        Icon(
            imageVector = icon,
            contentDescription = null,
            tint = palette.textSecondary,
            modifier = Modifier.size(20.dp)
        )
    }
}

/**
 * Header square bordered icon button matching `.icon-action-btn` in the HTML.
 */
@Composable
internal fun HeaderIconActionButton(
    icon: ImageVector,
    contentDescription: String,
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
    tint: Color? = null
) {
    val palette = LocalPhonogrammPalette.current
    Box(
        modifier = modifier
            .size(38.dp)
            .clip(RoundedCornerShape(11.dp))
            .background(palette.surfaceSubtle)
            .border(1.dp, palette.border, RoundedCornerShape(11.dp))
            .clickable(onClick = onClick),
        contentAlignment = Alignment.Center
    ) {
        Icon(
            imageVector = icon,
            contentDescription = contentDescription,
            tint = tint ?: palette.textSecondary,
            modifier = Modifier.size(19.dp)
        )
    }
}

/**
 * Compact search box matching `.search-box` in the HTML (`height: 40px; border-radius: 12px; background: var(--surface-input); border: 1px solid var(--border)`).
 */
@Composable
private fun PhonogrammSearchBox(
    value: String,
    onValueChange: (String) -> Unit,
    placeholder: String,
    inputTestTag: String,
    focusRequester: FocusRequester? = null,
    onSearchAction: (() -> Unit)? = null
) {
    val palette = LocalPhonogrammPalette.current
    var isFocused by remember { mutableStateOf(false) }

    Box(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 14.dp, vertical = 9.dp)
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .height(42.dp)
                .clip(RoundedCornerShape(12.dp))
                .background(if (isFocused) palette.surfaceElevated else palette.surfaceInput)
                .border(
                    width = if (isFocused) 1.5.dp else 1.dp,
                    color = if (isFocused) palette.primary else palette.border,
                    shape = RoundedCornerShape(12.dp)
                )
                .padding(horizontal = 12.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(9.dp)
        ) {
            Icon(
                imageVector = Icons.Default.Search,
                contentDescription = null,
                tint = if (isFocused) palette.primary else palette.textTertiary,
                modifier = Modifier.size(17.dp)
            )

            Box(
                modifier = Modifier.weight(1f),
                contentAlignment = Alignment.CenterStart
            ) {
                if (value.isEmpty()) {
                    Text(
                        text = placeholder,
                        color = palette.textTertiary,
                        fontSize = 13.5.sp,
                        fontWeight = FontWeight.Normal,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                }
                BasicTextField(
                    value = value,
                    onValueChange = onValueChange,
                    singleLine = true,
                    textStyle = TextStyle(
                        color = palette.text,
                        fontSize = 13.5.sp,
                        fontWeight = FontWeight.Medium
                    ),
                    cursorBrush = SolidColor(palette.primary),
                    keyboardOptions = KeyboardOptions(
                        capitalization = KeyboardCapitalization.None,
                        autoCorrectEnabled = false,
                        imeAction = ImeAction.Search
                    ),
                    keyboardActions = KeyboardActions(
                        onSearch = { onSearchAction?.invoke() }
                    ),
                    modifier = Modifier
                        .fillMaxWidth()
                        .then(if (focusRequester != null) Modifier.focusRequester(focusRequester) else Modifier)
                        .onFocusChanged { isFocused = it.isFocused }
                        .testTag(inputTestTag)
                )
            }

            if (value.isNotEmpty()) {
                Box(
                    modifier = Modifier
                        .size(20.dp)
                        .clip(CircleShape)
                        .background(palette.surfaceSubtle)
                        .clickable { onValueChange("") },
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = Icons.Default.Clear,
                        contentDescription = "Очистить",
                        tint = palette.textSecondary,
                        modifier = Modifier.size(13.dp)
                    )
                }
            }
        }
    }
}

@Composable
private fun ChatsTabView(
    currentUserProfile: UserProfile,
    folderFilter: ChatFolderFilter,
    chatsState: UiState<List<DirectChat>>,
    contactsList: List<UserProfile>,
    searchState: UserSearchState,
    searchQuery: String,
    currentThemeKey: PhonogrammThemeKey,
    onSearchQueryChange: (String) -> Unit,
    onSelectFolderFilter: (ChatFolderFilter) -> Unit,
    onToggleQuickTheme: () -> Unit,
    onOpenNewChatModal: () -> Unit,
    onOpenSystemBotChat: () -> Unit,
    onOpenDirectChat: (DirectChat) -> Unit,
    onOpenUserProfileModal: (String) -> Unit,
    onStartChatByNickname: (String) -> Unit
) {
    val palette = LocalPhonogrammPalette.current
    val isOldDeviceMode = LocalDeviceOptimizationMode.current.isOldDeviceMode
    val nowMillis = rememberPresenceClockMillis()
    val cleanQuery = searchQuery.trim().removePrefix("@")
    val searchFocusRequester = remember { FocusRequester() }

    // .tg-header
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .height(64.dp)
            .background(palette.surface)
            .padding(horizontal = 18.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        Row(
            verticalAlignment = Alignment.CenterVertically
        ) {
            // .brand-mark-badge + overlapping .tg-header-brand-dot
            Box(contentAlignment = Alignment.Center) {
                Box(
                    modifier = Modifier
                        .size(34.dp)
                        .then(
                            if (isOldDeviceMode) Modifier
                            else Modifier.shadow(10.dp, RoundedCornerShape(10.dp), spotColor = palette.primary)
                        )
                        .clip(RoundedCornerShape(10.dp))
                        .background(palette.msgOutBrush),
                    contentAlignment = Alignment.Center
                ) {
                    Image(
                        painter = painterResource(id = R.drawable.oleg_logo),
                        contentDescription = "Oleg",
                        contentScale = ContentScale.Crop,
                        modifier = Modifier.fillMaxSize()
                    )
                }
                Box(
                    modifier = Modifier
                        .align(Alignment.BottomEnd)
                        .offset(x = 3.dp, y = 2.dp)
                        .size(10.dp)
                        .clip(CircleShape)
                        .background(palette.online)
                        .border(2.5.dp, palette.surface, CircleShape)
                )
            }
            Spacer(modifier = Modifier.width(12.dp))
            Text(
                text = "Oleg",
                fontFamily = PlusJakartaSansFontFamily,
                fontWeight = FontWeight.ExtraBold,
                fontSize = 19.sp,
                letterSpacing = if (isOldDeviceMode) 0.sp else (-0.5).sp,
                color = palette.text
            )
        }

        // .tg-header-actions (Theme toggle, Search focus, New dialog)
        Row(
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(6.dp)
        ) {
            HeaderIconActionButton(
                icon = if (currentThemeKey == PhonogrammThemeKey.LIGHT) {
                    Icons.Default.DarkMode
                } else {
                    Icons.Default.LightMode
                },
                contentDescription = "Переключить тему (Тёмная / Светлая)",
                onClick = onToggleQuickTheme,
                modifier = Modifier.testTag("theme_toggle_btn")
            )
            HeaderIconActionButton(
                icon = Icons.Default.Search,
                contentDescription = "Поиск",
                onClick = {
                    try {
                        searchFocusRequester.requestFocus()
                    } catch (_: Exception) {
                    }
                }
            )
            HeaderIconActionButton(
                icon = Icons.Default.Add,
                contentDescription = "Новый диалог",
                onClick = onOpenNewChatModal,
                modifier = Modifier.testTag("header_new_chat_btn")
            )
        }
    }

    HorizontalDivider(color = palette.border)

    // .search-box-wrap
    PhonogrammSearchBox(
        value = searchQuery,
        onValueChange = onSearchQueryChange,
        placeholder = "Поиск диалогов или @никнейма...",
        inputTestTag = "search_nickname_input",
        focusRequester = searchFocusRequester,
        onSearchAction = {
            if (cleanQuery.length >= 3) {
                onStartChatByNickname(cleanQuery)
            }
        }
    )

    // .sidebar-Segment-bar (Все потоки | Личные | Системные)
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .horizontalScroll(rememberScrollState())
            .padding(start = 14.dp, end = 14.dp, bottom = 8.dp),
        horizontalArrangement = Arrangement.spacedBy(6.dp)
    ) {
        FolderFilterPill(
            label = "Все потоки",
            selected = folderFilter == ChatFolderFilter.ALL,
            onClick = { onSelectFolderFilter(ChatFolderFilter.ALL) },
            tag = "folder_all"
        )
        FolderFilterPill(
            label = "Личные",
            selected = folderFilter == ChatFolderFilter.PERSONAL,
            onClick = { onSelectFolderFilter(ChatFolderFilter.PERSONAL) },
            tag = "folder_personal"
        )
        FolderFilterPill(
            label = "Системные",
            selected = folderFilter == ChatFolderFilter.SYSTEM,
            onClick = { onSelectFolderFilter(ChatFolderFilter.SYSTEM) },
            tag = "folder_system"
        )
    }

    HorizontalDivider(color = palette.border)

    // .chats-list
    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .testTag("chats_list"),
        contentPadding = PaddingValues(start = 10.dp, end = 10.dp, top = 8.dp, bottom = 92.dp),
        verticalArrangement = Arrangement.spacedBy(3.dp)
    ) {
        if (cleanQuery.isNotEmpty()) {
            item(key = "quick_search_card") {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(bottom = 4.dp)
                        .clip(RoundedCornerShape(14.dp))
                        .background(palette.primarySoft)
                        .border(1.dp, palette.primary.copy(alpha = 0.35f), RoundedCornerShape(14.dp))
                        .clickable { onStartChatByNickname(cleanQuery) }
                        .padding(horizontal = 12.dp, vertical = 10.dp)
                        .testTag("quick_open_nickname_card")
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        Box(
                            modifier = Modifier
                                .size(44.dp)
                                .clip(RoundedCornerShape(14.dp))
                                .background(palette.msgOutBrush),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(
                                imageVector = Icons.Default.Search,
                                contentDescription = null,
                                tint = Color.White,
                                modifier = Modifier.size(20.dp)
                            )
                        }
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = "Найти и открыть @$cleanQuery",
                                fontFamily = PlusJakartaSansFontFamily,
                                fontWeight = FontWeight.Bold,
                                fontSize = 14.5.sp,
                                color = palette.text
                            )
                            val subText = when (searchState) {
                                is UserSearchState.Searching -> "Поиск в Cloud Firestore..."
                                is UserSearchState.Found -> "Найден: ${searchState.user.resolvedDisplayName()} (@${searchState.user.username})"
                                is UserSearchState.NotFound -> "Пользователь не найден — нажмите для проверки"
                                is UserSearchState.Error -> searchState.message
                                else -> "Нажмите для мгновенного перехода к диалогу"
                            }
                            Text(
                                text = subText,
                                fontSize = 12.sp,
                                color = palette.primary,
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis
                            )
                        }
                    }
                }
            }
        }

        // Official Oleg ✈️ System Bot Row (shown in ALL and SYSTEM folders)
        val showSystemBot = (folderFilter == ChatFolderFilter.ALL || folderFilter == ChatFolderFilter.SYSTEM) &&
            (cleanQuery.isEmpty() || "олег".contains(cleanQuery.lowercase()) || "oleg".contains(cleanQuery.lowercase()))

        if (showSystemBot) {
            item(key = "__system_bot__") {
                val lastSysMsg = currentUserProfile.parsedSystemMessages.lastOrNull()
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(14.dp))
                        .clickable(onClick = onOpenSystemBotChat)
                        .padding(horizontal = 12.dp, vertical = 10.dp)
                        .testTag("chat_item___system__"),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    PhonogrammAvatar(
                        name = "Oleg",
                        avatarUrl = "",
                        size = 48.dp,
                        cornerRadius = 16.dp,
                        isSystemBot = true
                    )
                    Column(modifier = Modifier.weight(1f)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(5.dp)
                            ) {
                                Text(
                                    text = "Oleg",
                                    fontFamily = PlusJakartaSansFontFamily,
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 14.5.sp,
                                    color = palette.text
                                )
                                VerifiedBadgeIcon()
                            }
                            Text(
                                text = lastSysMsg?.time?.ifBlank { "Бот" } ?: "Бот",
                                fontSize = 11.sp,
                                color = palette.textTertiary,
                                fontWeight = FontWeight.Medium
                            )
                        }
                        Spacer(modifier = Modifier.height(3.dp))
                        Text(
                            text = lastSysMsg?.text?.replace("\n", " ")
                                ?: "Системные уведомления и безопасность",
                            fontSize = 12.5.sp,
                            color = palette.textSecondary,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis
                        )
                    }
                }
            }
        }

        // Direct Chats from Firestore (shown in ALL and PERSONAL folders)
        if (folderFilter != ChatFolderFilter.SYSTEM) {
            when (chatsState) {
                is UiState.Loading -> {
                    item(key = "loading_chats") {
                        Box(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(vertical = 32.dp),
                            contentAlignment = Alignment.Center
                        ) {
                            CircularProgressIndicator(color = palette.primary)
                        }
                    }
                }

                is UiState.Error -> {
                    item(key = "error_chats") {
                        Text(
                            text = chatsState.message,
                            color = palette.error,
                            fontSize = 13.sp,
                            modifier = Modifier.padding(16.dp)
                        )
                    }
                }

                is UiState.Success -> {
                    val filteredChats = chatsState.data.filter { chat ->
                        val peerUid = chat.otherParticipantId(currentUserProfile.uid)
                        val peerProf = contactsList.firstOrNull {
                            (peerUid.isNotBlank() && it.uid == peerUid) ||
                                it.username.equals(chat.otherUsername(currentUserProfile.uid), ignoreCase = true)
                        }
                        val peerUsername = peerProf?.username?.takeIf { it.isNotBlank() }
                            ?: chat.otherUsername(currentUserProfile.uid)
                        val disp = peerProf?.resolvedDisplayName() ?: peerUsername
                        cleanQuery.isEmpty() ||
                            peerUsername.lowercase().contains(cleanQuery.lowercase()) ||
                            disp.lowercase().contains(cleanQuery.lowercase())
                    }

                    if (filteredChats.isEmpty() && !showSystemBot) {
                        item(key = "empty_chats") {
                            Column(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(vertical = 42.dp, horizontal = 24.dp),
                                horizontalAlignment = Alignment.CenterHorizontally
                            ) {
                                Box(
                                    modifier = Modifier
                                        .size(56.dp)
                                        .clip(RoundedCornerShape(18.dp))
                                        .background(palette.primarySoft)
                                        .border(1.dp, palette.primary.copy(alpha = 0.25f), RoundedCornerShape(18.dp)),
                                    contentAlignment = Alignment.Center
                                ) {
                                    Text(text = "💬", fontSize = 26.sp)
                                }
                                Spacer(modifier = Modifier.height(12.dp))
                                Text(
                                    text = "Чаты не найдены",
                                    fontFamily = PlusJakartaSansFontFamily,
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 16.sp,
                                    color = palette.text
                                )
                                Spacer(modifier = Modifier.height(4.dp))
                                Text(
                                    text = "Нажмите кнопку «+» или введите @никнейм собеседника в поиск выше",
                                    fontSize = 12.5.sp,
                                    color = palette.textSecondary,
                                    textAlign = TextAlign.Center
                                )
                            }
                        }
                    } else {
                        items(
                            items = filteredChats,
                            key = { it.id }
                        ) { chat ->
                            val peerUid = chat.otherParticipantId(currentUserProfile.uid)
                            val peerProfile = contactsList.firstOrNull {
                                (peerUid.isNotBlank() && it.uid == peerUid) ||
                                    it.username.equals(chat.otherUsername(currentUserProfile.uid), ignoreCase = true)
                            }
                            val peerUsername = peerProfile?.username?.takeIf { it.isNotBlank() }
                                ?: chat.otherUsername(currentUserProfile.uid)
                            val isPeerOnlineNow = peerProfile?.isEffectivelyOnline(nowMillis) == true
                            val peerStatusText = peerProfile?.formatPresenceStatus(nowMillis) ?: "не в сети"
                            DirectChatRowItem(
                                chat = chat,
                                currentUserId = currentUserProfile.uid,
                                peerUsername = peerUsername,
                                peerDisplayName = peerProfile?.resolvedDisplayName() ?: "@$peerUsername",
                                peerBio = peerProfile?.bio?.ifBlank { peerStatusText } ?: peerStatusText,
                                peerAvatarUrl = peerProfile?.avatarUrl ?: "",
                                isPeerVerified = peerProfile?.isVerified == true,
                                isPeerCreator = peerProfile?.isCreatorRole == true,
                                isPeerOnline = isPeerOnlineNow,
                                peerStatusText = peerStatusText,
                                onClick = { onOpenDirectChat(chat) },
                                onAvatarClick = { onOpenUserProfileModal(peerUsername.ifBlank { peerUid }) }
                            )
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun FolderFilterPill(
    label: String,
    selected: Boolean,
    onClick: () -> Unit,
    tag: String
) {
    val palette = LocalPhonogrammPalette.current
    Box(
        modifier = Modifier
            .clip(CircleShape)
            .background(
                if (selected) palette.primarySoft else palette.surfaceSubtle
            )
            .border(
                width = 1.dp,
                color = if (selected) palette.primary.copy(alpha = 0.38f) else palette.border,
                shape = CircleShape
            )
            .clickable(onClick = onClick)
            .padding(horizontal = 12.dp, vertical = 5.dp)
            .testTag(tag)
    ) {
        Text(
            text = label,
            fontSize = 11.5.sp,
            fontWeight = FontWeight.SemiBold,
            color = if (selected) palette.primary else palette.textSecondary
        )
    }
}

@Composable
private fun DirectChatRowItem(
    chat: DirectChat,
    currentUserId: String,
    peerUsername: String,
    peerDisplayName: String,
    peerBio: String,
    peerAvatarUrl: String,
    isPeerVerified: Boolean,
    isPeerCreator: Boolean = false,
    isPeerOnline: Boolean,
    peerStatusText: String = "",
    onClick: () -> Unit,
    onAvatarClick: () -> Unit
) {
    val palette = LocalPhonogrammPalette.current
    val preview = if (chat.lastMessage.isBlank()) {
        "@$peerUsername • $peerBio"
    } else if (chat.lastSenderId == currentUserId) {
        "Вы: ${chat.lastMessage}"
    } else {
        chat.lastMessage
    }

    val timeOrStatus = if (chat.updatedAtMillis > 0L) {
        formatPhonogrammShortTime(chat.updatedAtMillis)
    } else if (isPeerOnline) {
        "в сети"
    } else {
        peerStatusText
    }

    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(14.dp))
            .clickable(onClick = onClick)
            .padding(horizontal = 12.dp, vertical = 10.dp)
            .testTag("chat_item_${chat.id}"),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        PhonogrammAvatar(
            username = peerUsername,
            customEmojiOrText = peerAvatarUrl,
            size = 48.dp,
            cornerRadius = 16.dp,
            fontSize = 18.sp,
            showOnlineDot = isPeerOnline,
            onClick = onAvatarClick
        )
        Column(modifier = Modifier.weight(1f)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(5.dp),
                    modifier = Modifier.weight(1f)
                ) {
                    Text(
                        text = peerDisplayName,
                        fontFamily = PlusJakartaSansFontFamily,
                        fontWeight = FontWeight.Bold,
                        fontSize = 14.5.sp,
                        color = palette.text,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                    if (isPeerVerified) {
                        VerifiedBadgeIcon()
                    }
                    if (isPeerCreator) {
                        RoleBadgePill(text = "СОЗДАТЕЛЬ", isCreator = true)
                    }
                }
                if (timeOrStatus.isNotEmpty()) {
                    Text(
                        text = timeOrStatus,
                        fontSize = 11.sp,
                        color = if (timeOrStatus == "в сети") palette.online else palette.textTertiary,
                        fontWeight = if (timeOrStatus == "в сети") FontWeight.SemiBold else FontWeight.Medium
                    )
                }
            }
            Spacer(modifier = Modifier.height(3.dp))
            Text(
                text = preview,
                fontSize = 12.5.sp,
                color = palette.textSecondary,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )
        }
    }
}

@Composable
private fun ContactsTabView(
    contactsList: List<UserProfile>,
    contactFilter: String,
    onContactFilterChange: (String) -> Unit,
    onOpenNewChatModal: () -> Unit,
    onStartChatWithContact: (UserProfile) -> Unit,
    onOpenContactProfile: (UserProfile) -> Unit
) {
    val palette = LocalPhonogrammPalette.current
    val isOldDeviceMode = LocalDeviceOptimizationMode.current.isOldDeviceMode
    val nowMillis = rememberPresenceClockMillis()
    val filtered = contactsList.filter { u ->
        val q = contactFilter.trim().removePrefix("@").lowercase()
        q.isEmpty() || u.username.lowercase().contains(q) || u.resolvedDisplayName().lowercase().contains(q)
    }

    // .tg-header
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .height(64.dp)
            .background(palette.surface)
            .padding(horizontal = 18.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        Text(
            text = "Люди и контакты",
            fontFamily = PlusJakartaSansFontFamily,
            fontWeight = FontWeight.ExtraBold,
            fontSize = 19.sp,
            letterSpacing = if (isOldDeviceMode) 0.sp else (-0.5).sp,
            color = palette.text
        )
        HeaderIconActionButton(
            icon = Icons.Default.PersonAddAlt1,
            contentDescription = "Добавить контакт",
            onClick = onOpenNewChatModal,
            modifier = Modifier.testTag("add_contact_btn")
        )
    }

    HorizontalDivider(color = palette.border)

    PhonogrammSearchBox(
        value = contactFilter,
        onValueChange = onContactFilterChange,
        placeholder = "Фильтр по имени или @нику...",
        inputTestTag = "contact_filter_input"
    )

    if (filtered.isEmpty()) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(32.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center
        ) {
            Box(
                modifier = Modifier
                    .size(60.dp)
                    .clip(RoundedCornerShape(18.dp))
                    .background(palette.primarySoft)
                    .border(1.dp, palette.primary.copy(alpha = 0.25f), RoundedCornerShape(18.dp)),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = Icons.Default.People,
                    contentDescription = null,
                    tint = palette.primary,
                    modifier = Modifier.size(28.dp)
                )
            }
            Spacer(modifier = Modifier.height(12.dp))
            Text(
                text = "Список контактов пуст.",
                fontFamily = PlusJakartaSansFontFamily,
                fontWeight = FontWeight.Bold,
                fontSize = 15.5.sp,
                color = palette.text
            )
            Spacer(modifier = Modifier.height(4.dp))
            Text(
                text = "Нажмите иконку добавления сверху, чтобы найти собеседника.",
                fontSize = 12.5.sp,
                color = palette.textSecondary,
                textAlign = TextAlign.Center
            )
        }
    } else {
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .testTag("contacts_list"),
            contentPadding = PaddingValues(horizontal = 10.dp, vertical = 6.dp),
            verticalArrangement = Arrangement.spacedBy(3.dp)
        ) {
            items(filtered, key = { it.uid }) { contact ->
                val isContactOnline = contact.isEffectivelyOnline(nowMillis)
                val statusText = contact.formatPresenceStatus(nowMillis)
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(14.dp))
                        .clickable { onStartChatWithContact(contact) }
                        .padding(horizontal = 12.dp, vertical = 10.dp)
                        .testTag("contact_item_${contact.username}"),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    PhonogrammAvatar(
                        username = contact.username,
                        customEmojiOrText = contact.avatarUrl,
                        size = 48.dp,
                        cornerRadius = 16.dp,
                        fontSize = 18.sp,
                        showOnlineDot = isContactOnline,
                        onClick = { onOpenContactProfile(contact) }
                    )
                    Column(modifier = Modifier.weight(1f)) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(5.dp)
                        ) {
                            Text(
                                text = contact.resolvedDisplayName(),
                                fontFamily = PlusJakartaSansFontFamily,
                                fontWeight = FontWeight.Bold,
                                fontSize = 14.5.sp,
                                color = palette.text
                            )
                            if (contact.isVerified) {
                                VerifiedBadgeIcon()
                            }
                            if (contact.isCreatorRole) {
                                RoleBadgePill(text = "СОЗДАТЕЛЬ", isCreator = true)
                            }
                        }
                        Spacer(modifier = Modifier.height(2.dp))
                        Text(
                            text = "@${contact.username} • $statusText",
                            fontSize = 12.5.sp,
                            color = if (isContactOnline) palette.online else palette.textSecondary,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis
                        )
                    }
                }
            }
        }
    }
}

@Composable
private fun SettingsTabView(
    currentUserProfile: UserProfile,
    isVerifiedAdmin: Boolean,
    currentOptimizationMode: DeviceOptimizationMode,
    onSelectProfileTab: () -> Unit,
    onOpenEditProfileModal: () -> Unit,
    onOpenThemeStudioModal: () -> Unit,
    onOpenOptimizationModal: () -> Unit,
    onOpenAdminStudioModal: () -> Unit,
    onContactCreator: () -> Unit,
    onShowToast: (String) -> Unit,
    onRequestLogout: () -> Unit,
    onRequestDeleteAccount: () -> Unit
) {
    val palette = LocalPhonogrammPalette.current
    val isOldDeviceMode = currentOptimizationMode.isOldDeviceMode

    // .tg-header
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .height(64.dp)
            .background(palette.surface)
            .padding(horizontal = 18.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        Text(
            text = "Центр настроек",
            fontFamily = PlusJakartaSansFontFamily,
            fontWeight = FontWeight.ExtraBold,
            fontSize = 19.sp,
            letterSpacing = if (isOldDeviceMode) 0.sp else (-0.5).sp,
            color = palette.text
        )
        HeaderIconActionButton(
            icon = Icons.AutoMirrored.Filled.Logout,
            contentDescription = "Выйти из аккаунта",
            onClick = onRequestLogout,
            modifier = Modifier.testTag("settings_header_logout_btn")
        )
    }

    HorizontalDivider(color = palette.border)

    // .settings-scroll-area
    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(horizontal = 14.dp, vertical = 14.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        // .tg-user-card (#settings-top-user-card)
        // `background: linear-gradient(135deg, var(--primary-soft) 0%, var(--surface-elevated) 100%);`
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .then(
                    if (isOldDeviceMode) Modifier
                    else Modifier.shadow(6.dp, RoundedCornerShape(16.dp))
                )
                .clip(RoundedCornerShape(16.dp))
                .background(
                    Brush.linearGradient(
                        listOf(palette.primarySoft, palette.surfaceElevated)
                    )
                )
                .border(1.dp, palette.borderStrong, RoundedCornerShape(16.dp))
                .clickable(onClick = onSelectProfileTab)
                .padding(16.dp)
                .testTag("settings_user_card"),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            PhonogrammAvatar(
                username = currentUserProfile.username,
                customEmojiOrText = currentUserProfile.avatarUrl,
                size = 60.dp,
                cornerRadius = 20.dp,
                fontSize = 24.sp
            )
            Column(modifier = Modifier.weight(1f)) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    Text(
                        text = currentUserProfile.resolvedDisplayName(),
                        fontFamily = PlusJakartaSansFontFamily,
                        fontWeight = FontWeight.ExtraBold,
                        fontSize = 16.5.sp,
                        color = palette.text
                    )
                    if (currentUserProfile.isVerified) {
                        VerifiedBadgeIcon()
                    }
                    if (isVerifiedAdmin || currentUserProfile.isCreatorRole) {
                        RoleBadgePill(text = "СОЗДАТЕЛЬ ⚡", isCreator = true)
                    }
                }
                Spacer(modifier = Modifier.height(3.dp))
                Text(
                    text = "@${currentUserProfile.username}",
                    fontSize = 13.sp,
                    color = palette.primary,
                    fontWeight = FontWeight.SemiBold
                )
            }
        }

        // Unified .tg-group-card matching HTML lines 1664-1748
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .then(
                    if (isOldDeviceMode) Modifier
                    else Modifier.shadow(3.dp, RoundedCornerShape(16.dp))
                )
                .clip(RoundedCornerShape(16.dp))
                .background(palette.surfaceElevated)
                .border(1.dp, palette.border, RoundedCornerShape(16.dp))
        ) {
            // 1. Личные данные (--tg-icon-user: linear-gradient(135deg, #6366f1, #4f46e5))
            SettingsRowItem(
                icon = Icons.Default.Person,
                iconBrush = Brush.linearGradient(listOf(Color(0xFF6366F1), Color(0xFF4F46E5))),
                title = "Личные данные",
                subtitle = "Отображаемое имя, «О себе», день рождения",
                onClick = onOpenEditProfileModal,
                tag = "settings_row_personal"
            )
            HorizontalDivider(color = palette.border)

            // 2. Дизайн и темы (--tg-icon-chat: linear-gradient(135deg, #f59e0b, #d97706))
            SettingsRowItem(
                icon = Icons.Default.Palette,
                iconBrush = Brush.linearGradient(listOf(Color(0xFFF59E0B), Color(0xFFD97706))),
                title = "Дизайн и темы",
                subtitle = "Светлая и тёмная темы, палитры, типографика",
                onClick = onOpenThemeStudioModal,
                tag = "settings_row_themes"
            )
            HorizontalDivider(color = palette.border)

            // 2.5 Оптимизация (Новые / Старые устройства)
            SettingsRowItem(
                icon = Icons.Default.Speed,
                iconBrush = Brush.linearGradient(listOf(Color(0xFF06B6D4), Color(0xFF2563EB))),
                title = "Оптимизация",
                subtitle = "Интерфейс: Новые или Старые устройства",
                actionPillValue = currentOptimizationMode.shortBadge,
                onClick = onOpenOptimizationModal,
                tag = "settings_row_optimization"
            )
            HorizontalDivider(color = palette.border)

            // 3. Безопасность и приватность (--tg-icon-lock: linear-gradient(135deg, #10b981, #059669))
            SettingsRowItem(
                icon = Icons.Default.Lock,
                iconBrush = Brush.linearGradient(listOf(Color(0xFF10B981), Color(0xFF059669))),
                title = "Безопасность и приватность",
                subtitle = "Контроль сессии и двустороннее удаление",
                onClick = {
                    onShowToast("🔒 В Oleg вы можете удалять сообщения у себя или у обоих собеседников навсегда!")
                },
                tag = "settings_row_security"
            )
            HorizontalDivider(color = palette.border)

            // 4. Push-уведомления и звук (--tg-icon-bell: linear-gradient(135deg, #ec4899, #db2777))
            SettingsRowItem(
                icon = Icons.Default.Notifications,
                iconBrush = Brush.linearGradient(listOf(Color(0xFFEC4899), Color(0xFFDB2777))),
                title = "Push-уведомления и звук",
                subtitle = "Системные оповещения и синхронизация Cloud Firestore",
                onClick = {
                    onShowToast("Уведомления активны: Включены ✅")
                },
                tag = "settings_row_notifications"
            )
            HorizontalDivider(color = palette.border)

            // 5. Язык локализации (--tg-icon-lang: linear-gradient(135deg, #8b5cf6, #6d28d9))
            SettingsRowItem(
                icon = Icons.Default.Language,
                iconBrush = Brush.linearGradient(listOf(Color(0xFF8B5CF6), Color(0xFF6D28D9))),
                title = "Язык локализации",
                subtitle = null,
                actionPillValue = "Русский",
                onClick = {
                    onShowToast("Выбран русский язык интерфейса (по умолчанию)")
                },
                tag = "settings_row_language"
            )
            HorizontalDivider(color = palette.border)

            // 6. Коллекция подарков (--tg-icon-gift: linear-gradient(135deg, #f97316, #ea580c))
            SettingsRowItem(
                icon = Icons.Default.CardGiftcard,
                iconBrush = Brush.linearGradient(listOf(Color(0xFFF97316), Color(0xFFEA580C))),
                title = "Коллекция подарков 🧸🎁🚀",
                subtitle = "Редкие цифровые награды в вашем профиле",
                actionPillValue = "${currentUserProfile.parsedGifts.size}",
                onClick = onSelectProfileTab,
                tag = "settings_row_gifts"
            )
            HorizontalDivider(color = palette.border)

            // 7. Панель создателя ⚡ (ONLY visible to server-verified @ShabanDurov)
            if (isVerifiedAdmin) {
                SettingsRowItem(
                    icon = Icons.Default.Bolt,
                    iconBrush = Brush.linearGradient(listOf(Color(0xFFEF4444), Color(0xFFB91C1C))),
                    title = "Панель создателя ⚡",
                    titleColor = Color(0xFFFF8A80),
                    subtitle = "Статистика, подарки, рассылка, управление базой",
                    onClick = onOpenAdminStudioModal,
                    tag = "settings_row_admin"
                )
                HorizontalDivider(color = palette.border)
            }

            // 8. Связаться с создателем (linear-gradient(135deg, #0ea5e9, #0284c7))
            SettingsRowItem(
                icon = Icons.Default.SupportAgent,
                iconBrush = Brush.linearGradient(listOf(Color(0xFF0EA5E9), Color(0xFF0284C7))),
                title = "Связаться с создателем",
                subtitle = "Прямой диалог с @Shaban Durov",
                onClick = onContactCreator,
                tag = "settings_row_creator"
            )
        }

        // #settings-logout-btn
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .height(46.dp)
                .clip(RoundedCornerShape(13.dp))
                .background(palette.errorSoft)
                .border(1.dp, palette.error.copy(alpha = 0.30f), RoundedCornerShape(13.dp))
                .clickable(onClick = onRequestLogout)
                .testTag("logout_button"),
            contentAlignment = Alignment.Center
        ) {
            Text(
                text = "Выйти из аккаунта",
                color = palette.error,
                fontWeight = FontWeight.Bold,
                fontSize = 14.sp
            )
        }

        // #settings-delete-account-btn (visual parity with HTML lines 1753-1755)
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .height(46.dp)
                .clip(RoundedCornerShape(13.dp))
                .background(palette.error.copy(alpha = 0.22f))
                .border(1.dp, palette.error.copy(alpha = 0.45f), RoundedCornerShape(13.dp))
                .clickable(onClick = onRequestDeleteAccount)
                .testTag("delete_account_button"),
            contentAlignment = Alignment.Center
        ) {
            Text(
                text = "🗑️ Удалить аккаунт навсегда",
                color = palette.error,
                fontWeight = FontWeight.Bold,
                fontSize = 14.sp
            )
        }

        Spacer(modifier = Modifier.height(16.dp))
    }
}

@Composable
private fun SettingsRowItem(
    icon: ImageVector,
    iconBrush: Brush,
    title: String,
    subtitle: String?,
    titleColor: Color? = null,
    actionPillValue: String? = null,
    onClick: () -> Unit,
    tag: String
) {
    val palette = LocalPhonogrammPalette.current
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clickable(onClick = onClick)
            .padding(horizontal = 15.dp, vertical = 13.dp)
            .testTag(tag),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(13.dp)
    ) {
        // .tg-setting-icon
        Box(
            modifier = Modifier
                .size(38.dp)
                .shadow(4.dp, RoundedCornerShape(12.dp))
                .clip(RoundedCornerShape(12.dp))
                .background(iconBrush)
                .border(1.dp, Color.White.copy(alpha = 0.25f), RoundedCornerShape(12.dp)),
            contentAlignment = Alignment.Center
        ) {
            Icon(
                imageVector = icon,
                contentDescription = null,
                tint = Color.White,
                modifier = Modifier.size(19.dp)
            )
        }
        Column(modifier = Modifier.weight(1f)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Text(
                    text = title,
                    fontWeight = FontWeight.SemiBold,
                    fontSize = 14.5.sp,
                    color = titleColor ?: palette.text,
                    modifier = Modifier.weight(1f, fill = false)
                )
                if (actionPillValue != null) {
                    // .tg-setting-action-val
                    Box(
                        modifier = Modifier
                            .padding(start = 8.dp)
                            .clip(CircleShape)
                            .background(palette.primarySoft)
                            .padding(horizontal = 9.dp, vertical = 2.dp)
                    ) {
                        Text(
                            text = actionPillValue,
                            fontSize = 12.5.sp,
                            fontWeight = FontWeight.Bold,
                            color = palette.primary
                        )
                    }
                }
            }
            if (!subtitle.isNullOrBlank()) {
                Spacer(modifier = Modifier.height(2.dp))
                Text(
                    text = subtitle,
                    fontSize = 12.sp,
                    color = palette.textSecondary,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
            }
        }
    }
}

@Composable
private fun ProfileTabView(
    currentUserProfile: UserProfile,
    isVerifiedAdmin: Boolean,
    isOnline: Boolean,
    onOpenEditProfileModal: () -> Unit,
    onOpenSettingsTab: () -> Unit,
    onOpenGiftDetail: (GiftItem) -> Unit,
    onAvatarPicked: (String) -> Unit,
    onShowToast: (String) -> Unit
) {
    val context = LocalContext.current
    val palette = LocalPhonogrammPalette.current
    val isOldDeviceMode = LocalDeviceOptimizationMode.current.isOldDeviceMode
    var selectedSubTab by remember { mutableIntStateOf(0) } // 0 = Подарки 🧸🎁🚀, 1 = Публикации

    val photoPickerLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.PickVisualMedia()
    ) { uri ->
        if (uri != null) {
            val encoded = PhonogrammMediaHelper.encodeUriToAvatarDataUri(context, uri.toString())
            onAvatarPicked(encoded ?: uri.toString())
        }
    }

    // .tg-header
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .height(64.dp)
            .background(palette.surface)
            .padding(horizontal = 18.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        Text(
            text = "Личный профиль",
            fontFamily = PlusJakartaSansFontFamily,
            fontWeight = FontWeight.ExtraBold,
            fontSize = 19.sp,
            letterSpacing = if (isOldDeviceMode) 0.sp else (-0.5).sp,
            color = palette.text
        )
        HeaderIconActionButton(
            icon = Icons.Default.Edit,
            contentDescription = "Редактировать профиль",
            onClick = onOpenEditProfileModal,
            modifier = Modifier.testTag("profile_edit_btn")
        )
    }

    HorizontalDivider(color = palette.border)

    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
    ) {
        // .profile-hero
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .background(palette.surfaceElevated)
                .background(
                    Brush.radialGradient(
                        colors = listOf(palette.primarySoft, Color.Transparent),
                        radius = 520f
                    )
                )
                .padding(start = 16.dp, end = 16.dp, top = 26.dp, bottom = 20.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            PhonogrammAvatar(
                username = currentUserProfile.username,
                customEmojiOrText = currentUserProfile.avatarUrl,
                size = 100.dp,
                cornerRadius = 32.dp,
                fontSize = 38.sp,
                showCameraBadge = true,
                onClick = {
                    photoPickerLauncher.launch(
                        PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly)
                    )
                },
                modifier = Modifier.testTag("profile_avatar_picker")
            )

            Spacer(modifier = Modifier.height(14.dp))

            // .profile-display-name
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                Text(
                    text = currentUserProfile.resolvedDisplayName(),
                    fontFamily = PlusJakartaSansFontFamily,
                    fontWeight = FontWeight.ExtraBold,
                    fontSize = 20.sp,
                    color = palette.text
                )
                if (currentUserProfile.isVerified) {
                    VerifiedBadgeIcon()
                }
                if (isVerifiedAdmin || currentUserProfile.isCreatorRole) {
                    RoleBadgePill(text = "СОЗДАТЕЛЬ ⚡", isCreator = true)
                }
            }

            Spacer(modifier = Modifier.height(6.dp))

            // .profile-status-label.online
            Box(
                modifier = Modifier
                    .clip(CircleShape)
                    .background(if (isOnline) palette.successSoft else palette.surfaceSubtle)
                    .border(
                        1.dp,
                        if (isOnline) palette.online.copy(alpha = 0.25f) else palette.border,
                        CircleShape
                    )
                    .padding(horizontal = 10.dp, vertical = 3.dp)
            ) {
                Text(
                    text = if (isOnline) "в сети" else "не в сети",
                    fontSize = 12.5.sp,
                    fontWeight = FontWeight.SemiBold,
                    color = if (isOnline) palette.online else palette.textSecondary
                )
            }

            Spacer(modifier = Modifier.height(18.dp))

            // .profile-actions-row (Фото | Изменить | Настройки)
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .widthIn(max = 360.dp),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                ProfileHeroActionButton(
                    icon = Icons.Default.CameraAlt,
                    label = "Фото",
                    modifier = Modifier.weight(1f),
                    onClick = {
                        photoPickerLauncher.launch(
                            PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly)
                        )
                    }
                )
                ProfileHeroActionButton(
                    icon = Icons.Default.Edit,
                    label = "Изменить",
                    modifier = Modifier.weight(1f),
                    onClick = onOpenEditProfileModal
                )
                ProfileHeroActionButton(
                    icon = Icons.Default.Settings,
                    label = "Настройки",
                    modifier = Modifier.weight(1f),
                    onClick = onOpenSettingsTab
                )
            }
        }

        HorizontalDivider(color = palette.border)

        // .profile-info-block
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(start = 14.dp, end = 14.dp, top = 14.dp)
                .shadow(3.dp, RoundedCornerShape(16.dp))
                .clip(RoundedCornerShape(16.dp))
                .background(palette.surfaceElevated)
                .border(1.dp, palette.border, RoundedCornerShape(16.dp))
                .padding(horizontal = 16.dp, vertical = 6.dp)
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .clickable {
                        copyToClipboard(context, "@${currentUserProfile.username}")
                        onShowToast("Никнейм @${currentUserProfile.username} скопирован")
                    }
                    .padding(vertical = 11.dp)
            ) {
                Text(
                    text = "@${currentUserProfile.username}",
                    fontWeight = FontWeight.SemiBold,
                    fontSize = 14.5.sp,
                    color = palette.text
                )
                Spacer(modifier = Modifier.height(3.dp))
                Text(
                    text = "ИМЯ ПОЛЬЗОВАТЕЛЯ",
                    fontSize = 11.5.sp,
                    fontWeight = FontWeight.Medium,
                    color = palette.textTertiary,
                    letterSpacing = 0.5.sp
                )
            }

            HorizontalDivider(color = palette.border)

            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(vertical = 11.dp)
            ) {
                Text(
                    text = currentUserProfile.birthday.ifBlank { "Не указан" },
                    fontWeight = FontWeight.SemiBold,
                    fontSize = 14.5.sp,
                    color = palette.text
                )
                Spacer(modifier = Modifier.height(3.dp))
                Text(
                    text = "ДЕНЬ РОЖДЕНИЯ",
                    fontSize = 11.5.sp,
                    fontWeight = FontWeight.Medium,
                    color = palette.textTertiary,
                    letterSpacing = 0.5.sp
                )
            }

            HorizontalDivider(color = palette.border)

            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(vertical = 11.dp)
            ) {
                Text(
                    text = currentUserProfile.bio.ifBlank { "Счастливый пользователь Oleg" },
                    fontWeight = FontWeight.SemiBold,
                    fontSize = 14.5.sp,
                    color = palette.text
                )
                Spacer(modifier = Modifier.height(3.dp))
                Text(
                    text = "О СЕБЕ",
                    fontSize = 11.5.sp,
                    fontWeight = FontWeight.Medium,
                    color = palette.textTertiary,
                    letterSpacing = 0.5.sp
                )
            }

            HorizontalDivider(color = palette.border)

            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .clickable {
                        copyToClipboard(context, currentUserProfile.uid)
                        onShowToast("Firebase UID скопирован в буфер обмена")
                    }
                    .padding(vertical = 11.dp)
                    .testTag("profile_uid_row"),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = currentUserProfile.uid,
                        fontFamily = JetBrainsMonoFontFamily,
                        fontWeight = FontWeight.SemiBold,
                        fontSize = 12.sp,
                        color = palette.text,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                    Spacer(modifier = Modifier.height(3.dp))
                    Text(
                        text = "FIREBASE UID",
                        fontSize = 11.5.sp,
                        fontWeight = FontWeight.Medium,
                        color = palette.textTertiary,
                        letterSpacing = 0.5.sp
                    )
                }
                Icon(
                    imageVector = Icons.Default.ContentCopy,
                    contentDescription = "Скопировать UID",
                    tint = palette.textSecondary,
                    modifier = Modifier.size(16.dp)
                )
            }
        }

        // .profile-tabs-header (.profile-tab-pill buttons)
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(start = 14.dp, end = 14.dp, top = 12.dp, bottom = 8.dp),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            ProfileSubTabPill(
                title = "Подарки 🧸🎁🚀",
                selected = selectedSubTab == 0,
                modifier = Modifier.weight(1f),
                onClick = { selectedSubTab = 0 }
            )
            ProfileSubTabPill(
                title = "Публикации",
                selected = selectedSubTab == 1,
                modifier = Modifier.weight(1f),
                onClick = { selectedSubTab = 1 }
            )
        }

        HorizontalDivider(color = palette.border)

        if (selectedSubTab == 0) {
            val gifts = currentUserProfile.parsedGifts
            if (gifts.isEmpty()) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 20.dp, vertical = 30.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Text(text = "🎁", fontSize = 38.sp)
                    Spacer(modifier = Modifier.height(6.dp))
                    Text(
                        text = "Подарков пока нет",
                        fontFamily = PlusJakartaSansFontFamily,
                        fontWeight = FontWeight.SemiBold,
                        fontSize = 15.sp,
                        color = palette.text
                    )
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        text = "Подарки выдаются администрацией за активность и общение!",
                        fontSize = 12.sp,
                        color = palette.textSecondary,
                        textAlign = TextAlign.Center
                    )
                }
            } else {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(start = 14.dp, end = 14.dp, top = 14.dp, bottom = 28.dp),
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    gifts.chunked(3).forEach { rowGifts ->
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(10.dp)
                        ) {
                            rowGifts.forEach { gift ->
                                GiftGridCard(
                                    gift = gift,
                                    modifier = Modifier.weight(1f),
                                    onClick = { onOpenGiftDetail(gift) }
                                )
                            }
                            repeat(3 - rowGifts.size) {
                                Spacer(modifier = Modifier.weight(1f))
                            }
                        }
                    }
                }
            }
        } else {
            // #profile-posts-container matching HTML lines 1806-1810
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 20.dp, vertical = 32.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Text(text = "✨", fontSize = 38.sp)
                Spacer(modifier = Modifier.height(10.dp))
                Text(
                    text = "Лента публикаций пуста",
                    fontFamily = PlusJakartaSansFontFamily,
                    fontWeight = FontWeight.Bold,
                    fontSize = 16.sp,
                    color = palette.text
                )
                Spacer(modifier = Modifier.height(4.dp))
                Text(
                    text = "Скоро здесь можно будет закреплять моменты и заметки профиля.",
                    fontSize = 13.sp,
                    color = palette.textSecondary,
                    textAlign = TextAlign.Center
                )
            }
        }
    }
}

@Composable
private fun ProfileHeroActionButton(
    icon: ImageVector,
    label: String,
    modifier: Modifier = Modifier,
    onClick: () -> Unit
) {
    val palette = LocalPhonogrammPalette.current
    Column(
        modifier = modifier
            .height(60.dp)
            .shadow(2.dp, RoundedCornerShape(14.dp))
            .clip(RoundedCornerShape(14.dp))
            .background(palette.surface)
            .border(1.dp, palette.border, RoundedCornerShape(14.dp))
            .clickable(onClick = onClick)
            .padding(vertical = 10.dp, horizontal = 6.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        Icon(
            imageVector = icon,
            contentDescription = label,
            tint = palette.primary,
            modifier = Modifier.size(20.dp)
        )
        Spacer(modifier = Modifier.height(5.dp))
        Text(
            text = label,
            fontSize = 12.sp,
            fontWeight = FontWeight.SemiBold,
            color = palette.text
        )
    }
}

@Composable
private fun ProfileSubTabPill(
    title: String,
    selected: Boolean,
    modifier: Modifier = Modifier,
    onClick: () -> Unit
) {
    val palette = LocalPhonogrammPalette.current
    Box(
        modifier = modifier
            .shadow(if (selected) 8.dp else 0.dp, RoundedCornerShape(12.dp), spotColor = palette.primary)
            .clip(RoundedCornerShape(12.dp))
            .background(if (selected) palette.primary else palette.surfaceElevated)
            .border(
                width = 1.dp,
                color = if (selected) Color.Transparent else palette.border,
                shape = RoundedCornerShape(12.dp)
            )
            .clickable(onClick = onClick)
            .padding(vertical = 9.dp, horizontal = 14.dp),
        contentAlignment = Alignment.Center
    ) {
        Text(
            text = title,
            fontSize = 13.sp,
            fontWeight = FontWeight.Bold,
            color = if (selected) Color.White else palette.textSecondary
        )
    }
}

/**
 * Mobile Floating Dock Navigation Bar matching `#bottom-nav-bar` in the HTML.
 */
@Composable
private fun PhonogrammBottomNavBar(
    currentTab: PhonogrammTab,
    currentUserProfile: UserProfile,
    chatsBadgeCount: Int,
    onSelectTab: (PhonogrammTab) -> Unit
) {
    val palette = LocalPhonogrammPalette.current
    val isOldDeviceMode = LocalDeviceOptimizationMode.current.isOldDeviceMode
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .background(if (isOldDeviceMode) palette.surfaceElevated else palette.surfaceFloating)
            .navigationBarsPadding()
            .then(
                // Extra safe clearance on older Android phones where 3-button system bars
                // may overlap the bottom edge of the screen
                if (isOldDeviceMode) Modifier.padding(bottom = 16.dp) else Modifier
            )
    ) {
        HorizontalDivider(color = if (isOldDeviceMode) palette.borderStrong else palette.border)
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .height(if (isOldDeviceMode) 60.dp else 66.dp)
                .padding(horizontal = if (isOldDeviceMode) 6.dp else 10.dp, vertical = if (isOldDeviceMode) 4.dp else 6.dp),
            horizontalArrangement = Arrangement.spacedBy(4.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            BottomNavItem(
                icon = Icons.AutoMirrored.Filled.Chat,
                label = "Чаты",
                selected = currentTab == PhonogrammTab.CHATS,
                badgeCount = chatsBadgeCount,
                onClick = { onSelectTab(PhonogrammTab.CHATS) },
                modifier = Modifier.weight(1f),
                tag = "nav_tab_chats"
            )
            BottomNavItem(
                icon = Icons.Default.People,
                label = "Контакты",
                selected = currentTab == PhonogrammTab.CONTACTS,
                onClick = { onSelectTab(PhonogrammTab.CONTACTS) },
                modifier = Modifier.weight(1f),
                tag = "nav_tab_contacts"
            )
            BottomNavItem(
                icon = Icons.Default.Settings,
                label = "Настройки",
                selected = currentTab == PhonogrammTab.SETTINGS,
                onClick = { onSelectTab(PhonogrammTab.SETTINGS) },
                modifier = Modifier.weight(1f),
                tag = "nav_tab_settings"
            )
            BottomNavProfileItem(
                username = currentUserProfile.username,
                avatarUrl = currentUserProfile.avatarUrl,
                label = "Профиль",
                selected = currentTab == PhonogrammTab.PROFILE,
                onClick = { onSelectTab(PhonogrammTab.PROFILE) },
                modifier = Modifier.weight(1f),
                tag = "nav_tab_profile"
            )
        }
    }
}

/**
 * Desktop Left Vertical Navigation Rail matching `@media (min-width: 769px) #bottom-nav-bar` in the HTML.
 */
@Composable
private fun PhonogrammDesktopNavRail(
    currentTab: PhonogrammTab,
    currentUserProfile: UserProfile,
    chatsBadgeCount: Int,
    onSelectTab: (PhonogrammTab) -> Unit
) {
    val palette = LocalPhonogrammPalette.current
    Row(modifier = Modifier.fillMaxHeight()) {
        Column(
            modifier = Modifier
                .width(74.dp)
                .fillMaxHeight()
                .background(palette.bgElevated)
                .padding(vertical = 18.dp, horizontal = 8.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            // #bottom-nav-bar::before (Oleg brand mark)
            Box(
                modifier = Modifier
                    .padding(bottom = 12.dp)
                    .size(42.dp)
                    .shadow(10.dp, RoundedCornerShape(14.dp), spotColor = palette.primary)
                    .clip(RoundedCornerShape(14.dp))
                    .background(palette.msgOutBrush),
                contentAlignment = Alignment.Center
            ) {
                Image(
                    painter = painterResource(id = R.drawable.oleg_logo),
                    contentDescription = "Oleg",
                    contentScale = ContentScale.Crop,
                    modifier = Modifier.fillMaxSize()
                )
            }

            BottomNavItem(
                icon = Icons.AutoMirrored.Filled.Chat,
                label = "Чаты",
                selected = currentTab == PhonogrammTab.CHATS,
                badgeCount = chatsBadgeCount,
                onClick = { onSelectTab(PhonogrammTab.CHATS) },
                modifier = Modifier.size(width = 58.dp, height = 56.dp),
                tag = "nav_tab_chats"
            )
            BottomNavItem(
                icon = Icons.Default.People,
                label = "Контакты",
                selected = currentTab == PhonogrammTab.CONTACTS,
                onClick = { onSelectTab(PhonogrammTab.CONTACTS) },
                modifier = Modifier.size(width = 58.dp, height = 56.dp),
                tag = "nav_tab_contacts"
            )
            BottomNavItem(
                icon = Icons.Default.Settings,
                label = "Настройки",
                selected = currentTab == PhonogrammTab.SETTINGS,
                onClick = { onSelectTab(PhonogrammTab.SETTINGS) },
                modifier = Modifier.size(width = 58.dp, height = 56.dp),
                tag = "nav_tab_settings"
            )
            BottomNavProfileItem(
                username = currentUserProfile.username,
                avatarUrl = currentUserProfile.avatarUrl,
                label = "Профиль",
                selected = currentTab == PhonogrammTab.PROFILE,
                onClick = { onSelectTab(PhonogrammTab.PROFILE) },
                modifier = Modifier.size(width = 58.dp, height = 56.dp),
                tag = "nav_tab_profile"
            )
        }
        Box(
            modifier = Modifier
                .width(1.dp)
                .fillMaxHeight()
                .background(palette.border)
        )
    }
}

@Composable
private fun BottomNavItem(
    icon: ImageVector,
    label: String,
    selected: Boolean,
    badgeCount: Int = 0,
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
    tag: String
) {
    val palette = LocalPhonogrammPalette.current
    Box(
        modifier = modifier
            .height(54.dp)
            .clip(RoundedCornerShape(14.dp))
            .background(if (selected) palette.primarySoft else Color.Transparent)
            .border(
                width = 1.dp,
                color = if (selected) palette.primary.copy(alpha = 0.25f) else Color.Transparent,
                shape = RoundedCornerShape(14.dp)
            )
            .clickable(onClick = onClick)
            .padding(horizontal = 6.dp, vertical = 4.dp)
            .testTag(tag),
        contentAlignment = Alignment.Center
    ) {
        Column(
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.spacedBy(3.dp)
        ) {
            Box {
                Icon(
                    imageVector = icon,
                    contentDescription = label,
                    tint = if (selected) palette.primary else palette.textSecondary,
                    modifier = Modifier.size(21.dp)
                )
                if (badgeCount > 0) {
                    Box(
                        modifier = Modifier
                            .align(Alignment.TopEnd)
                            .offset(x = 9.dp, y = (-4).dp)
                            .clip(CircleShape)
                            .background(palette.primary)
                            .padding(horizontal = 5.dp, vertical = 1.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        Text(
                            text = badgeCount.toString(),
                            fontSize = 9.5.sp,
                            fontWeight = FontWeight.Bold,
                            color = Color.White
                        )
                    }
                }
            }
            Text(
                text = label,
                fontSize = 11.sp,
                fontWeight = FontWeight.SemiBold,
                color = if (selected) palette.primary else palette.textSecondary,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )
        }
    }
}

/**
 * Profile tab item with `.nav-avatar-thumb` circular avatar thumbnail matching HTML line 1831.
 */
@Composable
private fun BottomNavProfileItem(
    username: String,
    avatarUrl: String,
    label: String,
    selected: Boolean,
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
    tag: String
) {
    val context = LocalContext.current
    val palette = LocalPhonogrammPalette.current
    val customBitmap = remember(avatarUrl) {
        if (avatarUrl.isNotBlank() && avatarUrl.length > 2) {
            PhonogrammMediaHelper.decodeAvatarBitmap(context, avatarUrl)
        } else {
            null
        }
    }
    val initial = when {
        avatarUrl.isNotBlank() && avatarUrl.length <= 2 -> avatarUrl
        else -> username.trim().removePrefix("@").firstOrNull()?.uppercaseChar()?.toString() ?: "?"
    }

    Box(
        modifier = modifier
            .height(54.dp)
            .clip(RoundedCornerShape(14.dp))
            .background(if (selected) palette.primarySoft else Color.Transparent)
            .border(
                width = 1.dp,
                color = if (selected) palette.primary.copy(alpha = 0.25f) else Color.Transparent,
                shape = RoundedCornerShape(14.dp)
            )
            .clickable(onClick = onClick)
            .padding(horizontal = 6.dp, vertical = 4.dp)
            .testTag(tag),
        contentAlignment = Alignment.Center
    ) {
        Column(
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.spacedBy(3.dp)
        ) {
            // .nav-avatar-thumb
            Box(
                modifier = Modifier
                    .size(23.dp)
                    .clip(CircleShape)
                    .background(getAvatarBrush(username))
                    .then(
                        if (selected) Modifier.border(2.dp, palette.primary, CircleShape)
                        else Modifier
                    ),
                contentAlignment = Alignment.Center
            ) {
                if (customBitmap != null) {
                    Image(
                        bitmap = customBitmap,
                        contentDescription = username,
                        contentScale = ContentScale.Crop,
                        filterQuality = FilterQuality.High,
                        modifier = Modifier.fillMaxSize()
                    )
                } else {
                    Text(
                        text = initial,
                        fontSize = 10.5.sp,
                        fontWeight = FontWeight.Bold,
                        color = Color.White
                    )
                }
            }
            Text(
                text = label,
                fontSize = 11.sp,
                fontWeight = FontWeight.SemiBold,
                color = if (selected) palette.primary else palette.textSecondary,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )
        }
    }
}

private fun copyToClipboard(context: Context, text: String) {
    val clipboard = context.getSystemService(Context.CLIPBOARD_SERVICE) as? ClipboardManager
    clipboard?.setPrimaryClip(ClipData.newPlainText("Oleg", text))
}

private fun formatPhonogrammShortTime(timestampMillis: Long): String {
    if (timestampMillis <= 0L) return ""
    val now = System.currentTimeMillis()
    val diff = now - timestampMillis
    return if (diff < 24 * 60 * 60 * 1000L) {
        SimpleDateFormat("HH:mm", Locale.getDefault()).format(Date(timestampMillis))
    } else {
        SimpleDateFormat("dd.MM", Locale.getDefault()).format(Date(timestampMillis))
    }
}
