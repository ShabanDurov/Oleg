package com.example

import android.Manifest
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.os.Build
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.safeDrawing
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.windowInsetsPadding
import androidx.compose.material3.Button
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.credentials.CredentialManager
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import androidx.lifecycle.ViewModelProvider.AndroidViewModelFactory.Companion.APPLICATION_KEY
import androidx.lifecycle.compose.LocalLifecycleOwner
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.lifecycle.viewmodel.initializer
import androidx.lifecycle.viewmodel.viewModelFactory
import com.example.data.model.ChatMessage
import com.example.data.repository.MessengerRepository
import com.example.ui.auth.signOut
import com.example.ui.components.PhonogrammActiveCallTopBanner
import com.example.ui.components.PhonogrammInAppNotificationBanner
import com.example.ui.components.PhonogrammToastBanner
import com.example.ui.screens.AdminStudioModal
import com.example.ui.screens.AuthScreen
import com.example.ui.screens.CallStudioOverlay
import com.example.ui.screens.ChatDetailScreen
import com.example.ui.screens.ClearChatModal
import com.example.ui.screens.ConfirmDeleteAccountModal
import com.example.ui.screens.ConfirmLogoutModal
import com.example.ui.screens.EditProfileModal
import com.example.ui.screens.GiftDetailSheetModal
import com.example.ui.screens.MainMessengerScreen
import com.example.ui.screens.MessageActionModal
import com.example.ui.screens.NewChatDialogModal
import com.example.ui.screens.OptimizationStudioModal
import com.example.ui.screens.RegistrationScreen
import com.example.ui.screens.ThemeStudioModal
import com.example.ui.screens.UserProfileSheetModal
import com.example.ui.theme.DeviceOptimizationMode
import com.example.ui.theme.LocalPhonogrammPalette
import com.example.ui.theme.PhonogrammTheme
import com.example.ui.theme.PhonogrammThemeKey
import com.example.ui.viewmodel.ChatFolderFilter
import com.example.ui.viewmodel.MessengerViewModel
import com.example.ui.viewmodel.PhonogrammTab
import com.example.ui.viewmodel.ProfileState
import com.example.util.PhonogrammMediaHelper
import com.example.util.PhonogrammNotificationHelper
import com.example.util.observeOnlineStatus
import com.google.firebase.Firebase
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.auth.FirebaseUser
import com.google.firebase.auth.auth
import com.google.firebase.firestore.FirebaseFirestore
import kotlinx.coroutines.channels.awaitClose
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.callbackFlow
import kotlinx.coroutines.launch

class MainActivity : ComponentActivity() {

    private var pendingNotificationChatTarget by mutableStateOf<Pair<String, Boolean>?>(null)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        PhonogrammNotificationHelper.ensureNotificationChannel(this)
        extractNotificationTarget(intent)
        enableEdgeToEdge()
        setContent {
            val context = LocalContext.current
            val prefs = remember(context) {
                context.getSharedPreferences("pg_prefs", Context.MODE_PRIVATE)
            }
            var currentThemeKey by remember {
                mutableStateOf(
                    PhonogrammThemeKey.fromId(prefs.getString("pg_theme", PhonogrammThemeKey.DEFAULT.id))
                )
            }
            var messageFontSizeSp by remember {
                mutableIntStateOf(prefs.getInt("pg_font_size", 15).coerceIn(13, 20))
            }
            var currentOptimizationMode by remember {
                mutableStateOf(
                    DeviceOptimizationMode.fromId(
                        prefs.getString("pg_device_optimization", DeviceOptimizationMode.NEW_DEVICES.id)
                    )
                )
            }

            PhonogrammTheme(
                themeKey = currentThemeKey,
                messageFontSizeSp = messageFontSizeSp,
                optimizationMode = currentOptimizationMode
            ) {
                AppNavigation(
                    currentThemeKey = currentThemeKey,
                    messageFontSizeSp = messageFontSizeSp,
                    currentOptimizationMode = currentOptimizationMode,
                    pendingNotificationTarget = pendingNotificationChatTarget,
                    onConsumeNotificationTarget = { pendingNotificationChatTarget = null },
                    onChangeTheme = { nextTheme ->
                        currentThemeKey = nextTheme
                        prefs.edit().putString("pg_theme", nextTheme.id).apply()
                    },
                    onChangeFontSize = { nextSize ->
                        val clamped = nextSize.coerceIn(13, 20)
                        messageFontSizeSp = clamped
                        prefs.edit().putInt("pg_font_size", clamped).apply()
                    },
                    onChangeOptimizationMode = { nextMode ->
                        currentOptimizationMode = nextMode
                        prefs.edit().putString("pg_device_optimization", nextMode.id).apply()
                    }
                )
            }
        }
    }

    override fun onStart() {
        super.onStart()
        PhonogrammNotificationHelper.setActivityInForeground(this, true)
    }

    override fun onResume() {
        super.onResume()
        PhonogrammNotificationHelper.setActivityInForeground(this, true)
    }

    override fun onStop() {
        PhonogrammNotificationHelper.setActivityInForeground(this, false)
        super.onStop()
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        setIntent(intent)
        extractNotificationTarget(intent)
    }

    private fun extractNotificationTarget(intent: Intent?) {
        val targetUsername = intent?.getStringExtra(PhonogrammNotificationHelper.EXTRA_OPEN_CHAT_USERNAME)
        val isSystem = intent?.getBooleanExtra(PhonogrammNotificationHelper.EXTRA_OPEN_CHAT_IS_SYSTEM, false) ?: false
        if (!targetUsername.isNullOrBlank()) {
            pendingNotificationChatTarget = targetUsername to isSystem
            intent.removeExtra(PhonogrammNotificationHelper.EXTRA_OPEN_CHAT_USERNAME)
            intent.removeExtra(PhonogrammNotificationHelper.EXTRA_OPEN_CHAT_IS_SYSTEM)
        }
        if (intent?.hasExtra(PhonogrammNotificationHelper.EXTRA_OPEN_CALL_ID) == true) {
            intent.removeExtra(PhonogrammNotificationHelper.EXTRA_OPEN_CALL_ID)
        }
    }
}

internal fun FirebaseAuth.authStateFlow(): Flow<FirebaseUser?> = callbackFlow {
    val listener = FirebaseAuth.AuthStateListener { auth ->
        trySend(auth.currentUser)
    }
    addAuthStateListener(listener)
    awaitClose { removeAuthStateListener(listener) }
}

@Composable
fun AppNavigation(
    auth: FirebaseAuth = Firebase.auth,
    currentThemeKey: PhonogrammThemeKey = PhonogrammThemeKey.DEFAULT,
    messageFontSizeSp: Int = 15,
    currentOptimizationMode: DeviceOptimizationMode = DeviceOptimizationMode.NEW_DEVICES,
    pendingNotificationTarget: Pair<String, Boolean>? = null,
    onConsumeNotificationTarget: () -> Unit = {},
    onChangeTheme: (PhonogrammThemeKey) -> Unit = {},
    onChangeFontSize: (Int) -> Unit = {},
    onChangeOptimizationMode: (DeviceOptimizationMode) -> Unit = {}
) {
    val currentUser by auth.authStateFlow().collectAsStateWithLifecycle(initialValue = auth.currentUser)
    val user = currentUser

    if (user == null) {
        LaunchedEffect(Unit) {
            PhonogrammNotificationHelper.stopMonitoring()
        }
        AuthScreen(
            onAuthSuccess = { }
        )
    } else {
        AuthenticatedMessengerHost(
            currentUserId = user.uid,
            currentThemeKey = currentThemeKey,
            messageFontSizeSp = messageFontSizeSp,
            currentOptimizationMode = currentOptimizationMode,
            pendingNotificationTarget = pendingNotificationTarget,
            onConsumeNotificationTarget = onConsumeNotificationTarget,
            onChangeTheme = onChangeTheme,
            onChangeFontSize = onChangeFontSize,
            onChangeOptimizationMode = onChangeOptimizationMode
        )
    }
}

@Composable
fun AuthenticatedMessengerHost(
    currentUserId: String,
    currentThemeKey: PhonogrammThemeKey,
    messageFontSizeSp: Int,
    currentOptimizationMode: DeviceOptimizationMode = DeviceOptimizationMode.NEW_DEVICES,
    pendingNotificationTarget: Pair<String, Boolean>? = null,
    onConsumeNotificationTarget: () -> Unit = {},
    onChangeTheme: (PhonogrammThemeKey) -> Unit,
    onChangeFontSize: (Int) -> Unit,
    onChangeOptimizationMode: (DeviceOptimizationMode) -> Unit = {}
) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val palette = LocalPhonogrammPalette.current
    val credentialManager = remember { CredentialManager.create(context) }
    val isOnline by remember(context) { observeOnlineStatus(context) }
        .collectAsStateWithLifecycle(initialValue = true)

    val viewModel: MessengerViewModel = viewModel(
        key = currentUserId,
        factory = viewModelFactory {
            initializer {
                val app = checkNotNull(this[APPLICATION_KEY]) {
                    "APPLICATION_KEY missing from CreationExtras"
                }
                val databaseId = app.getString(R.string.firestore_database_id)
                val db = FirebaseFirestore.getInstance(databaseId)
                MessengerViewModel(
                    repository = MessengerRepository(db, Firebase.auth),
                    currentUserId = currentUserId,
                    appContext = app.applicationContext
                )
            }
        }
    )

    LaunchedEffect(currentUserId, context) {
        PhonogrammNotificationHelper.startMonitoring(context.applicationContext, currentUserId)
    }

    val profileState by viewModel.profileState.collectAsStateWithLifecycle()
    val isRegistering by viewModel.isRegistering.collectAsStateWithLifecycle()
    val registrationError by viewModel.registrationError.collectAsStateWithLifecycle()
    val chatsState by viewModel.chatsState.collectAsStateWithLifecycle()
    val peerProfiles by viewModel.peerProfiles.collectAsStateWithLifecycle()
    val searchState by viewModel.searchState.collectAsStateWithLifecycle()
    val activeChat by viewModel.activeChat.collectAsStateWithLifecycle()
    val isSystemBotChatOpen by viewModel.isSystemBotChatOpen.collectAsStateWithLifecycle()
    val messagesState by viewModel.messagesState.collectAsStateWithLifecycle()
    val replyingTo by viewModel.replyingTo.collectAsStateWithLifecycle()
    val isCreatingChat by viewModel.isCreatingChat.collectAsStateWithLifecycle()
    val chatCreationError by viewModel.chatCreationError.collectAsStateWithLifecycle()
    val isSendingMessage by viewModel.isSendingMessage.collectAsStateWithLifecycle()
    val sendMessageError by viewModel.sendMessageError.collectAsStateWithLifecycle()
    val toastMessage by viewModel.toastMessage.collectAsStateWithLifecycle()
    val inAppNotification by viewModel.inAppNotification.collectAsStateWithLifecycle()
    val inspectedPeerProfile by viewModel.inspectedPeerProfile.collectAsStateWithLifecycle()
    val selectedGiftDetail by viewModel.selectedGiftDetail.collectAsStateWithLifecycle()
    val lastGeneratedCode by viewModel.lastGeneratedCode.collectAsStateWithLifecycle()
    val isVerifiedAdmin by viewModel.isVerifiedAdmin.collectAsStateWithLifecycle()
    val callUiModel by viewModel.callUiModel.collectAsStateWithLifecycle()
    val activeCallSession by viewModel.activeCallSession.collectAsStateWithLifecycle()
    val isCallMinimized by viewModel.isCallMinimized.collectAsStateWithLifecycle()
    val isDeletingAccount by viewModel.isDeletingAccount.collectAsStateWithLifecycle()

    val lifecycleOwner = LocalLifecycleOwner.current
    DisposableEffect(lifecycleOwner, viewModel) {
        val isResumedOrStarted = lifecycleOwner.lifecycle.currentState.isAtLeast(Lifecycle.State.STARTED)
        viewModel.setAppInForeground(isResumedOrStarted)
        PhonogrammNotificationHelper.setActivityInForeground(context.applicationContext, isResumedOrStarted)
        val observer = LifecycleEventObserver { _, event ->
            when (event) {
                Lifecycle.Event.ON_START,
                Lifecycle.Event.ON_RESUME -> {
                    viewModel.setAppInForeground(true)
                    PhonogrammNotificationHelper.setActivityInForeground(context.applicationContext, true)
                }
                Lifecycle.Event.ON_STOP -> {
                    viewModel.setAppInForeground(false)
                    PhonogrammNotificationHelper.setActivityInForeground(context.applicationContext, false)
                }
                else -> Unit
            }
        }
        lifecycleOwner.lifecycle.addObserver(observer)
        onDispose {
            lifecycleOwner.lifecycle.removeObserver(observer)
        }
    }

    var hasRequestedInitialPermissions by remember(currentUserId) { mutableStateOf(false) }
    val initialPermissionsLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.RequestMultiplePermissions()
    ) { _ -> }

    LaunchedEffect(profileState is ProfileState.Ready) {
        if (profileState is ProfileState.Ready && !hasRequestedInitialPermissions) {
            hasRequestedInitialPermissions = true
            val missingPermissions = buildList {
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU &&
                    !PhonogrammNotificationHelper.hasNotificationPermission(context)
                ) {
                    add(Manifest.permission.POST_NOTIFICATIONS)
                }
                if (!PhonogrammMediaHelper.hasRecordAudioPermission(context)) {
                    add(Manifest.permission.RECORD_AUDIO)
                }
            }
            if (missingPermissions.isNotEmpty()) {
                initialPermissionsLauncher.launch(missingPermissions.toTypedArray())
            }
        }
    }

    LaunchedEffect(inAppNotification) {
        if (inAppNotification != null) {
            delay(4500L)
            viewModel.dismissInAppNotification()
        }
    }

    LaunchedEffect(pendingNotificationTarget, profileState is ProfileState.Ready) {
        val target = pendingNotificationTarget
        if (target != null && profileState is ProfileState.Ready) {
            val (username, isSystem) = target
            onConsumeNotificationTarget()
            if (isSystem || username.equals("Oleg", ignoreCase = true) || username.equals("Олег", ignoreCase = true) || username.equals("Phonogramm", ignoreCase = true)) {
                viewModel.openSystemBotChat()
            } else {
                viewModel.startOrOpenChatByNickname(username)
            }
        }
    }

    var currentTab by remember { mutableStateOf(PhonogrammTab.CHATS) }
    var folderFilter by remember { mutableStateOf(ChatFolderFilter.ALL) }
    var showNewChatModal by remember { mutableStateOf(false) }
    var showEditProfileModal by remember { mutableStateOf(false) }
    var showThemeStudioModal by remember { mutableStateOf(false) }
    var showOptimizationModal by remember { mutableStateOf(false) }
    var showAdminStudioModal by remember { mutableStateOf(false) }
    var showClearChatModal by remember { mutableStateOf(false) }
    var showLogoutConfirmModal by remember { mutableStateOf(false) }
    var showDeleteAccountConfirmModal by remember { mutableStateOf(false) }
    var actionTargetMessage by remember { mutableStateOf<ChatMessage?>(null) }
    var pendingCallTarget by remember { mutableStateOf<Pair<String, Boolean>?>(null) }

    val callAudioPermissionLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.RequestPermission()
    ) { granted ->
        val target = pendingCallTarget
        pendingCallTarget = null
        if (granted && target != null) {
            viewModel.startCallByNickname(target.first, target.second)
        } else {
            viewModel.showToast("Для аудиозвонка необходимо разрешение на использование микрофона 🎙️")
        }
    }

    val callVideoPermissionLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.RequestMultiplePermissions()
    ) { permissions ->
        val micGranted = permissions[Manifest.permission.RECORD_AUDIO] == true ||
            PhonogrammMediaHelper.hasRecordAudioPermission(context)
        val camGranted = permissions[Manifest.permission.CAMERA] == true ||
            PhonogrammMediaHelper.hasCameraPermission(context)
        val target = pendingCallTarget
        pendingCallTarget = null
        if (micGranted && camGranted && target != null) {
            viewModel.startCallByNickname(target.first, target.second)
        } else {
            viewModel.showToast("Для видеозвонка необходимы разрешения на микрофон и камеру 📹🎙️")
        }
    }

    val requestAndStartCall: (String, Boolean) -> Unit = { partnerUsername, isVideo ->
        if (isVideo) {
            if (PhonogrammMediaHelper.hasVideoCallPermissions(context)) {
                viewModel.startCallByNickname(partnerUsername, true)
            } else {
                pendingCallTarget = partnerUsername to true
                callVideoPermissionLauncher.launch(
                    arrayOf(Manifest.permission.RECORD_AUDIO, Manifest.permission.CAMERA)
                )
            }
        } else {
            if (PhonogrammMediaHelper.hasRecordAudioPermission(context)) {
                viewModel.startCallByNickname(partnerUsername, false)
            } else {
                pendingCallTarget = partnerUsername to false
                callAudioPermissionLauncher.launch(Manifest.permission.RECORD_AUDIO)
            }
        }
    }

    LaunchedEffect(showAdminStudioModal, isVerifiedAdmin) {
        if (showAdminStudioModal && !isVerifiedAdmin) {
            showAdminStudioModal = false
            viewModel.requestOpenAdminPanel()
        }
    }

    LaunchedEffect(toastMessage) {
        if (toastMessage != null) {
            delay(3200)
            viewModel.clearToast()
        }
    }

    val handleSignOut: () -> Unit = {
        viewModel.closeActiveChat()
        PhonogrammNotificationHelper.stopMonitoring()
        scope.launch {
            viewModel.markOfflineBeforeSignOut()
            signOut(
                credentialManager = credentialManager,
                onSignOutComplete = { },
                scope = scope
            )
        }
    }

    Box(modifier = Modifier.fillMaxSize()) {
        when (val state = profileState) {
            is ProfileState.Loading -> {
                Surface(
                    modifier = Modifier.fillMaxSize(),
                    color = palette.bgDeep
                ) {
                    Box(
                        modifier = Modifier.fillMaxSize(),
                        contentAlignment = Alignment.Center
                    ) {
                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                            CircularProgressIndicator(color = palette.accentPrimary)
                            Spacer(modifier = Modifier.height(14.dp))
                            Text(
                                text = "Синхронизация Oleg Cloud...",
                                style = MaterialTheme.typography.bodyMedium,
                                color = palette.textSecondary
                            )
                        }
                    }
                }
            }

            is ProfileState.NeedsRegistration -> {
                RegistrationScreen(
                    currentUserId = currentUserId,
                    isSubmitting = isRegistering,
                    errorMessage = registrationError,
                    onNicknameClearError = viewModel::clearRegistrationError,
                    onRegisterNickname = { nick, bday ->
                        viewModel.registerNickname(nick, bday)
                    },
                    onSignOut = handleSignOut
                )
            }

            is ProfileState.Error -> {
                Surface(
                    modifier = Modifier.fillMaxSize(),
                    color = palette.bgDeep
                ) {
                    Column(
                        modifier = Modifier
                            .fillMaxSize()
                            .padding(24.dp),
                        horizontalAlignment = Alignment.CenterHorizontally,
                        verticalArrangement = Arrangement.Center
                    ) {
                        Text(
                            text = state.message,
                            style = MaterialTheme.typography.bodyLarge,
                            color = palette.statusDanger
                        )
                        Spacer(modifier = Modifier.height(16.dp))
                        Button(onClick = viewModel::retryLoadProfile) {
                            Text("Повторить подключение")
                        }
                        Spacer(modifier = Modifier.height(10.dp))
                        Button(onClick = handleSignOut) {
                            Text("Выйти из аккаунта")
                        }
                    }
                }
            }

            is ProfileState.Ready -> {
                val selectedChat = activeChat
                val contactsList = remember(peerProfiles) {
                    peerProfiles.values.sortedBy { it.usernameLower }
                }
                val activeCallForBanner = activeCallSession

                Column(modifier = Modifier.fillMaxSize()) {
                    // Persistent top internal call notification banner when call is minimized into the messenger
                    PhonogrammActiveCallTopBanner(
                        visible = activeCallForBanner != null && isCallMinimized,
                        partnerUsername = activeCallForBanner?.otherUsername(currentUserId).orEmpty(),
                        isVideo = callUiModel.isLocalVideoEnabled || callUiModel.isRemoteVideoEnabled || activeCallForBanner?.isVideo == true,
                        isConnected = activeCallForBanner?.status == com.example.data.model.CallSession.STATUS_ACCEPTED,
                        elapsedTimeText = callUiModel.formattedElapsedTime,
                        onReturnToCall = {
                            viewModel.expandCall()
                        },
                        onHangupCall = {
                            viewModel.declineOrHangupCall(activeCallForBanner)
                        },
                        modifier = Modifier
                            .statusBarsPadding()
                    )

                    Box(modifier = Modifier.weight(1f).fillMaxSize()) {
                        if (isSystemBotChatOpen || selectedChat != null) {
                            val peerUid = selectedChat?.otherParticipantId(currentUserId).orEmpty()
                            val peerUsername = selectedChat?.otherParticipantUsername(currentUserId)?.lowercase().orEmpty()
                            val peerProf = when {
                                peerUid.isNotBlank() -> peerProfiles.values.firstOrNull { it.uid == peerUid }
                                    ?: if (peerUsername.isNotBlank()) peerProfiles[peerUsername] else null
                                peerUsername.isNotBlank() -> peerProfiles[peerUsername]
                                else -> null
                            }

                            ChatDetailScreen(
                                isSystemBotChat = isSystemBotChatOpen,
                                chat = selectedChat,
                                peerProfile = peerProf,
                                currentUserProfile = state.profile,
                                messagesState = messagesState,
                                replyingToMessage = replyingTo,
                                isSending = isSendingMessage,
                                sendError = sendMessageError,
                                onSendMessage = { text, onSent ->
                                    viewModel.sendMessage(text, onSent)
                                },
                                onSetReplyToMessage = { msg ->
                                    if (msg == null) viewModel.clearReplyToMessage()
                                    else viewModel.setReplyToMessage(msg)
                                },
                                onOpenMessageActions = { msg ->
                                    actionTargetMessage = msg
                                },
                                onOpenClearChatModal = {
                                    showClearChatModal = true
                                },
                                onOpenPeerProfile = { targetUsername ->
                                    if (targetUsername != "__system__") {
                                        viewModel.openPeerProfileModal(targetUsername)
                                    } else {
                                        viewModel.showToast("Oleg ✈️ — официальный системный бот безопасности")
                                    }
                                },
                                onStartAudioCall = { partnerName ->
                                    requestAndStartCall(partnerName, false)
                                },
                                onStartVideoCall = { partnerName ->
                                    requestAndStartCall(partnerName, true)
                                },
                                onShowToast = viewModel::showToast,
                                onClearSendError = viewModel::clearSendMessageError,
                                onBack = viewModel::closeActiveChat
                            )
                        } else {
                            BackHandler {
                                if (currentTab != PhonogrammTab.CHATS) {
                                    currentTab = PhonogrammTab.CHATS
                                } else {
                                    (context as? ComponentActivity)?.moveTaskToBack(true)
                                }
                            }

                            MainMessengerScreen(
                                currentUserProfile = state.profile,
                        isVerifiedAdmin = isVerifiedAdmin,
                        currentTab = currentTab,
                        folderFilter = folderFilter,
                        chatsState = chatsState,
                        contactsList = contactsList,
                        searchState = searchState,
                        isOnline = isOnline,
                        currentThemeKey = currentThemeKey,
                        currentOptimizationMode = currentOptimizationMode,
                        onSelectTab = { currentTab = it },
                        onSelectFolderFilter = { folderFilter = it },
                        onToggleQuickTheme = {
                            val next = if (currentThemeKey == PhonogrammThemeKey.LIGHT) {
                                PhonogrammThemeKey.DEFAULT
                            } else {
                                PhonogrammThemeKey.LIGHT
                            }
                            onChangeTheme(next)
                            viewModel.showToast("Тема изменена: ${next.title}")
                        },
                        onOpenNewChatModal = {
                            viewModel.clearChatCreationError()
                            showNewChatModal = true
                        },
                        onOpenEditProfileModal = {
                            showEditProfileModal = true
                        },
                        onOpenThemeStudioModal = {
                            showThemeStudioModal = true
                        },
                        onOpenOptimizationModal = {
                            showOptimizationModal = true
                        },
                        onOpenAdminStudioModal = {
                            if (viewModel.requestOpenAdminPanel()) {
                                showAdminStudioModal = true
                            } else {
                                showAdminStudioModal = false
                            }
                        },
                        onOpenGiftDetail = { gift, isMine ->
                            viewModel.openGiftDetailSheet(gift, isMine)
                        },
                        onOpenUserProfileModal = { username ->
                            viewModel.openPeerProfileModal(username)
                        },
                        onOpenSystemBotChat = viewModel::openSystemBotChat,
                        onOpenDirectChat = viewModel::openChat,
                        onStartChatByNickname = { nickname, onSuccess ->
                            viewModel.startOrOpenChatByNickname(nickname, onSuccess)
                        },
                        onSearchNickname = viewModel::searchUserByNickname,
                        onClearSearch = viewModel::clearSearch,
                        onAvatarPicked = viewModel::updateAvatarStyle,
                        onShowToast = viewModel::showToast,
                        onRequestLogout = {
                            showLogoutConfirmModal = true
                        },
                        onRequestDeleteAccount = {
                            showDeleteAccountConfirmModal = true
                        }
                    )
                        }
                    }
                }

                // Modals
                if (showNewChatModal) {
                    NewChatDialogModal(
                        isCreating = isCreatingChat,
                        errorMessage = chatCreationError,
                        onDismiss = {
                            showNewChatModal = false
                            viewModel.clearChatCreationError()
                        },
                        onConfirmNickname = { nick ->
                            viewModel.startOrOpenChatByNickname(nick) {
                                showNewChatModal = false
                            }
                        }
                    )
                }

                if (showEditProfileModal) {
                    EditProfileModal(
                        profile = state.profile,
                        onDismiss = { showEditProfileModal = false },
                        onSave = { displayName, birthday, bio ->
                            viewModel.updateProfileInfo(displayName, birthday, bio) {
                                showEditProfileModal = false
                            }
                        },
                        onRequestVerification = viewModel::submitVerificationRequest
                    )
                }

                if (showThemeStudioModal) {
                    ThemeStudioModal(
                        currentTheme = currentThemeKey,
                        currentFontSizeSp = messageFontSizeSp,
                        onSelectTheme = { themeKey ->
                            onChangeTheme(themeKey)
                            viewModel.showToast("Выбрана тема: ${themeKey.title}")
                        },
                        onChangeFontSize = onChangeFontSize,
                        onDismiss = { showThemeStudioModal = false }
                    )
                }

                if (showOptimizationModal) {
                    OptimizationStudioModal(
                        currentMode = currentOptimizationMode,
                        onSelectMode = { mode ->
                            onChangeOptimizationMode(mode)
                            viewModel.showToast("Режим оптимизации: ${mode.title} ⚡")
                        },
                        onDismiss = { showOptimizationModal = false }
                    )
                }

                if (showAdminStudioModal && isVerifiedAdmin) {
                    val nowMillis = System.currentTimeMillis()
                    val onlineCount = contactsList.count { it.isEffectivelyOnline(nowMillis) }
                    AdminStudioModal(
                        currentUserProfile = state.profile,
                        knownPeersCount = contactsList.size,
                        onlinePeersCount = onlineCount,
                        lastGeneratedCode = lastGeneratedCode,
                        onSendGift = viewModel::adminSendGift,
                        onSetVerified = viewModel::adminSetVerified,
                        onGenerateCode = viewModel::adminGenerateCode,
                        onDismiss = { showAdminStudioModal = false }
                    )
                }

                val targetMsg = actionTargetMessage
                if (targetMsg != null) {
                    MessageActionModal(
                        message = targetMsg,
                        onReply = {
                            viewModel.setReplyToMessage(targetMsg)
                            actionTargetMessage = null
                        },
                        onCopy = {
                            val cm = context.getSystemService(Context.CLIPBOARD_SERVICE) as? ClipboardManager
                            cm?.setPrimaryClip(ClipData.newPlainText("Message", targetMsg.text))
                            viewModel.showToast("Текст скопирован 📋")
                            actionTargetMessage = null
                        },
                        onDeleteForMe = {
                            viewModel.deleteMessageForMe(targetMsg)
                            actionTargetMessage = null
                        },
                        onDeleteForAll = {
                            viewModel.deleteMessageForAll(targetMsg)
                            actionTargetMessage = null
                        },
                        onDismiss = { actionTargetMessage = null }
                    )
                }

                if (showClearChatModal) {
                    ClearChatModal(
                        onClearForMe = {
                            viewModel.clearActiveChatForMe()
                            showClearChatModal = false
                        },
                        onClearForBoth = {
                            viewModel.clearActiveChatForBoth()
                            showClearChatModal = false
                        },
                        onDeleteContact = {
                            viewModel.deleteActiveContact()
                            showClearChatModal = false
                        },
                        onDismiss = { showClearChatModal = false }
                    )
                }

                if (showLogoutConfirmModal) {
                    ConfirmLogoutModal(
                        onConfirm = {
                            showLogoutConfirmModal = false
                            handleSignOut()
                        },
                        onDismiss = { showLogoutConfirmModal = false }
                    )
                }

                if (showDeleteAccountConfirmModal) {
                    ConfirmDeleteAccountModal(
                        username = state.profile.username,
                        isDeleting = isDeletingAccount,
                        onConfirmDelete = {
                            viewModel.deleteMyAccount {
                                showDeleteAccountConfirmModal = false
                                handleSignOut()
                            }
                        },
                        onDismiss = {
                            if (!isDeletingAccount) {
                                showDeleteAccountConfirmModal = false
                            }
                        }
                    )
                }

                val giftPair = selectedGiftDetail
                if (giftPair != null) {
                    GiftDetailSheetModal(
                        gift = giftPair.first,
                        isMyProfile = giftPair.second,
                        onToggleHide = {
                            viewModel.toggleGiftVisibility(giftPair.first)
                        },
                        onDismiss = viewModel::closeGiftDetailSheet
                    )
                }

                val peerModalProfile = inspectedPeerProfile
                if (peerModalProfile != null) {
                    UserProfileSheetModal(
                        peerProfile = peerModalProfile,
                        onOpenChat = {
                            viewModel.closePeerProfileModal()
                            viewModel.startOrOpenChatWithUser(peerModalProfile)
                        },
                        onStartAudioCall = {
                            viewModel.closePeerProfileModal()
                            requestAndStartCall(peerModalProfile.username, false)
                        },
                        onStartVideoCall = {
                            viewModel.closePeerProfileModal()
                            requestAndStartCall(peerModalProfile.username, true)
                        },
                        onInspectGift = { gift ->
                            viewModel.openGiftDetailSheet(gift, isMyProfile = false)
                        },
                        onDismiss = viewModel::closePeerProfileModal
                    )
                }

                val activeCall = activeCallSession
                if (activeCall != null) {
                    CallStudioOverlay(
                        partnerUsername = activeCall.otherUsername(currentUserId),
                        callUiModel = callUiModel,
                        webRtcEngine = viewModel.webRtcEngine,
                        onMinimizeToMessenger = {
                            viewModel.minimizeCall()
                        },
                        onAcceptCall = { enableVideo ->
                            viewModel.acceptIncomingCall(activeCall, enableVideo)
                        },
                        onToggleMute = {
                            viewModel.toggleCallMute()
                        },
                        onToggleSpeaker = {
                            viewModel.toggleCallSpeaker()
                        },
                        onToggleVideo = {
                            viewModel.toggleCallVideo()
                        },
                        onSwitchCamera = {
                            viewModel.switchCallCamera()
                        },
                        onHangup = {
                            viewModel.declineOrHangupCall(activeCall)
                        }
                    )
                }
            }
        }

        PhonogrammInAppNotificationBanner(
            notification = inAppNotification,
            onOpenChat = { notif ->
                viewModel.dismissInAppNotification()
                if (notif.isCallInvite && activeCallSession != null) {
                    viewModel.expandCall()
                } else if (notif.isSystemBot ||
                    notif.senderUsername.equals("Oleg", ignoreCase = true) ||
                    notif.senderUsername.equals("Олег", ignoreCase = true) ||
                    notif.senderUsername.equals("Phonogramm", ignoreCase = true)
                ) {
                    viewModel.openSystemBotChat()
                } else {
                    viewModel.startOrOpenChatByNickname(notif.senderUsername)
                }
            },
            onDismiss = viewModel::dismissInAppNotification,
            modifier = Modifier
                .align(Alignment.TopCenter)
                .windowInsetsPadding(WindowInsets.safeDrawing)
        )

        PhonogrammToastBanner(
            message = toastMessage,
            onDismiss = viewModel::clearToast,
            modifier = Modifier
                .align(Alignment.TopCenter)
                .windowInsetsPadding(WindowInsets.safeDrawing)
        )
    }
}
