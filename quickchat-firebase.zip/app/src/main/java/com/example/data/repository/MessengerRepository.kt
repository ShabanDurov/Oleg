package com.example.data.repository

import android.content.Context
import android.util.Log
import com.example.R
import com.example.data.OperationType
import com.example.data.handleFirestoreError
import com.example.data.model.AdminAccessDeniedException
import com.example.data.model.CallSession
import com.example.data.model.ChatMessage
import com.example.data.model.DirectChat
import com.example.data.model.GiftItem
import com.example.data.model.NicknameTakenException
import com.example.data.model.NicknameValidationException
import com.example.data.model.SelfChatException
import com.example.data.model.SystemBotMessage
import com.example.data.model.UserProfile
import com.google.firebase.Firebase
import com.google.firebase.Timestamp
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.auth.auth
import com.google.firebase.firestore.DocumentSnapshot
import com.google.firebase.firestore.FieldValue
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.FirebaseFirestoreException
import com.google.firebase.firestore.ListenerRegistration
import com.google.firebase.firestore.Source
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import kotlin.coroutines.cancellation.CancellationException
import kotlin.random.Random
import kotlinx.coroutines.Job
import kotlinx.coroutines.channels.awaitClose
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.callbackFlow
import kotlinx.coroutines.launch
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import kotlinx.coroutines.tasks.await
import kotlinx.coroutines.withTimeoutOrNull

class MessengerRepository(
    private val db: FirebaseFirestore,
    private val auth: FirebaseAuth = Firebase.auth
) {
    private val iceCandidateMutex = Mutex()

    constructor(context: Context) : this(
        FirebaseFirestore.getInstance(
            context.applicationContext.getString(R.string.firestore_database_id)
        ),
        Firebase.auth
    )

    private fun requireUserId(): String {
        return auth.currentUser?.uid?.takeIf { it.isNotBlank() }
            ?: throw IllegalStateException("Необходима авторизация пользователя в Firebase Auth.")
    }

    fun validateNickname(rawNickname: String): Result<String> {
        val trimmed = rawNickname.trim().removePrefix("@")
        if (trimmed.isEmpty()) {
            return Result.failure(NicknameValidationException("Введите @никнейм"))
        }
        if (trimmed.length < 3 || trimmed.length > 20) {
            return Result.failure(
                NicknameValidationException("Длина никнейма должна быть от 3 до 20 символов (сейчас: ${trimmed.length})")
            )
        }
        if (!NICKNAME_REGEX.matches(trimmed)) {
            return Result.failure(
                NicknameValidationException("Разрешены только латинские буквы (a-z, A-Z), цифры (0-9) и подчёркивание (_)")
            )
        }
        if (trimmed.equals("oleg", ignoreCase = true) || trimmed.equals("phonogramm", ignoreCase = true)) {
            return Result.failure(
                NicknameValidationException("Никнейм @$trimmed зарезервирован системой Oleg")
            )
        }
        return Result.success(trimmed)
    }

    /**
     * Safely parses a UserProfile from a DocumentSnapshot with defensive defaults for all optional fields.
     * Prevents deserialization crashes on legacy or partially populated documents.
     */
    private fun DocumentSnapshot.toSafeUserProfile(fallbackUid: String = id): UserProfile? {
        if (!exists()) return null
        return try {
            val rawData = data ?: return null
            val docUid = (rawData["uid"] as? String)?.takeIf { it.isNotBlank() } ?: fallbackUid
            val docUsername = (rawData["username"] as? String)?.trim() ?: ""
            val docUsernameLower = (rawData["usernameLower"] as? String)?.trim()?.lowercase(Locale.ROOT)
                ?: docUsername.lowercase(Locale.ROOT)
            val docDisplayName = (rawData["displayName"] as? String)?.trim() ?: docUsername
            val docBio = (rawData["bio"] as? String)?.trim() ?: ""
            val docBirthday = (rawData["birthday"] as? String)?.trim() ?: ""
            val docAvatarUrl = (rawData["avatarUrl"] as? String)?.trim() ?: ""
            val docIsVerified = (rawData["isVerified"] as? Boolean)
                ?: (rawData["verified"] as? Boolean)
                ?: false
            val docHasAdminPanel = (rawData["hasAdminPanel"] as? Boolean) ?: false
            val docIsOnline = (rawData["isOnline"] as? Boolean)
                ?: (rawData["online"] as? Boolean)
                ?: false
            val docLastOnlineMillis = (rawData["lastOnlineMillis"] as? Number)?.toLong() ?: 0L

            val docContacts = (rawData["contacts"] as? List<*>)
                ?.mapNotNull { (it as? String)?.trim() }
                ?.filter { it.isNotEmpty() }
                ?: emptyList()

            val docGifts = (rawData["gifts"] as? List<*>)
                ?.mapNotNull { item ->
                    if (item is Map<*, *>) {
                        item.entries.associate { (k, v) -> k.toString() to (v ?: "") }
                    } else {
                        null
                    }
                }
                ?: emptyList()

            val docSystemMessages = (rawData["systemMessages"] as? List<*>)
                ?.mapNotNull { item ->
                    if (item is Map<*, *>) {
                        item.entries.associate { (k, v) -> k.toString() to (v ?: "") }
                    } else {
                        null
                    }
                }
                ?: emptyList()

            val docCreatedAt = getTimestamp("createdAt", DocumentSnapshot.ServerTimestampBehavior.ESTIMATE)
            val docUpdatedAt = getTimestamp("updatedAt", DocumentSnapshot.ServerTimestampBehavior.ESTIMATE)

            UserProfile(
                id = id,
                uid = docUid,
                username = docUsername,
                usernameLower = docUsernameLower,
                displayName = docDisplayName,
                bio = docBio,
                birthday = docBirthday,
                avatarUrl = docAvatarUrl,
                isVerified = docIsVerified,
                hasAdminPanel = docHasAdminPanel,
                isOnline = docIsOnline,
                lastOnlineMillis = docLastOnlineMillis,
                contacts = docContacts,
                gifts = docGifts,
                systemMessages = docSystemMessages,
                createdAt = docCreatedAt,
                updatedAt = docUpdatedAt
            )
        } catch (e: Exception) {
            Log.e(TAG, "Failed to parse UserProfile from snapshot users/$id", e)
            null
        }
    }

    private fun DocumentSnapshot.toSafeDirectChat(): DirectChat? {
        if (!exists()) return null
        return try {
            val rawData = data ?: return null
            val p1Id = (rawData["participant1Id"] as? String) ?: ""
            val p2Id = (rawData["participant2Id"] as? String) ?: ""
            val pIds = (rawData["participantIds"] as? List<*>)
                ?.mapNotNull { it as? String }
                ?.takeIf { it.size == 2 }
                ?: listOf(p1Id, p2Id).filter { it.isNotBlank() }

            DirectChat(
                id = id,
                participantIds = pIds,
                participant1Id = p1Id,
                participant2Id = p2Id,
                participant1Username = (rawData["participant1Username"] as? String) ?: "",
                participant2Username = (rawData["participant2Username"] as? String) ?: "",
                lastMessageText = (rawData["lastMessageText"] as? String) ?: "",
                lastMessageSenderId = (rawData["lastMessageSenderId"] as? String) ?: "",
                createdAt = getTimestamp("createdAt", DocumentSnapshot.ServerTimestampBehavior.ESTIMATE),
                updatedAt = getTimestamp("updatedAt", DocumentSnapshot.ServerTimestampBehavior.ESTIMATE)
            )
        } catch (e: Exception) {
            Log.e(TAG, "Failed to parse DirectChat from snapshot chats/$id", e)
            null
        }
    }

    private fun DocumentSnapshot.toSafeChatMessage(fallbackChatId: String): ChatMessage? {
        if (!exists()) return null
        return try {
            val rawData = data ?: return null
            val pIds = (rawData["participantIds"] as? List<*>)
                ?.mapNotNull { it as? String }
                ?: emptyList()
            val delFor = (rawData["deletedFor"] as? List<*>)
                ?.mapNotNull { it as? String }
                ?: emptyList()

            ChatMessage(
                id = id,
                chatId = (rawData["chatId"] as? String)?.ifBlank { fallbackChatId } ?: fallbackChatId,
                senderId = (rawData["senderId"] as? String) ?: "",
                senderUsername = (rawData["senderUsername"] as? String) ?: "",
                text = (rawData["text"] as? String) ?: "",
                participantIds = pIds,
                replyToSender = (rawData["replyToSender"] as? String) ?: "",
                replyToText = (rawData["replyToText"] as? String) ?: "",
                read = (rawData["read"] as? Boolean) ?: false,
                deletedFor = delFor,
                voiceAudioBase64 = (rawData["voiceAudioBase64"] as? String) ?: "",
                imageBase64 = (rawData["imageBase64"] as? String) ?: "",
                createdAt = getTimestamp("createdAt", DocumentSnapshot.ServerTimestampBehavior.ESTIMATE)
            )
        } catch (e: Exception) {
            Log.e(TAG, "Failed to parse ChatMessage from snapshot chats/$fallbackChatId/messages/$id", e)
            null
        }
    }

    internal fun DocumentSnapshot.toSafeCallSession(): CallSession? {
        if (!exists()) return null
        return try {
            val rawData = data ?: return null
            val p1Id = (rawData["participant1Id"] as? String) ?: ""
            val p2Id = (rawData["participant2Id"] as? String) ?: ""
            val pIds = (rawData["participantIds"] as? List<*>)
                ?.mapNotNull { it as? String }
                ?.takeIf { it.size == 2 }
                ?: listOf(p1Id, p2Id).filter { it.isNotBlank() }

            val callerCands = (rawData["callerCandidates"] as? List<*>)
                ?.mapNotNull { it as? String }
                ?.take(60)
                ?: emptyList()
            val calleeCands = (rawData["calleeCandidates"] as? List<*>)
                ?.mapNotNull { it as? String }
                ?.take(60)
                ?: emptyList()

            CallSession(
                id = id,
                callId = (rawData["callId"] as? String)?.ifBlank { id } ?: id,
                sessionId = (rawData["sessionId"] as? String) ?: "",
                participantIds = pIds,
                participant1Id = p1Id,
                participant2Id = p2Id,
                callerId = (rawData["callerId"] as? String) ?: "",
                callerUsername = (rawData["callerUsername"] as? String) ?: "",
                calleeId = (rawData["calleeId"] as? String) ?: "",
                calleeUsername = (rawData["calleeUsername"] as? String) ?: "",
                isVideo = (rawData["isVideo"] as? Boolean) ?: false,
                status = (rawData["status"] as? String) ?: CallSession.STATUS_ENDED,
                callerVideoEnabled = (rawData["callerVideoEnabled"] as? Boolean) ?: false,
                calleeVideoEnabled = (rawData["calleeVideoEnabled"] as? Boolean) ?: false,
                callerMuted = (rawData["callerMuted"] as? Boolean) ?: false,
                calleeMuted = (rawData["calleeMuted"] as? Boolean) ?: false,
                offerSdp = (rawData["offerSdp"] as? String) ?: "",
                offerType = (rawData["offerType"] as? String) ?: "",
                answerSdp = (rawData["answerSdp"] as? String) ?: "",
                answerType = (rawData["answerType"] as? String) ?: "",
                callerCandidates = callerCands,
                calleeCandidates = calleeCands,
                createdAt = getTimestamp("createdAt", DocumentSnapshot.ServerTimestampBehavior.ESTIMATE),
                updatedAt = getTimestamp("updatedAt", DocumentSnapshot.ServerTimestampBehavior.ESTIMATE)
            )
        } catch (e: Exception) {
            Log.e(TAG, "Failed to parse CallSession from snapshot calls/$id", e)
            null
        }
    }

    /**
     * Observes the current user's profile document at /users/{userId}.
     * Includes automatic multi-step token refresh & backoff recovery so signing out and
     * signing back in never flashes a transient PERMISSION_DENIED / UNAUTHENTICATED screen.
     */
    fun observeUserProfile(userId: String): Flow<UserProfile?> = callbackFlow {
        val path = "users/$userId"
        if (userId.isBlank()) {
            trySend(null)
            close()
            return@callbackFlow
        }

        val docRef = db.collection("users").document(userId)
        var registration: ListenerRegistration? = null
        var retryAttempt = 0

        // Warm up token and perform a resilient initial fetch before attaching snapshot listener
        try {
            auth.currentUser?.getIdToken(false)?.await()
        } catch (tokenErr: Exception) {
            Log.w(TAG, "Initial getIdToken(false) before observeUserProfile failed: ${tokenErr.message}")
        }

        for (attempt in 0..2) {
            if (auth.currentUser?.uid != userId) break
            try {
                val initialSnap = docRef.get().await()
                if (initialSnap.exists()) {
                    trySend(initialSnap.toSafeUserProfile(userId))
                } else {
                    trySend(null)
                }
                break
            } catch (e: Exception) {
                if (attempt < 2) {
                    try {
                        auth.currentUser?.getIdToken(true)?.await()
                    } catch (_: Exception) {
                    }
                    delay(300L * (attempt + 1))
                }
            }
        }

        fun attachListener() {
            registration?.remove()
            registration = docRef.addSnapshotListener { snapshot, error ->
                if (error != null) {
                    if (auth.currentUser == null || auth.currentUser?.uid != userId) {
                        close()
                        return@addSnapshotListener
                    }
                    handleFirestoreError(error, OperationType.GET, path)
                    Log.w(TAG, "Snapshot listener error on $path (code=${error.code}, attempt=$retryAttempt): ${error.message}")

                    launch {
                        when (error.code) {
                            FirebaseFirestoreException.Code.NOT_FOUND -> {
                                trySend(null)
                            }

                            FirebaseFirestoreException.Code.PERMISSION_DENIED,
                            FirebaseFirestoreException.Code.UNAUTHENTICATED,
                            FirebaseFirestoreException.Code.INTERNAL,
                            FirebaseFirestoreException.Code.UNAVAILABLE,
                            FirebaseFirestoreException.Code.DEADLINE_EXCEEDED -> {
                                if (retryAttempt < 4 && auth.currentUser?.uid == userId) {
                                    retryAttempt += 1
                                    val backoffMs = 300L * retryAttempt
                                    delay(backoffMs)
                                    try {
                                        auth.currentUser?.getIdToken(true)?.await()
                                        val retrySnap = docRef.get().await()
                                        if (retrySnap.exists()) {
                                            trySend(retrySnap.toSafeUserProfile(userId))
                                        } else {
                                            trySend(null)
                                        }
                                        attachListener()
                                        return@launch
                                    } catch (retryEx: Exception) {
                                        Log.w(TAG, "Retry #$retryAttempt for $path failed: ${retryEx.message}")
                                        if (retryAttempt < 4) {
                                            attachListener()
                                            return@launch
                                        }
                                    }
                                }
                                try {
                                    val cachedSnap = docRef.get(Source.CACHE).await()
                                    if (cachedSnap.exists()) {
                                        trySend(cachedSnap.toSafeUserProfile(userId))
                                        return@launch
                                    }
                                } catch (_: Exception) {
                                }
                                close(error)
                            }

                            else -> {
                                close(error)
                            }
                        }
                    }
                    return@addSnapshotListener
                }

                retryAttempt = 0
                if (snapshot != null) {
                    if (!snapshot.exists()) {
                        trySend(null)
                    } else {
                        trySend(snapshot.toSafeUserProfile(userId))
                    }
                }
            }
        }

        attachListener()

        awaitClose {
            registration?.remove()
        }
    }

    suspend fun getUserProfile(userId: String): Result<UserProfile?> {
        if (userId.isBlank()) return Result.success(null)
        val path = "users/$userId"
        return try {
            val snap = db.collection("users").document(userId).get().await()
            if (snap.exists()) {
                Result.success(snap.toSafeUserProfile(userId))
            } else {
                Result.success(null)
            }
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.GET, path)
            Result.failure(e)
        }
    }

    /**
     * Observes a peer user's profile document `/users/{peerUid}` in real time so their online/offline
     * presence, lastOnlineMillis heartbeat, avatar, and verification badge update immediately.
     */
    fun observePeerProfile(peerUid: String): Flow<UserProfile?> = callbackFlow {
        if (peerUid.isBlank()) {
            trySend(null)
            close()
            return@callbackFlow
        }
        val docRef = db.collection("users").document(peerUid)
        var registration: ListenerRegistration? = null
        var retryJob: Job? = null

        fun mapSnapshot(snapshot: DocumentSnapshot): UserProfile? {
            if (!snapshot.exists()) return null
            return snapshot.toSafeUserProfile(peerUid)?.let { prof ->
                if (peerUid != auth.currentUser?.uid) {
                    prof.copy(contacts = emptyList(), systemMessages = emptyList())
                } else {
                    prof
                }
            }
        }

        launch {
            try {
                val freshSnap = docRef.get().await()
                if (freshSnap.exists()) {
                    trySend(mapSnapshot(freshSnap))
                }
            } catch (_: Exception) {
            }
        }

        fun attachListener() {
            registration?.remove()
            registration = docRef.addSnapshotListener { snapshot, error ->
                if (error != null) {
                    if (auth.currentUser == null) {
                        close()
                        return@addSnapshotListener
                    }
                    retryJob?.cancel()
                    retryJob = launch {
                        delay(1200L)
                        if (auth.currentUser != null) {
                            attachListener()
                        }
                    }
                    return@addSnapshotListener
                }
                if (snapshot != null && snapshot.exists()) {
                    trySend(mapSnapshot(snapshot))
                } else {
                    trySend(null)
                }
            }
        }

        attachListener()
        awaitClose {
            retryJob?.cancel()
            registration?.remove()
        }
    }

    suspend fun isCurrentUserVerifiedAdmin(): Boolean {
        val currentUser = auth.currentUser ?: return false
        val uid = currentUser.uid
        if (uid.isBlank()) return false

        return try {
            val userSnap = db.collection("users").document(uid).get().await()
            val profile = userSnap.toSafeUserProfile(uid) ?: return false
            if (profile.usernameLower != ADMIN_USERNAME_LOWER) {
                return false
            }

            val tokenResult = try {
                currentUser.getIdToken(false).await()
            } catch (_: Exception) {
                null
            }
            val hasCustomClaimAdmin = tokenResult?.claims?.get("admin") == true
            if (hasCustomClaimAdmin) {
                return true
            }

            val adminConfigSnap = db.collection("config").document("admin").get().await()
            if (!adminConfigSnap.exists()) {
                return false
            }
            val configuredAdminUid = adminConfigSnap.getString("adminUid")?.trim() ?: ""
            configuredAdminUid.isNotEmpty() && configuredAdminUid == uid
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            Log.w(TAG, "Admin verification check failed for uid=$uid: ${e.message}")
            false
        }
    }

    fun observeAdminStatus(userId: String): Flow<Boolean> = callbackFlow {
        if (userId.isBlank() || auth.currentUser?.uid != userId) {
            trySend(false)
            close()
            return@callbackFlow
        }

        trySend(isCurrentUserVerifiedAdmin())

        val configRef = db.collection("config").document("admin")
        val registration = configRef.addSnapshotListener { _, error ->
            if (error != null) {
                trySend(false)
                return@addSnapshotListener
            }
            launch {
                trySend(isCurrentUserVerifiedAdmin())
            }
        }

        awaitClose {
            registration.remove()
        }
    }

    private suspend fun requireVerifiedAdmin(): String {
        val uid = requireUserId()
        if (!isCurrentUserVerifiedAdmin()) {
            throw AdminAccessDeniedException(
                "Доступ запрещён: административные операции доступны только подтверждённому администратору @ShabanDurov"
            )
        }
        return uid
    }

    suspend fun registerNickname(
        rawNickname: String,
        rawBirthday: String = ""
    ): Result<UserProfile> {
        val validated = validateNickname(rawNickname).getOrElse { return Result.failure(it) }
        val uid = try {
            requireUserId()
        } catch (e: Exception) {
            return Result.failure(e)
        }
        val usernameLower = validated.lowercase(Locale.ROOT)
        val userRef = db.collection("users").document(uid)
        val usernameRef = db.collection("usernames").document(usernameLower)
        val nowMillis = System.currentTimeMillis()
        val birthdayClean = rawBirthday.trim().take(50)

        val welcomeMsg = SystemBotMessage(
            id = "welcome_$nowMillis",
            text = "👋 Добро пожаловать в Oleg!\n\nВаш аккаунт @$validated успешно зарегистрирован и защищён через Firebase Authentication.\nВаш уникальный UID: $uid",
            timestamp = nowMillis
        )

        val starterGift = GiftItem(
            id = "gift_welcome_$nowMillis",
            from = "Oleg",
            icon = "🚀",
            rarity = "epic",
            comment = "Первооткрывателю Oleg",
            dateStr = formatRussianDateTime(nowMillis),
            timestamp = nowMillis,
            hidden = false
        )

        return try {
            val profile = db.runTransaction { transaction ->
                val existingUserSnap = transaction.get(userRef)
                if (existingUserSnap.exists()) {
                    val existingObj = existingUserSnap.toSafeUserProfile(uid)
                    if (existingObj != null && existingObj.username.isNotBlank()) {
                        return@runTransaction existingObj
                    }
                }

                val existingUsernameSnap = transaction.get(usernameRef)
                if (existingUsernameSnap.exists()) {
                    val ownerUid = existingUsernameSnap.getString("uid")
                    if (ownerUid != uid) {
                        throw NicknameTakenException("Этот @никнейм («$validated») уже занят!")
                    }
                }

                val displayName = validated
                val bio = "Счастливый пользователь Oleg"

                val userData = mapOf(
                    "uid" to uid,
                    "username" to validated,
                    "usernameLower" to usernameLower,
                    "displayName" to displayName,
                    "bio" to bio,
                    "birthday" to birthdayClean,
                    "avatarUrl" to "",
                    "isVerified" to false,
                    "hasAdminPanel" to false,
                    "isOnline" to true,
                    "lastOnlineMillis" to nowMillis,
                    "contacts" to emptyList<String>(),
                    "gifts" to listOf(starterGift.toMap()),
                    "systemMessages" to listOf(welcomeMsg.toMap()),
                    "createdAt" to FieldValue.serverTimestamp(),
                    "updatedAt" to FieldValue.serverTimestamp()
                )
                val reservationData = mapOf(
                    "uid" to uid,
                    "username" to validated,
                    "usernameLower" to usernameLower,
                    "createdAt" to FieldValue.serverTimestamp()
                )

                transaction.set(userRef, userData)
                transaction.set(usernameRef, reservationData)

                UserProfile(
                    id = uid,
                    uid = uid,
                    username = validated,
                    usernameLower = usernameLower,
                    displayName = displayName,
                    bio = bio,
                    birthday = birthdayClean,
                    isVerified = false,
                    hasAdminPanel = false,
                    isOnline = true,
                    lastOnlineMillis = nowMillis,
                    gifts = listOf(starterGift.toMap()),
                    systemMessages = listOf(welcomeMsg.toMap()),
                    createdAt = Timestamp.now(),
                    updatedAt = Timestamp.now()
                )
            }.await()
            Result.success(profile)
        } catch (e: CancellationException) {
            throw e
        } catch (e: NicknameTakenException) {
            Result.failure(e)
        } catch (e: FirebaseFirestoreException) {
            handleFirestoreError(e, OperationType.CREATE, "users/$uid")
            if (e.cause is NicknameTakenException) {
                Result.failure(e.cause!!)
            } else if (e.code == FirebaseFirestoreException.Code.PERMISSION_DENIED ||
                e.code == FirebaseFirestoreException.Code.ALREADY_EXISTS
            ) {
                Result.failure(NicknameTakenException("Никнейм «$validated» уже занят или зарезервирован системой"))
            } else {
                Result.failure(e)
            }
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.CREATE, "users/$uid")
            val cause = e.cause
            if (cause is NicknameTakenException) {
                Result.failure(cause)
            } else {
                Result.failure(e)
            }
        }
    }

    /**
     * Permanently deletes the current user's account, including:
     * - All messages inside all direct chats of the user (`/chats/{chatId}/messages/{messageId}`)
     * - All direct chats of the user (`/chats/{chatId}`)
     * - All call sessions of the user (`/calls/{callId}`)
     * - The user's reserved nickname (`/usernames/{usernameLower}`)
     * - The user's profile document (`/users/{uid}`)
     */
    suspend fun deleteCurrentAccount(currentProfile: UserProfile? = null): Result<Unit> {
        val uid = try {
            requireUserId()
        } catch (e: Exception) {
            return Result.failure(e)
        }

        return try {
            // 1. Fetch profile to determine usernameLower if not provided
            val profileSnap = try {
                db.collection("users").document(uid).get().await()
            } catch (_: Exception) {
                null
            }
            val usernameLower = currentProfile?.usernameLower?.takeIf { it.isNotBlank() }
                ?: profileSnap?.getString("usernameLower")?.trim()?.lowercase(Locale.ROOT)
                ?: profileSnap?.getString("username")?.trim()?.lowercase(Locale.ROOT)
                ?: ""

            // 2. Delete all messages and chat documents where the user is a participant
            try {
                val chatsQuery = db.collection("chats")
                    .whereArrayContains("participantIds", uid)
                    .get()
                    .await()
                for (chatDoc in chatsQuery.documents) {
                    val chatId = chatDoc.id
                    try {
                        val msgsQuery = db.collection("chats")
                            .document(chatId)
                            .collection("messages")
                            .whereArrayContains("participantIds", uid)
                            .get()
                            .await()
                        for (chunk in msgsQuery.documents.chunked(400)) {
                            try {
                                val batch = db.batch()
                                for (msgDoc in chunk) {
                                    batch.delete(msgDoc.reference)
                                }
                                batch.commit().await()
                            } catch (e: Exception) {
                                Log.w(TAG, "Failed to batch-delete messages in $chatId: ${e.message}")
                            }
                        }
                    } catch (e: Exception) {
                        Log.w(TAG, "Failed to query messages for chat $chatId during account deletion: ${e.message}")
                    }
                    try {
                        chatDoc.reference.delete().await()
                    } catch (e: Exception) {
                        Log.w(TAG, "Failed to delete chat $chatId: ${e.message}")
                    }
                }
            } catch (e: Exception) {
                Log.w(TAG, "Failed to clean up user chats during account deletion: ${e.message}")
            }

            // 3. Delete all call documents where the user is a participant
            try {
                val callsQuery = db.collection("calls")
                    .whereArrayContains("participantIds", uid)
                    .get()
                    .await()
                for (chunk in callsQuery.documents.chunked(400)) {
                    try {
                        val batch = db.batch()
                        for (callDoc in chunk) {
                            batch.delete(callDoc.reference)
                        }
                        batch.commit().await()
                    } catch (_: Exception) {
                    }
                }
            } catch (_: Exception) {
            }

            // 4. Delete username reservation (/usernames/{usernameLower})
            if (usernameLower.isNotBlank()) {
                try {
                    db.collection("usernames").document(usernameLower).delete().await()
                } catch (e: Exception) {
                    Log.w(TAG, "Failed to delete username reservation $usernameLower: ${e.message}")
                }
            }

            // 5. Delete user profile document (/users/{uid})
            db.collection("users").document(uid).delete().await()

            // 6. Also attempt to delete the Firebase Auth user record if recently authenticated
            try {
                auth.currentUser?.delete()?.await()
            } catch (e: Exception) {
                Log.i(TAG, "FirebaseAuth user.delete() skipped or requires recent login; Firestore data is wiped: ${e.message}")
            }

            Result.success(Unit)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.DELETE, "users/$uid")
            Result.failure(e)
        }
    }

    suspend fun updateProfileInfo(
        displayName: String,
        birthday: String,
        bio: String,
        avatarUrl: String? = null
    ): Result<Unit> {
        val uid = try {
            requireUserId()
        } catch (e: Exception) {
            return Result.failure(e)
        }
        val path = "users/$uid"
        return try {
            val updates = mutableMapOf<String, Any>(
                "displayName" to displayName.trim().take(50),
                "birthday" to birthday.trim().take(50),
                "bio" to bio.trim().take(300),
                "updatedAt" to FieldValue.serverTimestamp()
            )
            if (avatarUrl != null) {
                updates["avatarUrl"] = avatarUrl.take(450000)
            }
            db.collection("users").document(uid).update(updates).await()
            Result.success(Unit)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.UPDATE, path)
            Result.failure(e)
        }
    }

    suspend fun updatePresence(isOnline: Boolean, explicitUserId: String? = null) {
        val uid = explicitUserId?.takeIf { it.isNotBlank() } ?: auth.currentUser?.uid ?: return
        if (auth.currentUser == null) return
        try {
            db.collection("users").document(uid).update(
                mapOf(
                    "isOnline" to isOnline,
                    "lastOnlineMillis" to System.currentTimeMillis(),
                    "updatedAt" to FieldValue.serverTimestamp()
                )
            ).await()
        } catch (e: Exception) {
            Log.w(TAG, "updatePresence(isOnline=$isOnline) failed for $uid: ${e.message}")
        }
    }

    suspend fun findUserByNickname(rawQuery: String): Result<UserProfile?> {
        val cleaned = rawQuery.trim().removePrefix("@")
        if (cleaned.isEmpty()) {
            return Result.success(null)
        }
        val validated = validateNickname(cleaned).getOrElse { return Result.failure(it) }
        val usernameLower = validated.lowercase(Locale.ROOT)
        val reservationPath = "usernames/$usernameLower"

        return try {
            val reservationSnap = db.collection("usernames").document(usernameLower).get().await()
            if (!reservationSnap.exists()) {
                return Result.success(null)
            }
            val targetUid = reservationSnap.getString("uid") ?: return Result.success(null)
            val userSnap = db.collection("users").document(targetUid).get().await()
            if (userSnap.exists()) {
                Result.success(userSnap.toSafeUserProfile(targetUid))
            } else {
                Result.success(null)
            }
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.GET, reservationPath)
            Result.failure(e)
        }
    }

    fun buildDeterministicChatId(uid1: String, uid2: String): String {
        require(uid1.isNotBlank() && uid2.isNotBlank()) { "UID участников не могут быть пустыми" }
        if (uid1 == uid2) {
            throw SelfChatException("Нельзя создать личный чат с самим собой")
        }
        return if (uid1 < uid2) "${uid1}_${uid2}" else "${uid2}_${uid1}"
    }

    suspend fun getOrCreateDirectChat(
        currentUser: UserProfile,
        otherUser: UserProfile
    ): Result<DirectChat> {
        val uid = try {
            requireUserId()
        } catch (e: Exception) {
            return Result.failure(e)
        }
        if (uid != currentUser.uid) {
            return Result.failure(IllegalStateException("Несовпадение идентификатора текущего пользователя"))
        }
        if (currentUser.uid == otherUser.uid) {
            return Result.failure(SelfChatException("Нельзя открыть личный чат с самим собой"))
        }

        val (firstUser, secondUser) = if (currentUser.uid < otherUser.uid) {
            currentUser to otherUser
        } else {
            otherUser to currentUser
        }

        val chatId = "${firstUser.uid}_${secondUser.uid}"
        val chatRef = db.collection("chats").document(chatId)

        return try {
            val existingSnap = chatRef.get().await()
            if (existingSnap.exists()) {
                val existingChat = existingSnap.toSafeDirectChat()
                if (existingChat != null) {
                    addContactToCurrentUser(otherUser.usernameLower)
                    return Result.success(existingChat)
                }
            }

            val participantIds = listOf(firstUser.uid, secondUser.uid)
            val chatPayload = mapOf(
                "participantIds" to participantIds,
                "participant1Id" to firstUser.uid,
                "participant2Id" to secondUser.uid,
                "participant1Username" to firstUser.username,
                "participant2Username" to secondUser.username,
                "lastMessageText" to "",
                "lastMessageSenderId" to "",
                "createdAt" to FieldValue.serverTimestamp(),
                "updatedAt" to FieldValue.serverTimestamp()
            )
            chatRef.set(chatPayload).await()
            addContactToCurrentUser(otherUser.usernameLower)

            Result.success(
                DirectChat(
                    id = chatId,
                    participantIds = participantIds,
                    participant1Id = firstUser.uid,
                    participant2Id = secondUser.uid,
                    participant1Username = firstUser.username,
                    participant2Username = secondUser.username,
                    lastMessageText = "",
                    lastMessageSenderId = "",
                    createdAt = Timestamp.now(),
                    updatedAt = Timestamp.now()
                )
            )
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.CREATE, "chats/$chatId")
            Result.failure(e)
        }
    }

    /**
     * Initiates a real-time outgoing WebRTC audio or video call in `/calls/{callId}` with `status = RINGING`.
     * Uses Firestore strictly for call state & WebRTC SDP/ICE signaling.
     */
    suspend fun startOutgoingCall(
        caller: UserProfile,
        callee: UserProfile,
        isVideo: Boolean
    ): Result<CallSession> {
        val uid = try {
            requireUserId()
        } catch (e: Exception) {
            return Result.failure(e)
        }
        if (uid != caller.uid) {
            return Result.failure(IllegalStateException("Несовпадение UID вызывающего пользователя"))
        }
        if (caller.uid == callee.uid) {
            return Result.failure(SelfChatException("Нельзя позвонить самому себе"))
        }

        val (p1Id, p2Id) = if (caller.uid < callee.uid) {
            caller.uid to callee.uid
        } else {
            callee.uid to caller.uid
        }
        val callId = "${p1Id}_${p2Id}"
        val participantIds = listOf(p1Id, p2Id)
        val sessionId = "call_${System.currentTimeMillis()}_${Random.nextInt(1000, 9999)}"
        val callRef = db.collection("calls").document(callId)
        val cleanCallerUsername = caller.username.trim().removePrefix("@").ifBlank { "User" }.take(20)
        val cleanCalleeUsername = callee.username.trim().removePrefix("@").ifBlank { "User" }.take(20)

        val payload = mapOf(
            "callId" to callId,
            "sessionId" to sessionId,
            "participantIds" to participantIds,
            "participant1Id" to p1Id,
            "participant2Id" to p2Id,
            "callerId" to caller.uid,
            "callerUsername" to cleanCallerUsername,
            "calleeId" to callee.uid,
            "calleeUsername" to cleanCalleeUsername,
            "isVideo" to isVideo,
            "status" to CallSession.STATUS_RINGING,
            "callerVideoEnabled" to isVideo,
            "calleeVideoEnabled" to false,
            "callerMuted" to false,
            "calleeMuted" to false,
            "offerSdp" to "",
            "offerType" to "",
            "answerSdp" to "",
            "answerType" to "",
            "callerCandidates" to emptyList<String>(),
            "calleeCandidates" to emptyList<String>(),
            "createdAt" to FieldValue.serverTimestamp(),
            "updatedAt" to FieldValue.serverTimestamp()
        )

        return try {
            val setTask = callRef.set(payload)
            withTimeoutOrNull(3500L) {
                setTask.await()
            }
            if (setTask.isComplete && setTask.exception != null) {
                throw setTask.exception!!
            }
            val session = CallSession(
                id = callId,
                callId = callId,
                sessionId = sessionId,
                participantIds = participantIds,
                participant1Id = p1Id,
                participant2Id = p2Id,
                callerId = caller.uid,
                callerUsername = cleanCallerUsername,
                calleeId = callee.uid,
                calleeUsername = cleanCalleeUsername,
                isVideo = isVideo,
                status = CallSession.STATUS_RINGING,
                callerVideoEnabled = isVideo,
                calleeVideoEnabled = false,
                callerMuted = false,
                calleeMuted = false,
                offerSdp = "",
                offerType = "",
                answerSdp = "",
                answerType = "",
                callerCandidates = emptyList(),
                calleeCandidates = emptyList(),
                createdAt = Timestamp.now(),
                updatedAt = Timestamp.now()
            )
            Result.success(session)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.CREATE, "calls/$callId")
            Result.failure(e)
        }
    }

    /**
     * Publishes the WebRTC SDP Offer generated by the caller into `/calls/{callId}`.
     */
    suspend fun publishWebRtcOffer(
        callId: String,
        offerSdp: String
    ): Result<Unit> {
        if (callId.isBlank() || offerSdp.isBlank()) return Result.failure(IllegalArgumentException("Пустой SDP Offer"))
        return try {
            requireUserId()
            val updates = mapOf(
                "offerSdp" to offerSdp.take(64000),
                "offerType" to "offer",
                "updatedAt" to FieldValue.serverTimestamp()
            )
            db.collection("calls").document(callId).update(updates).await()
            Result.success(Unit)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.UPDATE, "calls/$callId")
            Result.failure(e)
        }
    }

    /**
     * Publishes the WebRTC SDP Answer generated by the callee and transitions the call to `ACCEPTED`.
     */
    suspend fun publishWebRtcAnswer(
        callId: String,
        answerSdp: String,
        calleeVideoEnabled: Boolean
    ): Result<Unit> {
        if (callId.isBlank()) return Result.failure(IllegalArgumentException("Пустой callId"))
        return try {
            requireUserId()
            val updates = mutableMapOf<String, Any>(
                "status" to CallSession.STATUS_ACCEPTED,
                "calleeVideoEnabled" to calleeVideoEnabled,
                "updatedAt" to FieldValue.serverTimestamp()
            )
            if (answerSdp.isNotBlank()) {
                updates["answerSdp"] = answerSdp.take(64000)
                updates["answerType"] = "answer"
            }
            db.collection("calls").document(callId).update(updates).await()
            Result.success(Unit)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.UPDATE, "calls/$callId")
            Result.failure(e)
        }
    }

    /**
     * Appends a serialized WebRTC ICE candidate to `callerCandidates` or `calleeCandidates` on `/calls/{callId}`.
     */
    suspend fun publishWebRtcIceCandidate(
        callId: String,
        isCaller: Boolean,
        candidateJson: String
    ) {
        if (callId.isBlank() || candidateJson.isBlank()) return
        val fieldName = if (isCaller) "callerCandidates" else "calleeCandidates"
        iceCandidateMutex.withLock {
            try {
                val docRef = db.collection("calls").document(callId)
                val snap = docRef.get().await()
                if (!snap.exists()) return
                val status = snap.getString("status") ?: ""
                if (status != CallSession.STATUS_RINGING && status != CallSession.STATUS_ACCEPTED) return

                val currentList = (snap.get(fieldName) as? List<*>)
                    ?.mapNotNull { it as? String }
                    ?: emptyList()
                if (currentList.contains(candidateJson) || currentList.size >= 55) return

                docRef.update(
                    mapOf(
                        fieldName to (currentList + candidateJson),
                        "updatedAt" to FieldValue.serverTimestamp()
                    )
                ).await()
            } catch (_: Exception) {
            }
        }
    }

    /**
     * Updates the status of an existing call session (`ACCEPTED`, `DECLINED`, `MISSED`, `BUSY`, `ENDED`).
     * Retries terminal status updates on transient errors so peer hang-ups are always synchronized.
     */
    suspend fun updateCallStatus(
        callId: String,
        newStatus: String,
        calleeVideoOnAccept: Boolean? = null
    ): Result<Unit> {
        if (callId.isBlank()) return Result.failure(IllegalArgumentException("Пустой callId"))
        val isTerminal = newStatus in listOf(
            CallSession.STATUS_DECLINED,
            CallSession.STATUS_MISSED,
            CallSession.STATUS_BUSY,
            CallSession.STATUS_ENDED
        )
        var lastError: Exception? = null
        val maxAttempts = if (isTerminal) 3 else 1

        for (attempt in 1..maxAttempts) {
            try {
                requireUserId()
                val updates = mutableMapOf<String, Any>(
                    "status" to newStatus,
                    "updatedAt" to FieldValue.serverTimestamp()
                )
                if (calleeVideoOnAccept != null) {
                    updates["calleeVideoEnabled"] = calleeVideoOnAccept
                }
                if (isTerminal) {
                    updates["callerVideoEnabled"] = false
                    updates["calleeVideoEnabled"] = false
                    updates["callerMuted"] = false
                    updates["calleeMuted"] = false
                    updates["offerSdp"] = ""
                    updates["offerType"] = ""
                    updates["answerSdp"] = ""
                    updates["answerType"] = ""
                    updates["callerCandidates"] = emptyList<String>()
                    updates["calleeCandidates"] = emptyList<String>()
                }
                db.collection("calls").document(callId).update(updates).await()
                return Result.success(Unit)
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                lastError = e
                if (attempt < maxAttempts) {
                    delay(140L * attempt)
                }
            }
        }
        val err = lastError ?: IllegalStateException("Failed to update call status")
        handleFirestoreError(err, OperationType.UPDATE, "calls/$callId")
        return Result.failure(err)
    }

    /**
     * Updates whether the caller or callee currently has their microphone muted.
     */
    suspend fun updateCallMuteState(
        callId: String,
        isCaller: Boolean,
        muted: Boolean
    ): Result<Unit> {
        if (callId.isBlank()) return Result.failure(IllegalArgumentException("Пустой callId"))
        return try {
            requireUserId()
            val updates = mapOf(
                (if (isCaller) "callerMuted" else "calleeMuted") to muted,
                "updatedAt" to FieldValue.serverTimestamp()
            )
            db.collection("calls").document(callId).update(updates).await()
            Result.success(Unit)
        } catch (e: CancellationException) {
            throw e
        } catch (_: Exception) {
            Result.failure(IllegalStateException("Failed to update call mute state"))
        }
    }

    /**
     * Updates whether the caller or callee currently has their camera enabled.
     */
    suspend fun updateCallVideoState(
        callId: String,
        isCaller: Boolean,
        videoEnabled: Boolean
    ): Result<Unit> {
        if (callId.isBlank()) return Result.failure(IllegalArgumentException("Пустой callId"))
        return try {
            requireUserId()
            val updates = mapOf(
                (if (isCaller) "callerVideoEnabled" else "calleeVideoEnabled") to videoEnabled,
                "updatedAt" to FieldValue.serverTimestamp()
            )
            db.collection("calls").document(callId).update(updates).await()
            Result.success(Unit)
        } catch (e: CancellationException) {
            throw e
        } catch (_: Exception) {
            Result.failure(IllegalStateException("Failed to update call video state"))
        }
    }

    /**
     * Observes a single call document `/calls/{callId}` in real time with automatic listener recovery.
     */
    fun observeCallSession(callId: String): Flow<CallSession?> = callbackFlow {
        if (callId.isBlank()) {
            trySend(null)
            close()
            return@callbackFlow
        }
        val docRef = db.collection("calls").document(callId)
        var registration: ListenerRegistration? = null
        var retryJob: Job? = null

        fun attachListener() {
            registration?.remove()
            registration = docRef.addSnapshotListener { snapshot, error ->
                if (error != null) {
                    Log.w(TAG, "Error observing call session $callId: ${error.message}")
                    retryJob?.cancel()
                    retryJob = launch {
                        delay(800L)
                        attachListener()
                    }
                    return@addSnapshotListener
                }
                if (snapshot != null && snapshot.exists()) {
                    trySend(snapshot.toSafeCallSession())
                } else {
                    trySend(null)
                }
            }
        }

        attachListener()
        awaitClose {
            retryJob?.cancel()
            registration?.remove()
        }
    }

    /**
     * Observes all call documents where `participantIds` contains `userId`.
     */
    fun observeUserCalls(userId: String): Flow<List<CallSession>> = callbackFlow {
        if (userId.isBlank()) {
            trySend(emptyList())
            close()
            return@callbackFlow
        }
        var registration: ListenerRegistration? = null
        var retryJob: Job? = null

        fun attachListener() {
            registration?.remove()
            registration = db.collection("calls")
                .whereArrayContains("participantIds", userId)
                .addSnapshotListener { querySnapshot, error ->
                    if (error != null) {
                        Log.w(TAG, "Error observing user calls: ${error.message}")
                        retryJob?.cancel()
                        retryJob = launch {
                            delay(1000L)
                            attachListener()
                        }
                        return@addSnapshotListener
                    }
                    if (querySnapshot != null) {
                        val sessions = querySnapshot.documents.mapNotNull { it.toSafeCallSession() }
                        trySend(sessions)
                    }
                }
        }

        attachListener()
        awaitClose {
            retryJob?.cancel()
            registration?.remove()
        }
    }

    private suspend fun addContactToCurrentUser(otherUsernameLower: String) {
        val uid = auth.currentUser?.uid ?: return
        try {
            val snap = db.collection("users").document(uid).get().await()
            val currentContacts = (snap.get("contacts") as? List<*>)?.mapNotNull { it as? String } ?: emptyList()
            if (!currentContacts.contains(otherUsernameLower) && currentContacts.size < 190) {
                db.collection("users").document(uid).update(
                    mapOf(
                        "contacts" to (currentContacts + otherUsernameLower),
                        "updatedAt" to FieldValue.serverTimestamp()
                    )
                ).await()
            }
        } catch (_: Exception) {
        }
    }

    suspend fun removeContact(otherUsernameLower: String): Result<Unit> {
        val uid = try {
            requireUserId()
        } catch (e: Exception) {
            return Result.failure(e)
        }
        return try {
            val snap = db.collection("users").document(uid).get().await()
            val currentContacts = (snap.get("contacts") as? List<*>)?.mapNotNull { it as? String } ?: emptyList()
            val updated = currentContacts.filterNot { it.equals(otherUsernameLower, ignoreCase = true) }
            db.collection("users").document(uid).update(
                mapOf(
                    "contacts" to updated,
                    "updatedAt" to FieldValue.serverTimestamp()
                )
            ).await()
            Result.success(Unit)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.UPDATE, "users/$uid")
            Result.failure(e)
        }
    }

    fun observeUserChats(userId: String): Flow<List<DirectChat>> = callbackFlow {
        val path = "chats"
        var registration: ListenerRegistration? = null
        var retryCount = 0

        fun attach() {
            registration?.remove()
            registration = db.collection("chats")
                .whereArrayContains("participantIds", userId)
                .addSnapshotListener { querySnapshot, error ->
                    if (error != null) {
                        if (auth.currentUser == null || auth.currentUser?.uid != userId) {
                            close(error)
                            return@addSnapshotListener
                        }
                        handleFirestoreError(error, OperationType.LIST, path)
                        if (retryCount < 3) {
                            retryCount += 1
                            launch {
                                delay(350L * retryCount)
                                try {
                                    auth.currentUser?.getIdToken(true)?.await()
                                } catch (_: Exception) {
                                }
                                attach()
                            }
                            return@addSnapshotListener
                        }
                        close(error)
                        return@addSnapshotListener
                    }
                    retryCount = 0
                    if (querySnapshot != null) {
                        val list = querySnapshot.documents
                            .mapNotNull { it.toSafeDirectChat() }
                            .sortedByDescending { it.updatedAt ?: it.createdAt ?: Timestamp(0, 0) }
                        trySend(list)
                    }
                }
        }

        attach()
        awaitClose { registration?.remove() }
    }

    fun observeMessages(chatId: String, userId: String): Flow<List<ChatMessage>> = callbackFlow {
        val path = "chats/$chatId/messages"
        var registration: ListenerRegistration? = null
        var retryCount = 0

        fun attach() {
            registration?.remove()
            registration = db.collection("chats")
                .document(chatId)
                .collection("messages")
                .whereArrayContains("participantIds", userId)
                .addSnapshotListener { querySnapshot, error ->
                    if (error != null) {
                        if (auth.currentUser == null || auth.currentUser?.uid != userId) {
                            close(error)
                            return@addSnapshotListener
                        }
                        handleFirestoreError(error, OperationType.LIST, path)
                        if (retryCount < 3) {
                            retryCount += 1
                            launch {
                                delay(350L * retryCount)
                                attach()
                            }
                            return@addSnapshotListener
                        }
                        close(error)
                        return@addSnapshotListener
                    }
                    retryCount = 0
                    if (querySnapshot != null) {
                        val list = querySnapshot.documents
                            .mapNotNull { it.toSafeChatMessage(chatId) }
                            .filterNot { it.deletedFor.contains(userId) }
                            .sortedWith(
                                compareBy<ChatMessage> { it.createdAt?.seconds ?: Long.MAX_VALUE }
                                    .thenBy { it.createdAt?.nanoseconds ?: Int.MAX_VALUE }
                                    .thenBy { it.id }
                            )
                        trySend(list)
                    }
                }
        }

        attach()
        awaitClose { registration?.remove() }
    }

    suspend fun sendMessage(
        chat: DirectChat,
        senderProfile: UserProfile,
        rawText: String,
        replyToSender: String? = null,
        replyToText: String? = null,
        voiceAudioBase64: String? = null,
        imageBase64: String? = null
    ): Result<String> {
        val uid = try {
            requireUserId()
        } catch (e: Exception) {
            return Result.failure(e)
        }
        val trimmedText = rawText.trim()
        if (trimmedText.isEmpty()) {
            return Result.failure(IllegalArgumentException("Сообщение не может быть пустым"))
        }
        if (trimmedText.length > 1000) {
            return Result.failure(IllegalArgumentException("Сообщение слишком длинное (макс. 1000 символов)"))
        }

        val chatRef = db.collection("chats").document(chat.id)
        val messageRef = chatRef.collection("messages").document()

        val otherId = chat.otherParticipantId(uid)
        val effectiveParticipantIds = when {
            chat.participantIds.size == 2 && chat.participantIds.contains(uid) -> chat.participantIds
            otherId.isNotBlank() -> if (uid < otherId) listOf(uid, otherId) else listOf(otherId, uid)
            else -> listOf(chat.participant1Id, chat.participant2Id).filter { it.isNotBlank() }
        }

        val messagePayload = mutableMapOf<String, Any>(
            "chatId" to chat.id,
            "senderId" to uid,
            "senderUsername" to senderProfile.username.ifBlank { "User" },
            "text" to trimmedText,
            "participantIds" to effectiveParticipantIds,
            "read" to false,
            "deletedFor" to emptyList<String>(),
            "createdAt" to FieldValue.serverTimestamp()
        )
        if (!replyToSender.isNullOrBlank() && !replyToText.isNullOrBlank()) {
            messagePayload["replyToSender"] = replyToSender.take(30)
            messagePayload["replyToText"] = replyToText.take(500)
        }
        if (!voiceAudioBase64.isNullOrBlank() && voiceAudioBase64.length <= 340000) {
            messagePayload["voiceAudioBase64"] = voiceAudioBase64
        }
        if (!imageBase64.isNullOrBlank() && imageBase64.length <= 480000) {
            messagePayload["imageBase64"] = imageBase64
        }

        val isVideoCircleMsg = trimmedText.startsWith("🎥 Кружок") || imageBase64?.startsWith("VN1:") == true
        val previewSummary = if (!imageBase64.isNullOrBlank() && !isVideoCircleMsg && trimmedText != "📷 Фотография") {
            "📷 $trimmedText".take(1000)
        } else {
            trimmedText
        }

        val chatUpdatePayload = mapOf(
            "lastMessageText" to previewSummary,
            "lastMessageSenderId" to uid,
            "updatedAt" to FieldValue.serverTimestamp()
        )

        return try {
            val batch = db.batch()
            batch.set(messageRef, messagePayload)
            batch.update(chatRef, chatUpdatePayload)
            val commitTask = batch.commit()
            withTimeoutOrNull(3500L) {
                commitTask.await()
            }
            if (commitTask.isComplete && commitTask.exception != null) {
                throw commitTask.exception!!
            }
            Result.success(messageRef.id)
        } catch (e: CancellationException) {
            throw e
        } catch (batchErr: Exception) {
            // Fallback: if updating the parent chat document in the same batch failed (e.g. legacy chat schema),
            // write the message document directly so message delivery to the recipient is NEVER blocked.
            return try {
                val msgTask = messageRef.set(messagePayload)
                withTimeoutOrNull(3500L) {
                    msgTask.await()
                }
                if (msgTask.isComplete && msgTask.exception != null) {
                    throw msgTask.exception!!
                }
                try {
                    chatRef.update(chatUpdatePayload).await()
                } catch (_: Exception) {
                }
                Result.success(messageRef.id)
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                handleFirestoreError(e, OperationType.CREATE, messageRef.path)
                Result.failure(e)
            }
        }
    }

    suspend fun markMessagesAsRead(chatId: String, currentUserId: String, messages: List<ChatMessage>) {
        val unreadIncoming = messages.filter { it.senderId != currentUserId && !it.read && it.id.isNotBlank() }
        if (unreadIncoming.isEmpty()) return
        val messagesCol = db.collection("chats").document(chatId).collection("messages")
        for (chunk in unreadIncoming.chunked(400)) {
            try {
                val batch = db.batch()
                for (msg in chunk) {
                    batch.update(messagesCol.document(msg.id), "read", true)
                }
                batch.commit().await()
            } catch (_: Exception) {
            }
        }
    }

    suspend fun deleteMessageForMe(chatId: String, message: ChatMessage, currentUserId: String): Result<Unit> {
        if (message.id.isBlank()) return Result.failure(IllegalArgumentException("Некорректный ID сообщения"))
        val docRef = db.collection("chats").document(chatId).collection("messages").document(message.id)
        return try {
            val newDeletedFor = (message.deletedFor + currentUserId).distinct().take(2)
            docRef.update("deletedFor", newDeletedFor).await()
            Result.success(Unit)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.UPDATE, docRef.path)
            Result.failure(e)
        }
    }

    suspend fun deleteMessageForAll(chatId: String, messageId: String): Result<Unit> {
        if (messageId.isBlank()) return Result.failure(IllegalArgumentException("Некорректный ID сообщения"))
        val docRef = db.collection("chats").document(chatId).collection("messages").document(messageId)
        return try {
            docRef.delete().await()
            Result.success(Unit)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.DELETE, docRef.path)
            Result.failure(e)
        }
    }

    suspend fun clearChatForMe(chatId: String, currentUserId: String, currentMessages: List<ChatMessage>): Result<Unit> {
        return try {
            val toHide = currentMessages.filter { it.id.isNotBlank() && !it.deletedFor.contains(currentUserId) }
            val messagesCol = db.collection("chats").document(chatId).collection("messages")
            for (chunk in toHide.chunked(400)) {
                val batch = db.batch()
                for (msg in chunk) {
                    val updated = (msg.deletedFor + currentUserId).distinct().take(2)
                    batch.update(messagesCol.document(msg.id), "deletedFor", updated)
                }
                batch.commit().await()
            }
            Result.success(Unit)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.UPDATE, "chats/$chatId/messages")
            Result.failure(e)
        }
    }

    suspend fun clearChatForBoth(chatId: String, currentMessages: List<ChatMessage>): Result<Unit> {
        val uid = try {
            requireUserId()
        } catch (e: Exception) {
            return Result.failure(e)
        }
        return try {
            val toDelete = currentMessages.filter { it.id.isNotBlank() }
            val messagesCol = db.collection("chats").document(chatId).collection("messages")
            for (chunk in toDelete.chunked(400)) {
                val batch = db.batch()
                for (msg in chunk) {
                    batch.delete(messagesCol.document(msg.id))
                }
                batch.commit().await()
            }
            db.collection("chats").document(chatId).update(
                mapOf(
                    "lastMessageText" to "",
                    "lastMessageSenderId" to uid,
                    "updatedAt" to FieldValue.serverTimestamp()
                )
            ).await()
            Result.success(Unit)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.DELETE, "chats/$chatId/messages")
            Result.failure(e)
        }
    }

    suspend fun toggleGiftVisibility(giftId: String, profile: UserProfile): Result<Unit> {
        val uid = try {
            requireUserId()
        } catch (e: Exception) {
            return Result.failure(e)
        }
        return try {
            val updatedGifts = profile.parsedGifts.map { gift ->
                if (gift.id == giftId) gift.copy(hidden = !gift.hidden).toMap() else gift.toMap()
            }
            db.collection("users").document(uid).update(
                mapOf(
                    "gifts" to updatedGifts,
                    "updatedAt" to FieldValue.serverTimestamp()
                )
            ).await()
            Result.success(Unit)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.UPDATE, "users/$uid")
            Result.failure(e)
        }
    }

    suspend fun sendGiftToUser(
        targetNickname: String,
        senderUsername: String,
        emoji: String,
        rarity: String,
        comment: String
    ): Result<Unit> {
        try {
            requireVerifiedAdmin()
        } catch (e: Exception) {
            return Result.failure(e)
        }

        val targetProfile = findUserByNickname(targetNickname).getOrElse { return Result.failure(it) }
            ?: return Result.failure(IllegalArgumentException("Пользователь @$targetNickname не найден"))

        val now = System.currentTimeMillis()
        val newGift = GiftItem(
            id = "gift_${now}_${Random.nextInt(1000, 9999)}",
            from = senderUsername,
            icon = emoji,
            rarity = rarity,
            comment = comment.ifBlank { "Эксклюзивный подарок от @$senderUsername" }.take(80),
            dateStr = formatRussianDateTime(now),
            timestamp = now,
            hidden = false
        )
        val sysNotification = SystemBotMessage(
            id = "sys_gift_$now",
            text = "🎁 Вам пришёл новый подарок от @$senderUsername!\n\n$emoji ${newGift.comment}\n\nПодарок уже отображается в вашей коллекции во вкладке «Профиль».",
            timestamp = now
        )

        val updatedGifts = (targetProfile.parsedGifts + newGift).takeLast(100).map { it.toMap() }
        val updatedSysMsgs = (targetProfile.parsedSystemMessages + sysNotification).takeLast(100).map { it.toMap() }

        return try {
            db.collection("users").document(targetProfile.uid).update(
                mapOf(
                    "gifts" to updatedGifts,
                    "systemMessages" to updatedSysMsgs,
                    "updatedAt" to FieldValue.serverTimestamp()
                )
            ).await()
            Result.success(Unit)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.UPDATE, "users/${targetProfile.uid}")
            Result.failure(e)
        }
    }

    suspend fun setVerificationBadge(targetNickname: String, verified: Boolean, actorUsername: String): Result<Unit> {
        try {
            requireVerifiedAdmin()
        } catch (e: Exception) {
            return Result.failure(e)
        }

        val targetProfile = findUserByNickname(targetNickname).getOrElse { return Result.failure(it) }
            ?: return Result.failure(IllegalArgumentException("Пользователь @$targetNickname не найден"))

        val now = System.currentTimeMillis()
        val sysMsg = SystemBotMessage(
            id = "sys_ver_$now",
            text = if (verified) {
                "✔ Вашему аккаунту @${targetProfile.username} выдана галочка верификации администратором @$actorUsername!"
            } else {
                "✕ С вашего аккаунта @${targetProfile.username} снята галочка верификации."
            },
            timestamp = now
        )
        val updatedSysMsgs = (targetProfile.parsedSystemMessages + sysMsg).takeLast(100).map { it.toMap() }

        return try {
            db.collection("users").document(targetProfile.uid).update(
                mapOf(
                    "isVerified" to verified,
                    "systemMessages" to updatedSysMsgs,
                    "updatedAt" to FieldValue.serverTimestamp()
                )
            ).await()
            Result.success(Unit)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.UPDATE, "users/${targetProfile.uid}")
            Result.failure(e)
        }
    }

    suspend fun generateSecurityCodeForUser(targetNickname: String, actorUsername: String): Result<String> {
        try {
            requireVerifiedAdmin()
        } catch (e: Exception) {
            return Result.failure(e)
        }

        val targetProfile = findUserByNickname(targetNickname).getOrElse { return Result.failure(it) }
            ?: return Result.failure(IllegalArgumentException("Пользователь @$targetNickname не найден"))

        val code = Random.nextInt(100000, 999999).toString()
        val now = System.currentTimeMillis()
        val sysMsg = SystemBotMessage(
            id = "sys_code_$now",
            text = "🔐 Ваш одноразовый код безопасности Oleg:\n\nЗапросил: @$actorUsername • Срок действия: 24 часа.",
            code = code,
            timestamp = now
        )
        val updatedSysMsgs = (targetProfile.parsedSystemMessages + sysMsg).takeLast(100).map { it.toMap() }

        return try {
            db.collection("users").document(targetProfile.uid).update(
                mapOf(
                    "systemMessages" to updatedSysMsgs,
                    "updatedAt" to FieldValue.serverTimestamp()
                )
            ).await()
            Result.success(code)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.UPDATE, "users/${targetProfile.uid}")
            Result.failure(e)
        }
    }

    private fun formatRussianDateTime(millis: Long): String {
        return try {
            val sdf = SimpleDateFormat("dd MMM yyyy в HH:mm", Locale.forLanguageTag("ru-RU"))
            sdf.format(Date(millis))
        } catch (_: Exception) {
            "Сегодня"
        }
    }

    companion object {
        private const val TAG = "MessengerRepo"
        const val ADMIN_USERNAME_LOWER = "shabandurov"
        private val NICKNAME_REGEX = Regex("^[a-zA-Z0-9_]{3,20}$")
    }
}
