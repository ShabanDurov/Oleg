package com.example.data.model

import com.google.firebase.Timestamp
import com.google.firebase.firestore.DocumentId
import com.google.firebase.firestore.Exclude
import com.google.firebase.firestore.IgnoreExtraProperties
import com.google.firebase.firestore.PropertyName
import com.google.firebase.firestore.ServerTimestamp
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale

@IgnoreExtraProperties
data class GiftItem(
    val id: String = "",
    val from: String = "ShabanDurov",
    val icon: String = "🧸",
    val rarity: String = "rare",
    val comment: String = "Подарок для вас",
    val dateStr: String = "Сегодня",
    val timestamp: Long = 0L,
    val hidden: Boolean = false
) {
    fun toMap(): Map<String, Any> = mapOf(
        "id" to id,
        "from" to from,
        "icon" to icon,
        "rarity" to rarity,
        "comment" to comment,
        "dateStr" to dateStr,
        "timestamp" to timestamp,
        "hidden" to hidden
    )

    companion object {
        fun fromMap(map: Map<*, *>): GiftItem {
            val rawFrom = map["from"] as? String ?: "ShabanDurov"
            val rawComment = map["comment"] as? String ?: "Подарок"
            return GiftItem(
                id = map["id"] as? String ?: "",
                from = if (rawFrom.equals("Phonogramm", ignoreCase = true) || rawFrom.equals("Олег", ignoreCase = true)) "Oleg" else rawFrom,
                icon = map["icon"] as? String ?: "🧸",
                rarity = map["rarity"] as? String ?: "rare",
                comment = rawComment
                    .replace("Phonogramm", "Oleg", ignoreCase = true)
                    .replace("Олег", "Oleg", ignoreCase = true),
                dateStr = map["dateStr"] as? String ?: "Недавно",
                timestamp = (map["timestamp"] as? Number)?.toLong() ?: 0L,
                hidden = map["hidden"] as? Boolean ?: false
            )
        }
    }
}

@IgnoreExtraProperties
data class SystemBotMessage(
    val id: String = "",
    val text: String = "",
    val code: String = "",
    val timestamp: Long = 0L
) {
    @get:Exclude
    val time: String
        get() = if (timestamp > 0L) {
            SimpleDateFormat("HH:mm", Locale.getDefault()).format(Date(timestamp))
        } else {
            "Сейчас"
        }

    fun toMap(): Map<String, Any> = mapOf(
        "id" to id,
        "text" to text,
        "code" to code,
        "timestamp" to timestamp
    )

    companion object {
        fun fromMap(map: Map<*, *>): SystemBotMessage {
            val rawText = map["text"] as? String ?: ""
            return SystemBotMessage(
                id = map["id"] as? String ?: "",
                text = rawText
                    .replace("Phonogramm", "Oleg", ignoreCase = true)
                    .replace("Олег", "Oleg", ignoreCase = true),
                code = map["code"] as? String ?: "",
                timestamp = (map["timestamp"] as? Number)?.toLong() ?: 0L
            )
        }
    }
}

@IgnoreExtraProperties
data class UserProfile(
    @DocumentId val id: String = "",
    val uid: String = "",
    val username: String = "",
    val usernameLower: String = "",
    val displayName: String = "",
    val bio: String = "",
    val birthday: String = "",
    val avatarUrl: String = "",
    @get:PropertyName("isVerified")
    val isVerified: Boolean = false,
    val hasAdminPanel: Boolean = false,
    @get:PropertyName("isOnline")
    val isOnline: Boolean = false,
    val lastOnlineMillis: Long = 0L,
    val contacts: List<String> = emptyList(),
    val gifts: List<Map<String, Any>> = emptyList(),
    val systemMessages: List<Map<String, Any>> = emptyList(),
    @ServerTimestamp val createdAt: Timestamp? = null,
    @ServerTimestamp val updatedAt: Timestamp? = null
) {
    @get:Exclude
    val effectiveDisplayName: String
        get() = displayName.ifBlank { username }

    @Exclude
    fun resolvedDisplayName(): String = effectiveDisplayName

    /**
     * Returns the last timestamp (in epoch ms) when the user actively reported presence.
     * Combines client heartbeat (`lastOnlineMillis`) and server timestamp (`updatedAt`)
     * so device clock skew never hides a live user's presence.
     */
    @Exclude
    fun effectiveLastSeenMillis(): Long {
        val serverUpdatedMillis = updatedAt?.toDate()?.time ?: 0L
        val serverCreatedMillis = createdAt?.toDate()?.time ?: 0L
        return maxOf(lastOnlineMillis, serverUpdatedMillis, serverCreatedMillis)
    }

    /**
     * A user is considered online ONLY if `isOnline` is true AND their presence heartbeat
     * (`lastOnlineMillis` or `updatedAt`) was updated within the last [ONLINE_HEARTBEAT_TIMEOUT_MS] milliseconds.
     * This prevents stale "online" states when a user force-closes the app or loses connectivity.
     */
    @Exclude
    fun isEffectivelyOnline(nowMillis: Long = System.currentTimeMillis()): Boolean {
        if (!isOnline) return false
        val lastSeen = effectiveLastSeenMillis()
        if (lastSeen <= 0L) return true
        val ageMs = nowMillis - lastSeen
        return ageMs <= ONLINE_HEARTBEAT_TIMEOUT_MS
    }

    /**
     * Formats the user's live presence status in Russian ("в сети", "был(а) только что",
     * "был(а) X мин. назад", "был(а) сегодня в HH:mm", "был(а) вчера в HH:mm", etc.).
     */
    @Exclude
    fun formatPresenceStatus(nowMillis: Long = System.currentTimeMillis()): String {
        if (isEffectivelyOnline(nowMillis)) {
            return "в сети"
        }
        val lastSeen = effectiveLastSeenMillis()
        if (lastSeen <= 0L) {
            return "не в сети"
        }
        val diffMs = (nowMillis - lastSeen).coerceAtLeast(0L)
        val diffMinutes = diffMs / 60_000L
        if (diffMinutes < 1L) {
            return "был(а) только что"
        }
        if (diffMinutes < 60L) {
            return "был(а) $diffMinutes мин. назад"
        }

        val nowCal = Calendar.getInstance().apply { timeInMillis = nowMillis }
        val seenCal = Calendar.getInstance().apply { timeInMillis = lastSeen }
        val timeStr = SimpleDateFormat("HH:mm", Locale.getDefault()).format(Date(lastSeen))

        val sameYear = nowCal.get(Calendar.YEAR) == seenCal.get(Calendar.YEAR)
        val nowDay = nowCal.get(Calendar.DAY_OF_YEAR)
        val seenDay = seenCal.get(Calendar.DAY_OF_YEAR)

        return when {
            sameYear && nowDay == seenDay -> "был(а) сегодня в $timeStr"
            sameYear && nowDay - seenDay == 1 -> "был(а) вчера в $timeStr"
            else -> {
                val dateStr = SimpleDateFormat("dd.MM", Locale.getDefault()).format(Date(lastSeen))
                "был(а) $dateStr в $timeStr"
            }
        }
    }

    @get:Exclude
    val effectiveBio: String
        get() = bio.ifBlank { "Счастливый пользователь Oleg" }
            .replace("Phonogramm", "Oleg", ignoreCase = true)
            .replace("Олег", "Oleg", ignoreCase = true)

    @get:Exclude
    val effectiveBirthday: String
        get() = birthday.ifBlank { "Не указан" }

    @get:Exclude
    val isCreatorRole: Boolean
        get() = usernameLower == "shabandurov" && isVerified

    @get:Exclude
    val parsedGifts: List<GiftItem>
        get() = gifts.mapNotNull { raw ->
            try {
                GiftItem.fromMap(raw)
            } catch (_: Exception) {
                null
            }
        }

    @get:Exclude
    val parsedSystemMessages: List<SystemBotMessage>
        get() = systemMessages.mapNotNull { raw ->
            try {
                SystemBotMessage.fromMap(raw)
            } catch (_: Exception) {
                null
            }
        }.sortedBy { it.timestamp }

    companion object {
        const val ONLINE_HEARTBEAT_TIMEOUT_MS = 120_000L
    }
}

@IgnoreExtraProperties
data class UsernameReservation(
    @DocumentId val id: String = "",
    val uid: String = "",
    val username: String = "",
    val usernameLower: String = "",
    @ServerTimestamp val createdAt: Timestamp? = null
)

@IgnoreExtraProperties
data class DirectChat(
    @DocumentId val id: String = "",
    val participantIds: List<String> = emptyList(),
    val participant1Id: String = "",
    val participant2Id: String = "",
    val participant1Username: String = "",
    val participant2Username: String = "",
    val lastMessageText: String = "",
    val lastMessageSenderId: String = "",
    @ServerTimestamp val createdAt: Timestamp? = null,
    @ServerTimestamp val updatedAt: Timestamp? = null
) {
    @get:Exclude
    val lastMessage: String
        get() = lastMessageText

    @get:Exclude
    val lastSenderId: String
        get() = lastMessageSenderId

    @get:Exclude
    val updatedAtMillis: Long
        get() = updatedAt?.toDate()?.time ?: createdAt?.toDate()?.time ?: 0L

    @Exclude
    fun otherParticipantId(currentUserId: String): String {
        if (participant1Id == currentUserId && participant2Id.isNotBlank()) return participant2Id
        if (participant2Id == currentUserId && participant1Id.isNotBlank()) return participant1Id
        val fromList = participantIds.firstOrNull { it.isNotBlank() && it != currentUserId }
        if (!fromList.isNullOrBlank()) return fromList
        val fromChatId = id.split("_").firstOrNull { it.isNotBlank() && it != currentUserId }
        if (!fromChatId.isNullOrBlank()) return fromChatId
        return if (participant1Id == currentUserId) participant2Id else participant1Id
    }

    @Exclude
    fun otherParticipantUsername(currentUserId: String): String {
        if (participant1Id == currentUserId && participant2Username.isNotBlank()) return participant2Username
        if (participant2Id == currentUserId && participant1Username.isNotBlank()) return participant1Username
        return if (participant1Id == currentUserId) {
            participant2Username.ifBlank { participant1Username }
        } else {
            participant1Username.ifBlank { participant2Username }
        }
    }

    @Exclude
    fun otherUsername(currentUserId: String): String = otherParticipantUsername(currentUserId)
}

@IgnoreExtraProperties
data class ChatMessage(
    @DocumentId val id: String = "",
    val chatId: String = "",
    val senderId: String = "",
    val senderUsername: String = "",
    val text: String = "",
    val participantIds: List<String> = emptyList(),
    val replyToSender: String = "",
    val replyToText: String = "",
    val read: Boolean = false,
    val deletedFor: List<String> = emptyList(),
    val voiceAudioBase64: String = "",
    val imageBase64: String = "",
    @ServerTimestamp val createdAt: Timestamp? = null
) {
    @get:Exclude
    val createdAtMillis: Long
        get() = createdAt?.toDate()?.time ?: System.currentTimeMillis()
}

@IgnoreExtraProperties
data class CallSession(
    @DocumentId val id: String = "",
    val callId: String = "",
    val sessionId: String = "",
    val participantIds: List<String> = emptyList(),
    val participant1Id: String = "",
    val participant2Id: String = "",
    val callerId: String = "",
    val callerUsername: String = "",
    val calleeId: String = "",
    val calleeUsername: String = "",
    @get:PropertyName("isVideo")
    val isVideo: Boolean = false,
    val status: String = STATUS_RINGING,
    val callerVideoEnabled: Boolean = false,
    val calleeVideoEnabled: Boolean = false,
    val callerMuted: Boolean = false,
    val calleeMuted: Boolean = false,
    val offerSdp: String = "",
    val offerType: String = "",
    val answerSdp: String = "",
    val answerType: String = "",
    val callerCandidates: List<String> = emptyList(),
    val calleeCandidates: List<String> = emptyList(),
    @ServerTimestamp val createdAt: Timestamp? = null,
    @ServerTimestamp val updatedAt: Timestamp? = null
) {
    @get:Exclude
    val updatedAtMillis: Long
        get() = updatedAt?.toDate()?.time ?: createdAt?.toDate()?.time ?: 0L

    @Exclude
    fun isCaller(currentUserId: String): Boolean = callerId == currentUserId

    @Exclude
    fun isIncoming(currentUserId: String): Boolean = calleeId == currentUserId

    @Exclude
    fun otherUsername(currentUserId: String): String =
        if (callerId == currentUserId) calleeUsername else callerUsername

    @Exclude
    fun otherUserId(currentUserId: String): String =
        if (callerId == currentUserId) calleeId else callerId

    @Exclude
    fun peerVideoEnabled(currentUserId: String): Boolean =
        if (callerId == currentUserId) calleeVideoEnabled else callerVideoEnabled

    @Exclude
    fun peerMuted(currentUserId: String): Boolean =
        if (callerId == currentUserId) calleeMuted else callerMuted

    @Exclude
    fun peerCandidates(currentUserId: String): List<String> =
        if (callerId == currentUserId) calleeCandidates else callerCandidates

    companion object {
        const val STATUS_RINGING = "RINGING"
        const val STATUS_ACCEPTED = "ACCEPTED"
        const val STATUS_DECLINED = "DECLINED"
        const val STATUS_MISSED = "MISSED"
        const val STATUS_BUSY = "BUSY"
        const val STATUS_ENDED = "ENDED"
    }
}

class NicknameValidationException(message: String) : IllegalArgumentException(message)
class NicknameTakenException(message: String) : IllegalStateException(message)
class SelfChatException(message: String) : IllegalArgumentException(message)
class AdminAccessDeniedException(
    message: String = "Отказано в доступе: панель создателя доступна только подтверждённому администратору @ShabanDurov 🔒"
) : SecurityException(message)

data class IncomingMessageNotification(
    val id: String,
    val chatId: String = "",
    val senderUsername: String,
    val senderDisplayName: String = "",
    val senderAvatarUrl: String = "",
    val messageText: String,
    val isSystemBot: Boolean = false,
    val isCallInvite: Boolean = false,
    val callSessionId: String = "",
    val isVideoCall: Boolean = false,
    val timestamp: Long = System.currentTimeMillis()
)
