# Security Specification (`security_spec.md`)

## 1. Data Invariants

1. **Authentication Mandatory**: Every read and write operation across `/users`, `/usernames`, `/chats`, and `/chats/{chatId}/messages` requires `request.auth != null`.
2. **Atomic Nickname Uniqueness (`users` <-> `usernames`)**:
   - A `/users/{userId}` document can only be created if `userId == request.auth.uid`, `username` matches `^[a-zA-Z0-9_]{3,20}$`, `usernameLower == username.lower()`, and in the same atomic transaction `/usernames/{usernameLower}` exists after commit with `uid == request.auth.uid`.
   - A `/usernames/{usernameLower}` document can only be created if it does not already exist, `usernameLower` matches `^[a-z0-9_]{3,20}$`, `uid == request.auth.uid`, and `/users/{request.auth.uid}` exists after commit with `usernameLower == usernameLower`.
   - Neither `/users/{userId}` nor `/usernames/{usernameLower}` can be updated or deleted once created, preventing nickname hijacking or profile spoofing.
3. **Deterministic Non-Duplicate Direct Chats (`/chats/{chatId}`)**:
   - Every direct chat has exactly 2 distinct participants (`participant1Id < participant2Id`), and `chatId` MUST equal `participant1Id + '_' + participant2Id`.
   - `request.auth.uid` MUST be one of `participantIds`.
   - Both `participant1Id` and `participant2Id` MUST exist in `/users`.
   - Only participants (`request.auth.uid in resource.data.participantIds`) can read, list, or update the chat's `lastMessageText`, `lastMessageSenderId`, and `updatedAt`.
4. **Message Isolation & Author Integrity (`/chats/{chatId}/messages/{messageId}`)**:
   - Only participants of `chatId` can read, list, or create messages.
   - On message creation, `senderId` MUST equal `request.auth.uid`, `text.trim().size() >= 1`, `text.size() <= 1000`, and `participantIds` MUST match the parent `/chats/{chatId}` document's `participantIds`.
   - Messages are immutable (`allow update, delete: if false`).

## 2. The "Dirty Dozen" Payloads

1. **Unauthenticated Profile Read**: Unauthenticated client attempts `get /users/alice_123`. (Must Fail)
2. **Identity Spoofing on Profile Creation**: `alice_123` attempts to create `/users/bob_456` or set `uid: "bob_456"`. (Must Fail)
3. **Orphan Profile Creation Without Username Reservation**: `alice_123` writes `/users/alice_123` without atomically reserving `/usernames/alice_nick`. (Must Fail)
4. **Case-Insensitive Nickname Collision / Hijack**: `bob_456` attempts to overwrite existing `/usernames/alice_nick` or register `"ALICE_NICK"`. (Must Fail)
5. **Invalid Nickname Format**: `alice_123` attempts to register `"ab"` (too short) or `"bad!nick"` (invalid chars). (Must Fail)
6. **Ghost Field Injection (Shadow Write)**: `alice_123` includes `"isAdmin": true` in `/users/alice_123` or `/chats/{chatId}`. (Must Fail)
7. **Duplicate / Non-Canonical Chat Creation**: `alice_123` attempts to create a chat with `chatId: "random_id"` or reversed `participant1Id > participant2Id`. (Must Fail)
8. **Cross-User Chat Snooping**: `charlie_789` attempts to `get` or `list` a chat between `alice_123` and `bob_456`. (Must Fail)
9. **Chat Participant Mutation**: `alice_123` attempts to update `participantIds` on an existing `/chats/{chatId}` document. (Must Fail)
10. **Message Author Spoofing**: `alice_123` attempts to create a message in `alice_123_bob_456` with `senderId: "bob_456"`. (Must Fail)
11. **Empty / Whitespace-Only Message**: `alice_123` attempts to create a message with `text: "   "`. (Must Fail)
12. **Cross-User Message Scraping**: `charlie_789` attempts to `list` or `get` `/chats/alice_123_bob_456/messages`. (Must Fail)
