const {
  initializeTestEnvironment,
  assertFails,
  assertSucceeds,
} = require("@firebase/rules-unit-testing");
const { test, before, after, beforeEach } = require("node:test");
const fs = require("node:fs");

let testEnv;
const PROJECT_ID = process.env.GCP_PROJECT || "demo-no-project";
const ALICE_UID = "alice_123";
const BOB_UID = "bob_456";
const CHARLIE_UID = "charlie_789";
const SHABAN_UID = "shaban_durov_verified_uid";

const [emulatorHost, emulatorPortStr] = (process.env.FIRESTORE_EMULATOR_HOST || "127.0.0.1:8085").split(":");
const emulatorPort = parseInt(emulatorPortStr, 10);

before(async () => {
  const rules = fs.readFileSync("./firestore.rules", "utf8");
  testEnv = await initializeTestEnvironment({
    projectId: PROJECT_ID,
    firestore: {
      rules,
      host: emulatorHost,
      port: emulatorPort,
    },
  });
});

after(async () => {
  if (testEnv) {
    await testEnv.cleanup();
  }
});

beforeEach(async () => {
  if (testEnv) {
    await testEnv.clearFirestore();
  }
});

async function registerUserAtomically(db, uid, username, extraFields = {}) {
  const now = new Date();
  const usernameLower = username.toLowerCase();
  const batch = db.batch();
  batch.set(db.collection("users").doc(uid), {
    uid,
    username,
    usernameLower,
    createdAt: now,
    updatedAt: now,
    ...extraFields,
  });
  batch.set(db.collection("usernames").doc(usernameLower), {
    uid,
    username,
    usernameLower,
    createdAt: now,
  });
  await batch.commit();
}

test("1. Unauthenticated user cannot read or write any collection", async () => {
  const unauthDb = testEnv.unauthenticatedContext().firestore();
  await assertFails(unauthDb.collection("users").doc(ALICE_UID).get());
  await assertFails(unauthDb.collection("usernames").doc("alice_01").get());
  await assertFails(unauthDb.collection("chats").get());
});

test("2. Atomic nickname registration succeeds when valid and paired, and reading non-existent profile succeeds", async () => {
  const aliceDb = testEnv.authenticatedContext(ALICE_UID).firestore();
  // Reading non-existent profile document before registration must succeed (not fail with permission denied)
  await assertSucceeds(aliceDb.collection("users").doc(ALICE_UID).get());
  await assertSucceeds(registerUserAtomically(aliceDb, ALICE_UID, "Alice_01"));
});

test("3. Orphan user profile creation without username reservation fails", async () => {
  const aliceDb = testEnv.authenticatedContext(ALICE_UID).firestore();
  const now = new Date();
  await assertFails(
    aliceDb.collection("users").doc(ALICE_UID).set({
      uid: ALICE_UID,
      username: "Alice_01",
      usernameLower: "alice_01",
      createdAt: now,
      updatedAt: now,
    })
  );
});

test("4. Duplicate case-insensitive nickname registration by another user fails", async () => {
  const aliceDb = testEnv.authenticatedContext(ALICE_UID).firestore();
  await assertSucceeds(registerUserAtomically(aliceDb, ALICE_UID, "Alice_01"));

  const bobDb = testEnv.authenticatedContext(BOB_UID).firestore();
  await assertFails(registerUserAtomically(bobDb, BOB_UID, "ALICE_01"));
});

test("5. Invalid nickname format (<3 chars or invalid symbols) fails", async () => {
  const aliceDb = testEnv.authenticatedContext(ALICE_UID).firestore();
  await assertFails(registerUserAtomically(aliceDb, ALICE_UID, "ab"));
  await assertFails(registerUserAtomically(aliceDb, ALICE_UID, "alice!@#"));
});

test("6. Creating deterministic direct chat and sending message succeeds for participants", async () => {
  const aliceDb = testEnv.authenticatedContext(ALICE_UID).firestore();
  const bobDb = testEnv.authenticatedContext(BOB_UID).firestore();
  await assertSucceeds(registerUserAtomically(aliceDb, ALICE_UID, "Alice_01"));
  await assertSucceeds(registerUserAtomically(bobDb, BOB_UID, "Bob_02"));

  const chatId = `${ALICE_UID}_${BOB_UID}`;
  const now = new Date();

  await assertSucceeds(
    aliceDb.collection("chats").doc(chatId).set({
      participantIds: [ALICE_UID, BOB_UID],
      participant1Id: ALICE_UID,
      participant2Id: BOB_UID,
      participant1Username: "Alice_01",
      participant2Username: "Bob_02",
      lastMessageText: "",
      lastMessageSenderId: "",
      createdAt: now,
      updatedAt: now,
    })
  );

  // Non-canonical chatId fails
  await assertFails(
    aliceDb.collection("chats").doc(`${BOB_UID}_${ALICE_UID}`).set({
      participantIds: [ALICE_UID, BOB_UID],
      participant1Id: ALICE_UID,
      participant2Id: BOB_UID,
      participant1Username: "Alice_01",
      participant2Username: "Bob_02",
      lastMessageText: "",
      lastMessageSenderId: "",
      createdAt: now,
      updatedAt: now,
    })
  );

  // Alice sends a valid message
  await assertSucceeds(
    aliceDb.collection("chats").doc(chatId).collection("messages").doc("msg_1").set({
      chatId,
      senderId: ALICE_UID,
      senderUsername: "Alice_01",
      text: "Привет, Боб!",
      participantIds: [ALICE_UID, BOB_UID],
      createdAt: now,
    })
  );

  // Empty/whitespace message fails
  await assertFails(
    aliceDb.collection("chats").doc(chatId).collection("messages").doc("msg_empty").set({
      chatId,
      senderId: ALICE_UID,
      senderUsername: "Alice_01",
      text: "   ",
      participantIds: [ALICE_UID, BOB_UID],
      createdAt: now,
    })
  );

  // Spoofing senderId fails
  await assertFails(
    aliceDb.collection("chats").doc(chatId).collection("messages").doc("msg_spoof").set({
      chatId,
      senderId: BOB_UID,
      senderUsername: "Bob_02",
      text: "Spoofed",
      participantIds: [ALICE_UID, BOB_UID],
      createdAt: now,
    })
  );

  // Bob can query chats and messages with participantIds array-contains filter
  await assertSucceeds(
    bobDb.collection("chats").where("participantIds", "array-contains", BOB_UID).get()
  );
  await assertSucceeds(
    bobDb
      .collection("chats")
      .doc(chatId)
      .collection("messages")
      .where("participantIds", "array-contains", BOB_UID)
      .get()
  );

  // Charlie (non-participant) cannot read or list Alice & Bob's chat or messages
  const charlieDb = testEnv.authenticatedContext(CHARLIE_UID).firestore();
  await assertFails(charlieDb.collection("chats").doc(chatId).get());
  await assertFails(
    charlieDb.collection("chats").doc(chatId).collection("messages").doc("msg_1").get()
  );
  await assertFails(
    charlieDb.collection("chats").doc(chatId).collection("messages").get()
  );
});

test("7. Regular user cannot self-assign admin privileges, modify /config/admin, or perform admin operations", async () => {
  const aliceDb = testEnv.authenticatedContext(ALICE_UID).firestore();
  const bobDb = testEnv.authenticatedContext(BOB_UID).firestore();

  // Regular user cannot create profile with hasAdminPanel=true or isVerified=true
  await assertFails(
    registerUserAtomically(aliceDb, ALICE_UID, "Alice_01", { hasAdminPanel: true })
  );
  await assertFails(
    registerUserAtomically(aliceDb, ALICE_UID, "Alice_01", { isVerified: true })
  );

  await assertSucceeds(registerUserAtomically(aliceDb, ALICE_UID, "Alice_01"));
  await assertSucceeds(registerUserAtomically(bobDb, BOB_UID, "Bob_02"));

  // Regular user cannot write to /config/admin
  await assertFails(
    aliceDb.collection("config").doc("admin").set({ adminUid: ALICE_UID })
  );

  // Regular user cannot escalate their own profile to hasAdminPanel=true or isVerified=true
  await assertFails(
    aliceDb.collection("users").doc(ALICE_UID).update({
      hasAdminPanel: true,
      updatedAt: new Date(),
    })
  );
  await assertFails(
    aliceDb.collection("users").doc(ALICE_UID).update({
      isVerified: true,
      updatedAt: new Date(),
    })
  );

  // Regular user cannot grant verification badge or gifts to another user
  await assertFails(
    aliceDb.collection("users").doc(BOB_UID).update({
      isVerified: true,
      updatedAt: new Date(),
    })
  );
});

test("8. Only verified ShabanDurov (with UID in /config/admin or admin Custom Claim) can perform admin operations", async () => {
  const bobDb = testEnv.authenticatedContext(BOB_UID).firestore();
  await assertSucceeds(registerUserAtomically(bobDb, BOB_UID, "Bob_02"));

  // Provision /config/admin on the server (simulating Firebase Console / Admin SDK setup)
  await testEnv.withSecurityRulesDisabled(async (context) => {
    await context.firestore().collection("config").doc("admin").set({
      adminUid: SHABAN_UID,
      adminUsernameLower: "shabandurov",
    });
  });

  // Impostor Charlie cannot reserve 'ShabanDurov' when /config/admin points to SHABAN_UID
  const charlieDb = testEnv.authenticatedContext(CHARLIE_UID).firestore();
  await assertFails(registerUserAtomically(charlieDb, CHARLIE_UID, "ShabanDurov"));

  // True ShabanDurov (matching SHABAN_UID) can register 'ShabanDurov' and perform admin operations
  const shabanDb = testEnv.authenticatedContext(SHABAN_UID).firestore();
  await assertSucceeds(registerUserAtomically(shabanDb, SHABAN_UID, "ShabanDurov"));

  await assertSucceeds(
    shabanDb.collection("users").doc(BOB_UID).update({
      isVerified: true,
      gifts: [{ id: "g1", from: "ShabanDurov", icon: "👑", rarity: "legendary" }],
      updatedAt: new Date(),
    })
  );
});
